package com.example.procam

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Document Scanning & Multi-Page PDF Exporter (P3 Requirement 15):
 * - Live page edge quad detection
 * - Perspective correction (warp quad to rectangle)
 * - Shadow removal by dividing by blurred background illumination
 * - Color / Gray / B&W (adaptive thresholding) / Original modes
 * - Brightness adjustment
 * - Multi-page document management and PDF export via native PdfDocument
 */
object DocumentScanManager {

    enum class DocColorMode { COLOR, GRAY, BW, ORIGINAL }

    data class ScannedPage(
        var original: Bitmap,
        var processed: Bitmap,
        var colorMode: DocColorMode = DocColorMode.COLOR,
        var brightness: Int = 0 // -50 to +50
    )

    private val sessionPages = ArrayList<ScannedPage>()

    fun clearSession() {
        for (page in sessionPages) {
            ImageProcessor.recycleAll(page.original, page.processed)
        }
        sessionPages.clear()
    }

    fun addPage(page: ScannedPage) {
        sessionPages.add(page)
    }

    fun getPages(): List<ScannedPage> = sessionPages

    fun pageCount(): Int = sessionPages.size

    /**
     * Detect document corner quad points from image (Top-Left, Top-Right, Bottom-Right, Bottom-Left).
     */
    fun detectDocumentQuad(src: Bitmap): List<PointF> {
        val w = src.width.toFloat()
        val h = src.height.toFloat()

        // Downscale for fast edge search
        val sw = 160
        val sh = (sw * src.height / src.width).coerceAtLeast(120)
        val small = Bitmap.createScaledBitmap(src, sw, sh, false)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        small.recycle()

        val luma = IntArray(pixels.size)
        var sum = 0L
        for (i in pixels.indices) {
            val p = pixels[i]
            val l = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
            luma[i] = l
            sum += l
        }
        val avgLuma = (sum / luma.size).toInt()

        // Find candidate bounding bounds of the high-contrast document region
        var minX = sw
        var maxX = 0
        var minY = sh
        var maxY = 0

        for (y in 0 until sh) {
            val row = y * sw
            for (x in 0 until sw) {
                // Documents are typically brighter than background
                if (luma[row + x] > avgLuma * 1.05f) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }

        val scaleX = w / sw.toFloat()
        val scaleY = h / sh.toFloat()

        // If high-contrast quad found, use it; otherwise default to 85% centered page quad
        val insetX = w * 0.08f
        val insetY = h * 0.08f

        val left = if (maxX > minX + 20) (minX * scaleX).coerceIn(insetX * 0.5f, w * 0.25f) else insetX
        val right = if (maxX > minX + 20) (maxX * scaleX).coerceIn(w * 0.75f, w - insetX * 0.5f) else w - insetX
        val top = if (maxY > minY + 20) (minY * scaleY).coerceIn(insetY * 0.5f, h * 0.25f) else insetY
        val bottom = if (maxY > minY + 20) (maxY * scaleY).coerceIn(h * 0.75f, h - insetY * 0.5f) else h - insetY

        return listOf(
            PointF(left, top),       // Top-Left
            PointF(right, top),      // Top-Right
            PointF(right, bottom),   // Bottom-Right
            PointF(left, bottom)     // Bottom-Left
        )
    }

    /**
     * Perspective warp from 4 corner points to a straight rectangular document.
     */
    fun perspectiveCrop(src: Bitmap, quad: List<PointF>): Bitmap {
        if (quad.size != 4) return src
        val tl = quad[0]
        val tr = quad[1]
        val br = quad[2]
        val bl = quad[3]

        // Compute output width & height from quad edge lengths
        val widthA = sqrt((br.x - bl.x) * (br.x - bl.x) + (br.y - bl.y) * (br.y - bl.y))
        val widthB = sqrt((tr.x - tl.x) * (tr.x - tl.x) + (tr.y - tl.y) * (tr.y - tl.y))
        val dstW = max(widthA, widthB).toInt().coerceAtLeast(200)

        val heightA = sqrt((tr.x - br.x) * (tr.x - br.x) + (tr.y - br.y) * (tr.y - br.y))
        val heightB = sqrt((tl.x - bl.x) * (tl.x - bl.x) + (tl.y - bl.y) * (tl.y - bl.y))
        val dstH = max(heightA, heightB).toInt().coerceAtLeast(200)

        val srcPoints = floatArrayOf(
            tl.x, tl.y,
            tr.x, tr.y,
            br.x, br.y,
            bl.x, bl.y
        )

        val dstPoints = floatArrayOf(
            0f, 0f,
            dstW.toFloat(), 0f,
            dstW.toFloat(), dstH.toFloat(),
            0f, dstH.toFloat()
        )

        val matrix = Matrix()
        matrix.setPolyToPoly(srcPoints, 0, dstPoints, 0, 4)

        val out = Bitmap.createBitmap(dstW, dstH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(src, matrix, paint)
        return out
    }

    /**
     * Shadow removal by dividing by blurred background illumination:
     * Removes desk shadows, arm shadows, and lighting unevenness.
     */
    fun removeShadowsAndProcess(src: Bitmap, mode: DocColorMode, brightness: Int = 0): Bitmap {
        val w = src.width
        val h = src.height

        if (mode == DocColorMode.ORIGINAL) {
            return src.copy(Bitmap.Config.ARGB_8888, true)
        }

        // Generate heavy blurred background illumination map
        val illumScale = 16
        val iw = max(1, w / illumScale)
        val ih = max(1, h / illumScale)
        val small = Bitmap.createScaledBitmap(src, iw, ih, true)
        val illum = Bitmap.createScaledBitmap(small, w, h, true)
        small.recycle()

        val pixels = IntArray(w)
        val illumPixels = IntArray(w)
        val outPixels = IntArray(w)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

        val brightOffset = brightness * 2

        for (y in 0 until h) {
            src.getPixels(pixels, 0, w, 0, y, w, 1)
            illum.getPixels(illumPixels, 0, w, 0, y, w, 1)

            for (x in 0 until w) {
                val p = pixels[x]
                val ip = illumPixels[x]

                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255

                val ir = max(1, (ip shr 16) and 255)
                val ig = max(1, (ip shr 8) and 255)
                val ib = max(1, ip and 255)

                // Divide by blurred background illumination to cancel shadows
                var flatR = ((r * 255) / ir + brightOffset).coerceIn(0, 255)
                var flatG = ((g * 255) / ig + brightOffset).coerceIn(0, 255)
                var flatB = ((b * 255) / ib + brightOffset).coerceIn(0, 255)

                when (mode) {
                    DocColorMode.COLOR -> {
                        // High-contrast color: boost text contrast while keeping color signatures/stamps
                        val luma = (77 * flatR + 150 * flatG + 29 * flatB) shr 8
                        if (luma > 210) {
                            flatR = 255; flatG = 255; flatB = 255
                        } else if (luma < 90) {
                            flatR = (flatR * 0.8f).toInt(); flatG = (flatG * 0.8f).toInt(); flatB = (flatB * 0.8f).toInt()
                        }
                    }
                    DocColorMode.GRAY -> {
                        val gray = ((77 * flatR + 150 * flatG + 29 * flatB) shr 8).coerceIn(0, 255)
                        flatR = gray; flatG = gray; flatB = gray
                    }
                    DocColorMode.BW -> {
                        // Adaptive threshold (never single global threshold)
                        val luma = (77 * flatR + 150 * flatG + 29 * flatB) shr 8
                        val v = if (luma < 175) 0 else 255
                        flatR = v; flatG = v; flatB = v
                    }
                    DocColorMode.ORIGINAL -> {}
                }

                outPixels[x] = (0xFF shl 24) or (flatR shl 16) or (flatG shl 8) or flatB
            }
            out.setPixels(outPixels, 0, w, 0, y, w, 1)
        }
        illum.recycle()
        return out
    }

    /**
     * Export all scanned document pages to a clean PDF document.
     */
    fun exportToPdf(context: Context, pages: List<Bitmap>): Uri? {
        if (pages.isEmpty()) return null

        val pdfDoc = PdfDocument()
        val name = "PROCAM_DOC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".pdf"

        try {
            for ((index, pageBitmap) in pages.withIndex()) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageBitmap.width, pageBitmap.height, index + 1).create()
                val page = pdfDoc.startPage(pageInfo)
                val canvas = page.canvas
                val paint = Paint(Paint.FILTER_BITMAP_FLAG)
                canvas.drawBitmap(pageBitmap, 0f, 0f, paint)
                pdfDoc.finishPage(page)
            }

            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Documents/ProCam")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = context.contentResolver.insert(MediaStore.Files.getContentUri("external"), values) ?: return null
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    pdfDoc.writeTo(out)
                }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                context.contentResolver.update(uri, done, null, null)
                pdfDoc.close()
                return uri
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "ProCam")
                dir.mkdirs()
                val file = File(dir, name)
                FileOutputStream(file).use { out -> pdfDoc.writeTo(out) }
                pdfDoc.close()
                return Uri.fromFile(file)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            try { pdfDoc.close() } catch (ignored: Exception) {}
            return null
        }
    }
}
