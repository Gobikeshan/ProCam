package com.example.procam

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

/**
 * Real-time RGB and Luma Histogram View for the Photo Editor.
 */
class HistogramView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val rHist = IntArray(256)
    private val gHist = IntArray(256)
    private val bHist = IntArray(256)
    private val lumaHist = IntArray(256)

    private val rPath = Path()
    private val gPath = Path()
    private val bPath = Path()
    private val lumaPath = Path()

    private val rPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x88FF4444.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }
    private val gPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x8800E676.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }
    private val bPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x882979FF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }
    private val lumaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAAFFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private val bgPaint = Paint().apply {
        color = 0x77000000.toInt()
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint().apply {
        color = 0x44FFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    fun updateHistogram(bitmap: Bitmap?) {
        if (bitmap == null || bitmap.isRecycled) return

        rHist.fill(0)
        gHist.fill(0)
        bHist.fill(0)
        lumaHist.fill(0)

        // Subsample bitmap for fast computation
        val stepX = max(1, bitmap.width / 160)
        val stepY = max(1, bitmap.height / 160)

        val w = bitmap.width
        val h = bitmap.height

        for (y in 0 until h step stepY) {
            for (x in 0 until w step stepX) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luma = (0.299f * r + 0.587f * g + 0.114f * b).toInt().coerceIn(0, 255)

                rHist[r]++
                gHist[g]++
                bHist[b]++
                lumaHist[luma]++
            }
        }

        buildPaths()
        postInvalidate()
    }

    private fun buildPaths() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        var maxCount = 1
        for (i in 0..255) {
            maxCount = max(maxCount, max(rHist[i], max(gHist[i], max(bHist[i], lumaHist[i]))))
        }

        fun makePath(hist: IntArray, path: Path) {
            path.reset()
            val step = w / 255f
            for (i in 0..255) {
                val x = i * step
                val y = h - (hist[i].toFloat() / maxCount * (h - 4f)) - 2f
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
        }

        makePath(rHist, rPath)
        makePath(gHist, gPath)
        makePath(bHist, bPath)
        makePath(lumaHist, lumaPath)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        buildPaths()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 8f, 8f, bgPaint)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 8f, 8f, borderPaint)

        canvas.drawPath(rPath, rPaint)
        canvas.drawPath(gPath, gPaint)
        canvas.drawPath(bPath, bPaint)
        canvas.drawPath(lumaPath, lumaPaint)
    }
}
