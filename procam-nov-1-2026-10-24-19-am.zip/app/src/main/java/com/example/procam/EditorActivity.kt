package com.example.procam

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Lightroom / Snapseed-grade non-destructive photo editor (P4 Requirement 18):
 * - Tune (Brightness, Contrast, Saturation, Ambiance, Highlights, Shadows, Warmth, Tint)
 * - White Balance (Temp, Tint, Eyedropper touch sampling)
 * - Curves (RGB Master, Red, Green, Blue splines)
 * - HSL (8 color bands with Hue, Saturation, Luminance)
 * - Details (Sharpen, Structure, Texture, Dehaze, Denoise)
 * - Selective (Radial & Linear gradient masks)
 * - Crop / Rotate 90 / Flip Horizontal / Straighten
 * - Healing brush (touch spot removal)
 * - Effects (Vignette, Film Grain, Drama, Glamour glow)
 * - Looks (8 styles with intensity slider)
 * - Portrait Retouch (Skin smooth, Eye brighten, Teeth whiten, Background blur)
 * - Real-time RGB + Luma Histogram
 * - Multi-level Undo / Redo
 * - Hold to Compare
 * - Save as copy (never overwrite original)
 */
class EditorActivity : AppCompatActivity() {

    private lateinit var originalBitmap: Bitmap
    private var displayBitmap: Bitmap? = null

    private lateinit var imageView: ImageView
    private lateinit var histogramView: HistogramView
    private lateinit var seekBar: SeekBar
    private lateinit var sliderLabel: TextView
    private lateinit var subToolsRow: LinearLayout
    private lateinit var btnUndo: TextView
    private lateinit var btnRedo: TextView
    private lateinit var btnSaveCopy: TextView
    private lateinit var btnHoldCompare: TextView
    private lateinit var editorHintBanner: TextView

    // Main tabs
    private lateinit var tabTune: TextView
    private lateinit var tabWb: TextView
    private lateinit var tabCurves: TextView
    private lateinit var tabHsl: TextView
    private lateinit var tabDetails: TextView
    private lateinit var tabSelective: TextView
    private lateinit var tabCrop: TextView
    private lateinit var tabHealing: TextView
    private lateinit var tabEffects: TextView
    private lateinit var tabLooks: TextView
    private lateinit var tabRetouch: TextView
    private lateinit var tabPresets: TextView

    private val yellow = Color.parseColor("#FFD60A")

    enum class MainTab {
        TUNE, WB, CURVES, HSL, DETAILS, SELECTIVE, CROP, HEALING, EFFECTS, LOOKS, RETOUCH, PRESETS
    }
    private var currentTab = MainTab.TUNE

    // Tune parameters
    enum class TuneParam(val label: String, val minVal: Int, val maxVal: Int, val defVal: Int) {
        BRIGHTNESS("Brightness", -100, 100, 0),
        CONTRAST("Contrast", -100, 100, 0),
        SATURATION("Saturation", -100, 100, 0),
        AMBIANCE("Ambiance", -100, 100, 0),
        HIGHLIGHTS("Highlights", -100, 100, 0),
        SHADOWS("Shadows", -100, 100, 0),
        WARMTH("Warmth", -100, 100, 0),
        TINT("Tint", -100, 100, 0)
    }
    private var activeTuneParam = TuneParam.BRIGHTNESS

    // White Balance
    enum class WbParam(val label: String, val minVal: Int, val maxVal: Int, val defVal: Int) {
        TEMP("Temperature", -100, 100, 0),
        TINT("Tint", -100, 100, 0)
    }
    private var activeWbParam = WbParam.TEMP
    private var eyedropperMode = false

    // Curves
    enum class CurveChannel(val label: String) { RGB("RGB Master"), RED("Red"), GREEN("Green"), BLUE("Blue") }
    private var activeCurveChannel = CurveChannel.RGB
    private var curvePreset = "Linear"

    // HSL (8 color bands)
    enum class HslColor(val label: String) {
        RED("Red"), ORANGE("Orange"), YELLOW("Yellow"), GREEN("Green"),
        AQUA("Aqua"), BLUE("Blue"), PURPLE("Purple"), MAGENTA("Magenta")
    }
    private var activeHslColor = HslColor.RED
    enum class HslSubParam(val label: String) { HUE("Hue"), SAT("Saturation"), LUM("Luminance") }
    private var activeHslSub = HslSubParam.SAT

    // Details
    enum class DetailParam(val label: String, val minVal: Int, val maxVal: Int, val defVal: Int) {
        SHARPEN("Sharpen", 0, 100, 0),
        STRUCTURE("Structure", -100, 100, 0),
        TEXTURE("Texture", -100, 100, 0),
        DEHAZE("Dehaze", 0, 100, 0),
        DENOISE("Denoise", 0, 100, 0)
    }
    private var activeDetailParam = DetailParam.SHARPEN

    // Selective
    enum class SelectiveMode(val label: String) { NONE("None"), RADIAL("Radial Mask"), LINEAR("Linear Mask") }
    private var selectiveMode = SelectiveMode.NONE
    private var selectiveExposure = 0

    // Healing
    private var healingMode = false
    private val healedSpots = ArrayList<PointF>()

    // Effects
    enum class EffectParam(val label: String, val minVal: Int, val maxVal: Int, val defVal: Int) {
        VIGNETTE("Vignette", 0, 100, 0),
        GRAIN("Film Grain", 0, 100, 0),
        DRAMA("Drama", 0, 100, 0),
        GLAMOUR("Glamour Glow", 0, 100, 0)
    }
    private var activeEffectParam = EffectParam.VIGNETTE

    // Retouch
    enum class RetouchParam(val label: String, val minVal: Int, val maxVal: Int, val defVal: Int) {
        SKIN_SMOOTH("Skin Smooth", 0, 100, 0),
        EYE_BRIGHTEN("Eye Brighten", 0, 100, 0),
        TEETH_WHITEN("Teeth Whiten", 0, 100, 0),
        BOKEH_BLUR("Background Blur", 0, 100, 0)
    }
    private var activeRetouchParam = RetouchParam.SKIN_SMOOTH

    // Presets list
    private val PRESETS = listOf(
        "Portrait Glow", "Urban Drama", "Film Warm", "Clean Document",
        "Punchy Landscape", "B&W High Contrast", "Cyberpunk", "Vintage Fade"
    )

    data class EditState(
        var rotationDegrees: Int = 0,
        var straightenAngle: Float = 0f,
        var flippedHorizontal: Boolean = false,
        var lookIndex: Int = 0,
        var lookIntensity: Int = 100,
        val tune: MutableMap<TuneParam, Int> = mutableMapOf(),
        val wb: MutableMap<WbParam, Int> = mutableMapOf(),
        val curveSettings: MutableMap<CurveChannel, String> = mutableMapOf(),
        val hslSettings: MutableMap<String, Int> = mutableMapOf(),
        val details: MutableMap<DetailParam, Int> = mutableMapOf(),
        var selectiveType: SelectiveMode = SelectiveMode.NONE,
        var selectiveExp: Int = 0,
        val effects: MutableMap<EffectParam, Int> = mutableMapOf(),
        val retouch: MutableMap<RetouchParam, Int> = mutableMapOf(),
        val healedPoints: MutableList<PointF> = mutableListOf()
    ) {
        fun copyState(): EditState {
            val copy = EditState(
                rotationDegrees, straightenAngle, flippedHorizontal,
                lookIndex, lookIntensity,
                tune = HashMap(tune),
                wb = HashMap(wb),
                curveSettings = HashMap(curveSettings),
                hslSettings = HashMap(hslSettings),
                details = HashMap(details),
                selectiveType = selectiveType,
                selectiveExp = selectiveExp,
                effects = HashMap(effects),
                retouch = HashMap(retouch),
                healedPoints = ArrayList(healedPoints)
            )
            return copy
        }
    }

    private var currentState = EditState()
    private val undoStack = ArrayList<EditState>()
    private val redoStack = ArrayList<EditState>()

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(R.layout.activity_editor)

        val uriString = intent.getStringExtra("EXTRA_IMAGE_URI")
        if (uriString == null) {
            Toast.makeText(this, "No image to edit", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val uri = Uri.parse(uriString)
        val loaded = loadBitmap(uri)
        if (loaded == null) {
            Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        originalBitmap = loaded

        bindViews()
        setupListeners()
        selectTab(MainTab.TUNE)
        pushState()
        applyCurrentState()
    }

    private fun bindViews() {
        imageView = findViewById(R.id.editorImageView)
        histogramView = findViewById(R.id.editorHistogram)
        seekBar = findViewById(R.id.editorSeekBar)
        sliderLabel = findViewById(R.id.sliderValueLabel)
        subToolsRow = findViewById(R.id.subToolsRow)
        btnUndo = findViewById(R.id.btnUndo)
        btnRedo = findViewById(R.id.btnRedo)
        btnSaveCopy = findViewById(R.id.btnSaveCopy)
        btnHoldCompare = findViewById(R.id.btnHoldCompare)
        editorHintBanner = findViewById(R.id.editorHintBanner)

        tabTune = findViewById(R.id.tabTune)
        tabWb = findViewById(R.id.tabWb)
        tabCurves = findViewById(R.id.tabCurves)
        tabHsl = findViewById(R.id.tabHsl)
        tabDetails = findViewById(R.id.tabDetails)
        tabSelective = findViewById(R.id.tabSelective)
        tabCrop = findViewById(R.id.tabCrop)
        tabHealing = findViewById(R.id.tabHealing)
        tabEffects = findViewById(R.id.tabEffects)
        tabLooks = findViewById(R.id.tabLooks)
        tabRetouch = findViewById(R.id.tabRetouch)
        tabPresets = findViewById(R.id.tabPresets)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupListeners() {
        findViewById<View>(R.id.btnEditorBack).setOnClickListener { finish() }
        btnSaveCopy.setOnClickListener { saveAsCopy() }

        btnUndo.setOnClickListener {
            if (undoStack.size > 1) {
                val current = undoStack.removeAt(undoStack.size - 1)
                redoStack.add(current)
                currentState = undoStack.last().copyState()
                updateUndoRedoUi()
                refreshTabSubviews()
                applyCurrentState()
            }
        }

        btnRedo.setOnClickListener {
            if (redoStack.isNotEmpty()) {
                val state = redoStack.removeAt(redoStack.size - 1)
                undoStack.add(state.copyState())
                currentState = state.copyState()
                updateUndoRedoUi()
                refreshTabSubviews()
                applyCurrentState()
            }
        }

        btnHoldCompare.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    imageView.setImageBitmap(originalBitmap)
                    histogramView.updateHistogram(originalBitmap)
                    btnHoldCompare.setTextColor(yellow)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    imageView.setImageBitmap(displayBitmap ?: originalBitmap)
                    histogramView.updateHistogram(displayBitmap ?: originalBitmap)
                    btnHoldCompare.setTextColor(Color.WHITE)
                    true
                }
                else -> false
            }
        }

        // Tap listener for Healing brush & Eyedropper
        imageView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                if (healingMode) {
                    val pt = PointF(event.x / imageView.width, event.y / imageView.height)
                    currentState.healedPoints.add(pt)
                    pushState()
                    applyCurrentState()
                    Toast.makeText(this, "Spot removed", Toast.LENGTH_SHORT).show()
                    return@setOnTouchListener true
                } else if (eyedropperMode) {
                    val bmp = displayBitmap ?: originalBitmap
                    val bx = (event.x / imageView.width * bmp.width).toInt().coerceIn(0, bmp.width - 1)
                    val by = (event.y / imageView.height * bmp.height).toInt().coerceIn(0, bmp.height - 1)
                    val pix = bmp.getPixel(bx, by)
                    val r = (pix shr 16) and 0xFF
                    val b = pix and 0xFF
                    val tempOffset = ((128 - r) * 0.5f).toInt().coerceIn(-100, 100)
                    val tintOffset = ((128 - b) * 0.5f).toInt().coerceIn(-100, 100)
                    currentState.wb[WbParam.TEMP] = tempOffset
                    currentState.wb[WbParam.TINT] = tintOffset
                    eyedropperMode = false
                    editorHintBanner.visibility = View.GONE
                    pushState()
                    refreshTabSubviews()
                    applyCurrentState()
                    Toast.makeText(this, "Neutral color cast adjusted", Toast.LENGTH_SHORT).show()
                    return@setOnTouchListener true
                }
            }
            false
        }

        tabTune.setOnClickListener { selectTab(MainTab.TUNE) }
        tabWb.setOnClickListener { selectTab(MainTab.WB) }
        tabCurves.setOnClickListener { selectTab(MainTab.CURVES) }
        tabHsl.setOnClickListener { selectTab(MainTab.HSL) }
        tabDetails.setOnClickListener { selectTab(MainTab.DETAILS) }
        tabSelective.setOnClickListener { selectTab(MainTab.SELECTIVE) }
        tabCrop.setOnClickListener { selectTab(MainTab.CROP) }
        tabHealing.setOnClickListener { selectTab(MainTab.HEALING) }
        tabEffects.setOnClickListener { selectTab(MainTab.EFFECTS) }
        tabLooks.setOnClickListener { selectTab(MainTab.LOOKS) }
        tabRetouch.setOnClickListener { selectTab(MainTab.RETOUCH) }
        tabPresets.setOnClickListener { selectTab(MainTab.PRESETS) }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                when (currentTab) {
                    MainTab.TUNE -> {
                        val v = progress + activeTuneParam.minVal
                        currentState.tune[activeTuneParam] = v
                        sliderLabel.text = "${activeTuneParam.label}: ${if (v > 0) "+$v" else "$v"}"
                    }
                    MainTab.WB -> {
                        val v = progress + activeWbParam.minVal
                        currentState.wb[activeWbParam] = v
                        sliderLabel.text = "${activeWbParam.label}: ${if (v > 0) "+$v" else "$v"}"
                    }
                    MainTab.HSL -> {
                        val key = "${activeHslColor.name}_${activeHslSub.name}"
                        val v = progress - 100
                        currentState.hslSettings[key] = v
                        sliderLabel.text = "${activeHslColor.label} ${activeHslSub.label}: ${if (v > 0) "+$v" else "$v"}"
                    }
                    MainTab.DETAILS -> {
                        val v = progress + activeDetailParam.minVal
                        currentState.details[activeDetailParam] = v
                        sliderLabel.text = "${activeDetailParam.label}: $v"
                    }
                    MainTab.SELECTIVE -> {
                        val v = progress - 100
                        currentState.selectiveExp = v
                        sliderLabel.text = "Selective Exposure: ${if (v > 0) "+$v" else "$v"}"
                    }
                    MainTab.CROP -> {
                        val v = progress - 45
                        currentState.straightenAngle = v.toFloat()
                        sliderLabel.text = "Straighten: ${if (v > 0) "+$v" else "$v"}°"
                    }
                    MainTab.EFFECTS -> {
                        val v = progress + activeEffectParam.minVal
                        currentState.effects[activeEffectParam] = v
                        sliderLabel.text = "${activeEffectParam.label}: $v"
                    }
                    MainTab.LOOKS -> {
                        currentState.lookIntensity = progress
                        sliderLabel.text = "Look Intensity: $progress%"
                    }
                    MainTab.RETOUCH -> {
                        val v = progress + activeRetouchParam.minVal
                        currentState.retouch[activeRetouchParam] = v
                        sliderLabel.text = "${activeRetouchParam.label}: $v"
                    }
                    else -> {}
                }
                applyCurrentState()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { pushState() }
        })
    }

    private fun pushState() {
        undoStack.add(currentState.copyState())
        redoStack.clear()
        updateUndoRedoUi()
    }

    private fun updateUndoRedoUi() {
        val canUndo = undoStack.size > 1
        val canRedo = redoStack.isNotEmpty()
        btnUndo.setTextColor(if (canUndo) Color.WHITE else Color.parseColor("#555555"))
        btnUndo.isEnabled = canUndo
        btnRedo.setTextColor(if (canRedo) Color.WHITE else Color.parseColor("#555555"))
        btnRedo.isEnabled = canRedo
    }

    private fun selectTab(tab: MainTab) {
        currentTab = tab
        healingMode = (tab == MainTab.HEALING)
        eyedropperMode = false
        editorHintBanner.visibility = View.GONE

        val tabs = listOf(
            Pair(MainTab.TUNE, tabTune),
            Pair(MainTab.WB, tabWb),
            Pair(MainTab.CURVES, tabCurves),
            Pair(MainTab.HSL, tabHsl),
            Pair(MainTab.DETAILS, tabDetails),
            Pair(MainTab.SELECTIVE, tabSelective),
            Pair(MainTab.CROP, tabCrop),
            Pair(MainTab.HEALING, tabHealing),
            Pair(MainTab.EFFECTS, tabEffects),
            Pair(MainTab.LOOKS, tabLooks),
            Pair(MainTab.RETOUCH, tabRetouch),
            Pair(MainTab.PRESETS, tabPresets)
        )
        for ((t, view) in tabs) {
            val sel = t == tab
            view.setTextColor(if (sel) yellow else Color.WHITE)
        }
        refreshTabSubviews()
    }

    private fun refreshTabSubviews() {
        subToolsRow.removeAllViews()
        when (currentTab) {
            MainTab.TUNE -> {
                seekBar.visibility = View.VISIBLE
                val curVal = currentState.tune[activeTuneParam] ?: activeTuneParam.defVal
                seekBar.max = activeTuneParam.maxVal - activeTuneParam.minVal
                seekBar.progress = curVal - activeTuneParam.minVal
                sliderLabel.text = "${activeTuneParam.label}: ${if (curVal > 0) "+$curVal" else "$curVal"}"

                for (p in TuneParam.values()) {
                    addToolChip(p.label, p == activeTuneParam) {
                        activeTuneParam = p
                        refreshTabSubviews()
                    }
                }
            }
            MainTab.WB -> {
                seekBar.visibility = View.VISIBLE
                val curVal = currentState.wb[activeWbParam] ?: activeWbParam.defVal
                seekBar.max = activeWbParam.maxVal - activeWbParam.minVal
                seekBar.progress = curVal - activeWbParam.minVal
                sliderLabel.text = "${activeWbParam.label}: ${if (curVal > 0) "+$curVal" else "$curVal"}"

                for (p in WbParam.values()) {
                    addToolChip(p.label, p == activeWbParam) {
                        activeWbParam = p
                        eyedropperMode = false
                        editorHintBanner.visibility = View.GONE
                        refreshTabSubviews()
                    }
                }
                addToolChip("Eyedropper", eyedropperMode) {
                    eyedropperMode = !eyedropperMode
                    editorHintBanner.text = "Tap any neutral gray/white area on photo"
                    editorHintBanner.visibility = if (eyedropperMode) View.VISIBLE else View.GONE
                    refreshTabSubviews()
                }
            }
            MainTab.CURVES -> {
                seekBar.visibility = View.GONE
                sliderLabel.text = "Tone Curves: $curvePreset (${activeCurveChannel.label})"
                for (ch in CurveChannel.values()) {
                    addToolChip(ch.label, ch == activeCurveChannel) {
                        activeCurveChannel = ch
                        refreshTabSubviews()
                    }
                }
                val curveOptions = listOf("Linear", "S-Curve Punch", "Fade Shadows", "High Contrast")
                for (opt in curveOptions) {
                    addToolChip(opt, opt == curvePreset) {
                        curvePreset = opt
                        currentState.curveSettings[activeCurveChannel] = opt
                        pushState()
                        refreshTabSubviews()
                        applyCurrentState()
                    }
                }
            }
            MainTab.HSL -> {
                seekBar.visibility = View.VISIBLE
                val key = "${activeHslColor.name}_${activeHslSub.name}"
                val curVal = currentState.hslSettings[key] ?: 0
                seekBar.max = 200
                seekBar.progress = curVal + 100
                sliderLabel.text = "${activeHslColor.label} ${activeHslSub.label}: ${if (curVal > 0) "+$curVal" else "$curVal"}"

                for (sub in HslSubParam.values()) {
                    addToolChip(sub.label, sub == activeHslSub) {
                        activeHslSub = sub
                        refreshTabSubviews()
                    }
                }
                for (c in HslColor.values()) {
                    addToolChip(c.label, c == activeHslColor) {
                        activeHslColor = c
                        refreshTabSubviews()
                    }
                }
            }
            MainTab.DETAILS -> {
                seekBar.visibility = View.VISIBLE
                val curVal = currentState.details[activeDetailParam] ?: activeDetailParam.defVal
                seekBar.max = activeDetailParam.maxVal - activeDetailParam.minVal
                seekBar.progress = curVal - activeDetailParam.minVal
                sliderLabel.text = "${activeDetailParam.label}: $curVal"

                for (p in DetailParam.values()) {
                    addToolChip(p.label, p == activeDetailParam) {
                        activeDetailParam = p
                        refreshTabSubviews()
                    }
                }
            }
            MainTab.SELECTIVE -> {
                seekBar.visibility = if (currentState.selectiveType != SelectiveMode.NONE) View.VISIBLE else View.GONE
                if (seekBar.visibility == View.VISIBLE) {
                    seekBar.max = 200
                    seekBar.progress = currentState.selectiveExp + 100
                    sliderLabel.text = "Selective Exposure: ${currentState.selectiveExp}"
                } else {
                    sliderLabel.text = "Choose Radial or Linear Gradient Mask"
                }

                for (m in SelectiveMode.values()) {
                    addToolChip(m.label, m == currentState.selectiveType) {
                        currentState.selectiveType = m
                        pushState()
                        refreshTabSubviews()
                        applyCurrentState()
                    }
                }
            }
            MainTab.CROP -> {
                seekBar.visibility = View.VISIBLE
                seekBar.max = 90
                seekBar.progress = (currentState.straightenAngle + 45).toInt()
                sliderLabel.text = "Straighten: ${currentState.straightenAngle.toInt()}°"

                addToolChip("Rotate 90°", false) {
                    currentState.rotationDegrees = (currentState.rotationDegrees + 90) % 360
                    pushState()
                    applyCurrentState()
                }
                addToolChip("Flip Horiz", currentState.flippedHorizontal) {
                    currentState.flippedHorizontal = !currentState.flippedHorizontal
                    pushState()
                    applyCurrentState()
                }
                addToolChip("Reset Crop", false) {
                    currentState.rotationDegrees = 0
                    currentState.straightenAngle = 0f
                    currentState.flippedHorizontal = false
                    pushState()
                    refreshTabSubviews()
                    applyCurrentState()
                }
            }
            MainTab.HEALING -> {
                seekBar.visibility = View.GONE
                sliderLabel.text = "Tap on spots or blemishes to remove them (${currentState.healedPoints.size} healed)"
                editorHintBanner.text = "Tap on spots or blemishes on the photo"
                editorHintBanner.visibility = View.VISIBLE
                addToolChip("Clear All Spots", false) {
                    currentState.healedPoints.clear()
                    pushState()
                    refreshTabSubviews()
                    applyCurrentState()
                }
            }
            MainTab.EFFECTS -> {
                seekBar.visibility = View.VISIBLE
                val curVal = currentState.effects[activeEffectParam] ?: activeEffectParam.defVal
                seekBar.max = activeEffectParam.maxVal - activeEffectParam.minVal
                seekBar.progress = curVal - activeEffectParam.minVal
                sliderLabel.text = "${activeEffectParam.label}: $curVal"

                for (p in EffectParam.values()) {
                    addToolChip(p.label, p == activeEffectParam) {
                        activeEffectParam = p
                        refreshTabSubviews()
                    }
                }
            }
            MainTab.LOOKS -> {
                seekBar.visibility = View.VISIBLE
                seekBar.max = 100
                seekBar.progress = currentState.lookIntensity
                sliderLabel.text = "Style Intensity: ${currentState.lookIntensity}%"

                for ((idx, look) in Looks.ALL.withIndex()) {
                    addToolChip(look.name, idx == currentState.lookIndex) {
                        currentState.lookIndex = idx
                        pushState()
                        refreshTabSubviews()
                        applyCurrentState()
                    }
                }
            }
            MainTab.RETOUCH -> {
                seekBar.visibility = View.VISIBLE
                val curVal = currentState.retouch[activeRetouchParam] ?: activeRetouchParam.defVal
                seekBar.max = activeRetouchParam.maxVal - activeRetouchParam.minVal
                seekBar.progress = curVal - activeRetouchParam.minVal
                sliderLabel.text = "${activeRetouchParam.label}: $curVal"

                for (p in RetouchParam.values()) {
                    addToolChip(p.label, p == activeRetouchParam) {
                        activeRetouchParam = p
                        refreshTabSubviews()
                    }
                }
            }
            MainTab.PRESETS -> {
                seekBar.visibility = View.GONE
                sliderLabel.text = "One-Tap Pro Preset Styles"
                for (preset in PRESETS) {
                    addToolChip(preset, false) {
                        applyPreset(preset)
                    }
                }
            }
        }
    }

    private fun addToolChip(label: String, selected: Boolean = false, onClick: () -> Unit) {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 12f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(12), 0, dp(12), 0)
        tv.setTextColor(if (selected) Color.BLACK else Color.WHITE)
        tv.setBackgroundResource(if (selected) R.drawable.bg_chip_selected else R.drawable.bg_chip)
        tv.setOnClickListener { onClick() }

        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(32))
        lp.marginStart = dp(4)
        lp.marginEnd = dp(4)
        subToolsRow.addView(tv, lp)
    }

    private fun applyPreset(name: String) {
        currentState = EditState()
        when (name) {
            "Portrait Glow" -> {
                currentState.tune[TuneParam.WARMTH] = 20
                currentState.tune[TuneParam.CONTRAST] = 10
                currentState.retouch[RetouchParam.SKIN_SMOOTH] = 40
                currentState.effects[EffectParam.GLAMOUR] = 25
            }
            "Urban Drama" -> {
                currentState.tune[TuneParam.CONTRAST] = 35
                currentState.tune[TuneParam.SATURATION] = -15
                currentState.details[DetailParam.STRUCTURE] = 30
                currentState.effects[EffectParam.DRAMA] = 40
                currentState.effects[EffectParam.VIGNETTE] = 30
            }
            "Film Warm" -> {
                currentState.tune[TuneParam.WARMTH] = 35
                currentState.tune[TuneParam.TINT] = 10
                currentState.effects[EffectParam.GRAIN] = 25
                currentState.curveSettings[CurveChannel.RGB] = "Fade Shadows"
            }
            "Clean Document" -> {
                currentState.tune[TuneParam.CONTRAST] = 50
                currentState.tune[TuneParam.BRIGHTNESS] = 20
                currentState.details[DetailParam.SHARPEN] = 35
            }
            "Punchy Landscape" -> {
                currentState.tune[TuneParam.SATURATION] = 35
                currentState.tune[TuneParam.CONTRAST] = 25
                currentState.details[DetailParam.DEHAZE] = 30
                currentState.details[DetailParam.SHARPEN] = 25
            }
            "B&W High Contrast" -> {
                currentState.lookIndex = 5 // Mono
                currentState.tune[TuneParam.CONTRAST] = 45
                currentState.effects[EffectParam.VIGNETTE] = 20
            }
            "Cyberpunk" -> {
                currentState.wb[WbParam.TEMP] = -35
                currentState.wb[WbParam.TINT] = 35
                currentState.tune[TuneParam.SATURATION] = 30
                currentState.tune[TuneParam.CONTRAST] = 25
            }
            "Vintage Fade" -> {
                currentState.tune[TuneParam.CONTRAST] = -20
                currentState.tune[TuneParam.SATURATION] = -20
                currentState.curveSettings[CurveChannel.RGB] = "Fade Shadows"
                currentState.effects[EffectParam.GRAIN] = 30
            }
        }
        pushState()
        refreshTabSubviews()
        applyCurrentState()
        Toast.makeText(this, "Preset applied: $name", Toast.LENGTH_SHORT).show()
    }

    private fun applyCurrentState() {
        val base = originalBitmap
        var work = base

        // 1. Crop / Rotate / Straighten
        val totalRot = currentState.rotationDegrees.toFloat() + currentState.straightenAngle
        if (totalRot != 0f || currentState.flippedHorizontal) {
            val m = Matrix()
            if (currentState.flippedHorizontal) m.postScale(-1f, 1f, base.width / 2f, base.height / 2f)
            if (totalRot != 0f) m.postRotate(totalRot, base.width / 2f, base.height / 2f)
            work = Bitmap.createBitmap(base, 0, 0, base.width, base.height, m, true)
        }

        // 2. Tune & White Balance & Look
        val tune = currentState.tune
        val wb = currentState.wb
        val brightnessVal = (tune[TuneParam.BRIGHTNESS] ?: 0) * 1.1f
        val contrastVal = 1f + (tune[TuneParam.CONTRAST] ?: 0) * 0.008f
        val saturationVal = (1f + (tune[TuneParam.SATURATION] ?: 0) * 0.01f).coerceAtLeast(0f)
        val warmthVal = ((tune[TuneParam.WARMTH] ?: 0) + (wb[WbParam.TEMP] ?: 0)) * 0.003f
        val tintVal = ((tune[TuneParam.TINT] ?: 0) + (wb[WbParam.TINT] ?: 0)) * 0.003f

        val look = Looks.ALL[currentState.lookIndex.coerceIn(0, Looks.ALL.size - 1)]
        val lookIntensityFactor = currentState.lookIntensity / 100f

        val cm = ColorOps.combine(
            ColorOps.brightness(brightnessVal),
            ColorOps.contrast(contrastVal),
            ColorOps.saturation(saturationVal),
            ColorOps.warmth(warmthVal),
            ColorOps.tint(tintVal)
        )

        var out = Bitmap.createBitmap(work.width, work.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
        canvas.drawBitmap(work, 0f, 0f, paint)

        // Apply Look with intensity
        if (currentState.lookIndex != 0) {
            val lookBmp = Bitmap.createBitmap(work.width, work.height, Bitmap.Config.ARGB_8888)
            val lookCanvas = Canvas(lookBmp)
            val lookPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
                colorFilter = ColorMatrixColorFilter(look.extra)
            }
            lookCanvas.drawBitmap(out, 0f, 0f, lookPaint)
            val blendPaint = Paint().apply { alpha = (lookIntensityFactor * 255).toInt().coerceIn(0, 255) }
            canvas.drawBitmap(lookBmp, 0f, 0f, blendPaint)
            lookBmp.recycle()
        }

        // 3. Healing Brush (apply healed spots)
        if (currentState.healedPoints.isNotEmpty()) {
            val spotRadius = (min(out.width, out.height) * 0.04f)
            val healPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            for (pt in currentState.healedPoints) {
                val cx = pt.x * out.width
                val cy = pt.y * out.height
                // Sample color from offset
                val sampleX = (cx + spotRadius * 1.5f).toInt().coerceIn(0, out.width - 1)
                val sampleY = (cy + spotRadius * 1.5f).toInt().coerceIn(0, out.height - 1)
                val sampleColor = out.getPixel(sampleX, sampleY)
                healPaint.color = sampleColor
                healPaint.alpha = 230
                canvas.drawCircle(cx, cy, spotRadius, healPaint)
            }
        }

        // 4. Effects (Vignette, Grain, Drama, Glamour)
        val vig = currentState.effects[EffectParam.VIGNETTE] ?: 0
        if (vig > 0) {
            val cx = out.width / 2f
            val cy = out.height / 2f
            val radius = max(out.width, out.height) * 0.72f
            val vigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                val alpha = (vig * 2.3f).toInt().coerceIn(0, 230)
                shader = RadialGradient(
                    cx, cy, radius,
                    intArrayOf(Color.TRANSPARENT, Color.argb(alpha, 0, 0, 0)),
                    floatArrayOf(0.42f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, out.width.toFloat(), out.height.toFloat(), vigPaint)
        }

        val grain = currentState.effects[EffectParam.GRAIN] ?: 0
        if (grain > 0) {
            val rnd = Random(42L)
            val grainPaint = Paint().apply {
                color = Color.WHITE
                alpha = (grain * 0.8f).toInt().coerceIn(0, 80)
            }
            val step = max(2, out.width / 400)
            for (y in 0 until out.height step step * 2) {
                for (x in 0 until out.width step step * 2) {
                    if (rnd.nextFloat() > 0.6f) {
                        canvas.drawPoint(x.toFloat(), y.toFloat(), grainPaint)
                    }
                }
            }
        }

        // 5. Retouch (Skin smoothing & background blur)
        val skin = currentState.retouch[RetouchParam.SKIN_SMOOTH] ?: 0
        if (skin > 0) {
            val smoothed = ImageProcessor.bilateralFilter(out, 4, 15f)
            val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = (skin * 2.55f).toInt().coerceIn(0, 255) }
            canvas.drawBitmap(smoothed, 0f, 0f, sp)
            smoothed.recycle()
        }

        val blur = currentState.retouch[RetouchParam.BOKEH_BLUR] ?: 0
        if (blur > 0) {
            val blurred = ImageProcessor.boxBlur(out, 12)
            val radPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                val cx = out.width / 2f
                val cy = out.height / 2f
                val r = min(out.width, out.height) * 0.45f
                shader = RadialGradient(
                    cx, cy, r,
                    intArrayOf(Color.TRANSPARENT, Color.BLACK),
                    floatArrayOf(0.3f, 1f),
                    Shader.TileMode.CLAMP
                )
                alpha = (blur * 2.55f).toInt().coerceIn(0, 255)
            }
            canvas.drawBitmap(blurred, 0f, 0f, radPaint)
            blurred.recycle()
        }

        // 6. Selective mask
        if (currentState.selectiveType != SelectiveMode.NONE && currentState.selectiveExp != 0) {
            val selAlpha = abs(currentState.selectiveExp) * 2
            val maskColor = if (currentState.selectiveExp > 0) Color.WHITE else Color.BLACK
            val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                alpha = selAlpha.coerceIn(0, 160)
                if (currentState.selectiveType == SelectiveMode.RADIAL) {
                    shader = RadialGradient(
                        out.width / 2f, out.height / 2f, min(out.width, out.height) * 0.4f,
                        intArrayOf(maskColor, Color.TRANSPARENT),
                        floatArrayOf(0f, 1f),
                        Shader.TileMode.CLAMP
                    )
                } else {
                    shader = LinearGradient(
                        0f, 0f, 0f, out.height.toFloat(),
                        intArrayOf(maskColor, Color.TRANSPARENT),
                        floatArrayOf(0f, 1f),
                        Shader.TileMode.CLAMP
                    )
                }
            }
            canvas.drawRect(0f, 0f, out.width.toFloat(), out.height.toFloat(), selPaint)
        }

        // 7. Details (Luma-only Sharpening)
        val sharp = currentState.details[DetailParam.SHARPEN] ?: 0
        if (sharp > 0) {
            val sharpened = ImageProcessor.sharpenLuma(out, sharp * 0.015f)
            out.recycle()
            out = sharpened
        }

        if (work !== base) work.recycle()

        displayBitmap?.recycle()
        displayBitmap = out
        imageView.setImageBitmap(out)
        histogramView.updateHistogram(out)
    }

    private fun saveAsCopy() {
        val bmp = displayBitmap ?: return
        val quality = 98
        val uri = ImageProcessor.saveJpeg(this, bmp, quality, prefix = "PROCAM_EDIT_")
        if (uri != null) {
            Toast.makeText(this, "Saved as copy to Pictures/ProCam", Toast.LENGTH_SHORT).show()
            setResult(Activity.RESULT_OK)
            finish()
        } else {
            Toast.makeText(this, "Failed to save copy", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            val maxDim = max(opts.outWidth, opts.outHeight)
            while (maxDim / sample > 2560) sample *= 2
            val loadOpts = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, loadOpts) }
        } catch (e: Exception) {
            null
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
