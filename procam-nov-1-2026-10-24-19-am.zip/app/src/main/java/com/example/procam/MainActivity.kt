package com.example.procam

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.media.MediaActionSound
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import android.os.Vibrator
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), SensorEventListener {

    enum class Mode { PHOTO, VIDEO, PORTRAIT, NIGHT, PRO, MORE, PANORAMA, SPHERE, DUAL, DOC, QR }

    private val yellow = Color.parseColor("#FFD60A")

    private lateinit var prefs: Prefs
    private lateinit var profile: DeviceProfile

    // Views
    private lateinit var previewView: PreviewView
    private lateinit var livePortraitOverlay: ImageView
    private lateinit var gridOverlay: GridOverlay
    private lateinit var focusRing: View
    private lateinit var shutterFlash: View
    private lateinit var statusContainer: View
    private lateinit var statusText: TextView
    private lateinit var nightProgressBar: ProgressBar
    private lateinit var countdownText: TextView
    private lateinit var peopleCountChip: TextView
    private lateinit var portraitBadge: TextView
    private lateinit var btnFlash: TextView
    private lateinit var btnTimer: TextView
    private lateinit var btnRatio: TextView
    private lateinit var btnGrid: TextView
    private lateinit var btnLooks: TextView
    private lateinit var btnEnhance: TextView
    private lateinit var btnFps: TextView
    private lateinit var btnSettings: TextView
    private lateinit var exposureBar: SeekBar
    private lateinit var portraitBlurContainer: View
    private lateinit var blurLabel: TextView
    private lateinit var portraitBlurSeekBar: SeekBar
    private lateinit var proControlsContainer: View
    private lateinit var proValuesScroll: HorizontalScrollView
    private lateinit var proValuesRow: LinearLayout
    private lateinit var proTabIso: TextView
    private lateinit var proTabShutter: TextView
    private lateinit var proTabWb: TextView
    private lateinit var proTabFocus: TextView
    private lateinit var proTabEv: TextView
    private lateinit var proTabRaw: TextView
    private lateinit var looksScroll: HorizontalScrollView
    private lateinit var looksRow: LinearLayout
    private lateinit var zoomDial: ZoomDialView
    private lateinit var zoomBar: LinearLayout
    private lateinit var modeBar: LinearLayout
    private lateinit var thumbnail: ImageView
    private lateinit var shutterButton: FrameLayout
    private lateinit var shutterInner: View
    private lateinit var btnFlip: ImageView
    private lateinit var btnPause: ImageView
    private lateinit var btnPhotoWhileVideo: ImageView

    // MORE modes UI
    private lateinit var moreSheetContainer: View
    private lateinit var dualPipContainer: View
    private lateinit var dualPipPreview: PreviewView
    private lateinit var qrResultContainer: View
    private lateinit var qrContentText: TextView
    private var tileDualCamera: View? = null

    private val modeViews = LinkedHashMap<Mode, TextView>()
    private val zoomChips = ArrayList<Pair<Float, TextView>>()
    private val lookChips = ArrayList<TextView>()

    // CameraX
    private var cameraProvider: ProcessCameraProvider? = null
    private var extensionsManager: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    // Sensors
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null
    private var gyroscope: Sensor? = null
    private var rotationVector: Sensor? = null

    // Gyro shake gating state
    private var gyroSpeed: Float = 0f
    private var calmTimestamp: Long = 0L
    private var isTripod: Boolean = false

    // State
    private var mode = Mode.PHOTO
    private var lensFront = false
    private var ratioMode = 0 // 0 = 4:3, 1 = 16:9, 2 = 1:1
    private var flashIndex = 0 // 0 off, 1 auto, 2 on, 3 torch
    private var timerSeconds = 0
    private var lookIndex = 0
    private var expMin = 0
    private var countdownLeft = 0
    private var countdownRunning = false
    private var nightBusy = false
    private var paused = false
    private var pending = 0
    private var settingsOpened = false
    private var is60FpsSupported = false
    private var currentFps60 = false
    private var isRawSupported = false
    private var isConcurrentSupported = false
    private var lastUri: Uri? = null
    private var lastMime = "image/jpeg"
    private var lastTapPoint: PointF? = null

    // Video multi-segment concatenation (flipping camera while recording)
    private var isFlippingVideo = false
    private val recordedVideoSegments = ArrayList<File>()

    // Panorama & Photo Sphere modes state
    private var panoCapturing = false
    private val panoStrips = ArrayList<Bitmap>()
    private var panoStartAngle = 0f
    private var lastPanoYaw = 0f
    private var sphereCapturing = false
    private val sphereCaptures = ArrayList<Bitmap>()
    private val sphereTargets = ArrayList<SphereTarget>()
    private var currentPitch = 0f
    private var currentYaw = 0f

    // Pro Mode Manual Settings
    private enum class ProTab { ISO, SHUTTER, WB, FOCUS, EV }
    private var activeProTab = ProTab.ISO
    private var manualIso = 0 // 0 = Auto
    private var manualShutterNs = 0L // 0 = Auto
    private var manualWb = 0 // 0 = Auto
    private var manualFocusDistance = -1f // -1 = Auto AF
    private var manualEv = 0f

    private val handler = Handler(Looper.getMainLooper())
    private val captureExecutor = Executors.newSingleThreadExecutor()
    private val processExecutor = Executors.newSingleThreadExecutor()
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val sound = MediaActionSound()

    // ML Kit Detectors
    private val liveFaceDetector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .enableTracking()
            .build()
        FaceDetection.getClient(options)
    }

    private val barcodeScanner by lazy {
        BarcodeScanning.getClient()
    }

    private val liveSegmenter by lazy {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
            .build()
        Segmentation.getClient(options)
    }

    private val qrImagePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                val inputImage = InputImage.fromFilePath(this, uri)
                barcodeScanner.process(inputImage)
                    .addOnSuccessListener { barcodes ->
                        if (barcodes.isNotEmpty()) {
                            val raw = barcodes[0].rawValue ?: barcodes[0].displayValue ?: ""
                            if (raw.isNotEmpty()) showQrActionSheet(raw)
                        } else {
                            toast("No QR code found in selected image")
                        }
                    }
                    .addOnFailureListener { toast("Error reading image") }
            } catch (e: Exception) {
                toast("Could not open image")
            }
        }
    }

    private var lastFaceMeteringTime = 0L

    private val hideExposure = Runnable { exposureBar.visibility = View.GONE }

    private val countdownTick = object : Runnable {
        override fun run() {
            if (countdownLeft > 0) {
                countdownText.text = countdownLeft.toString()
                countdownLeft--
                handler.postDelayed(this, 1000)
            } else {
                countdownRunning = false
                countdownText.visibility = View.GONE
                capture()
            }
        }
    }

    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            loadLastMedia()
        }
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.CAMERA] == true) {
            startCamera()
        } else {
            toast("Camera permission is required")
            finish()
        }
    }

    // ------------------------------------------------------------------ Setup
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        profile = Profiles.resolve(this, prefs.profileKey)
        lookIndex = prefs.lookIndex.coerceIn(0, Looks.ALL.size - 1)
        currentFps60 = prefs.videoFps60

        bindViews()
        initSensors()
        initSphereTargets()

        sound.load(MediaActionSound.SHUTTER_CLICK)
        sound.load(MediaActionSound.START_VIDEO_RECORDING)
        sound.load(MediaActionSound.STOP_VIDEO_RECORDING)

        setupTopBar()
        setupModeBar()
        setupLooks()
        setupPortraitControls()
        setupProControls()
        setupZoomDial()
        setupGestures()
        setupControls()
        setupMoreModes()
        layoutPreview()
        refreshAll()
        loadLastMedia()

        val needed = ArrayList<String>()
        needed.add(Manifest.permission.CAMERA)
        needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (needed.all { hasPerm(it) }) startCamera() else permLauncher.launch(needed.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        sensorManager?.let { sm ->
            accelerometer?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
            gyroscope?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
            rotationVector?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        }
        if (settingsOpened) {
            settingsOpened = false
            profile = Profiles.resolve(this, prefs.profileKey)
            currentFps60 = prefs.videoFps60
            refreshAll()
            if (cameraProvider != null && recording == null) bindCamera()
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager?.unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        captureExecutor.shutdown()
        processExecutor.shutdown()
        analysisExecutor.shutdown()
        sound.release()
    }

    private fun initSensors() {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyroscope = sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        rotationVector = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    }

    private fun initSphereTargets() {
        sphereTargets.clear()
        // 16 points: horizon (6), pitch +35 (4), pitch -35 (4), zenith +85 (1), nadir -85 (1)
        val pitches = listOf(
            0f, 0f, 0f, 0f, 0f, 0f,
            35f, 35f, 35f, 35f,
            -35f, -35f, -35f, -35f,
            85f, -85f
        )
        val yaws = listOf(
            0f, 60f, 120f, 180f, 240f, 300f,
            45f, 135f, 225f, 315f,
            45f, 135f, 225f, 315f,
            0f, 0f
        )
        for (i in pitches.indices) {
            sphereTargets.add(SphereTarget(pitches[i], yaws[i]))
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                if (prefs.levelLine) {
                    val ax = event.values[0]
                    val ay = event.values[1]
                    val rollDegrees = Math.toDegrees(atan2(ax.toDouble(), ay.toDouble())).toFloat()
                    var normRoll = rollDegrees
                    while (normRoll > 45f) normRoll -= 90f
                    while (normRoll < -45f) normRoll += 90f
                    gridOverlay.updateOrientation(normRoll)
                }
            }
            Sensor.TYPE_GYROSCOPE -> {
                val gx = event.values[0]
                val gy = event.values[1]
                val gz = event.values[2]
                gyroSpeed = sqrt(gx * gx + gy * gy + gz * gz)

                // Gyroscope shake gating
                val isShaky = gyroSpeed > 0.35f
                if (prefs.gyroShakeGating && isShaky && (mode == Mode.NIGHT || mode == Mode.PHOTO)) {
                    gridOverlay.showHoldSteady = true
                } else {
                    gridOverlay.showHoldSteady = false
                }

                // Tripod detection: speed < 0.04 rad/s for > 1.2s
                val now = System.currentTimeMillis()
                if (gyroSpeed < 0.04f) {
                    if (calmTimestamp == 0L) calmTimestamp = now
                    else if (now - calmTimestamp > 1200L) isTripod = true
                } else {
                    calmTimestamp = 0L
                    isTripod = false
                }
            }
            Sensor.TYPE_ROTATION_VECTOR -> {
                val rotationMatrix = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                val orientation = FloatArray(3)
                SensorManager.getOrientation(rotationMatrix, orientation)
                // Pitch & Yaw in degrees
                currentPitch = Math.toDegrees(orientation[1].toDouble()).toFloat()
                currentYaw = Math.toDegrees(orientation[0].toDouble()).toFloat()

                if (mode == Mode.SPHERE && sphereCapturing) {
                    gridOverlay.updateSphere(sphereTargets, currentPitch, currentYaw)
                    checkSphereAutoCapture()
                } else if (mode == Mode.PANORAMA && panoCapturing) {
                    var diffAngle = currentYaw - panoStartAngle
                    while (diffAngle < 0f) diffAngle += 360f
                    val progress = (diffAngle / 140f).coerceIn(0f, 1f)
                    val isLevel = abs(currentPitch) < 8f
                    gridOverlay.updatePanorama(diffAngle, progress, isLevel)

                    if (gyroSpeed > 0.40f) {
                        setStatus("Move slower \u2192")
                    } else {
                        setStatus("Pan smoothly \u2192")
                    }

                    if (abs(diffAngle - lastPanoYaw) >= 14f && isLevel && gyroSpeed < 0.40f) {
                        lastPanoYaw = diffAngle
                        triggerPanoStripCapture()
                    }
                    if (diffAngle >= 140f || panoStrips.size >= 8) {
                        finishPanorama()
                    }
                }
            }
        }
    }

    private fun triggerPanoStripCapture() {
        val ic = imageCapture ?: return
        ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp = try { toUpright(image) } catch (t: Throwable) { null }
                if (bmp != null) panoStrips.add(ImageProcessor.limit(bmp, 8))
            }
            override fun onError(e: ImageCaptureException) {}
        })
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun bindViews() {
        previewView = findViewById(R.id.previewView)
        livePortraitOverlay = findViewById(R.id.livePortraitOverlay)
        gridOverlay = findViewById(R.id.gridOverlay)
        focusRing = findViewById(R.id.focusRing)
        shutterFlash = findViewById(R.id.shutterFlash)
        statusContainer = findViewById(R.id.statusContainer)
        statusText = findViewById(R.id.statusText)
        nightProgressBar = findViewById(R.id.nightProgressBar)
        countdownText = findViewById(R.id.countdownText)
        peopleCountChip = findViewById(R.id.peopleCountChip)
        portraitBadge = findViewById(R.id.portraitBadge)
        btnFlash = findViewById(R.id.btnFlash)
        btnTimer = findViewById(R.id.btnTimer)
        btnRatio = findViewById(R.id.btnRatio)
        btnGrid = findViewById(R.id.btnGrid)
        btnLooks = findViewById(R.id.btnLooks)
        btnEnhance = findViewById(R.id.btnEnhance)
        btnFps = findViewById(R.id.btnFps)
        btnSettings = findViewById(R.id.btnSettings)
        exposureBar = findViewById(R.id.exposureBar)
        portraitBlurContainer = findViewById(R.id.portraitBlurContainer)
        blurLabel = findViewById(R.id.blurLabel)
        portraitBlurSeekBar = findViewById(R.id.portraitBlurSeekBar)
        proControlsContainer = findViewById(R.id.proControlsContainer)
        proValuesScroll = findViewById(R.id.proValuesScroll)
        proValuesRow = findViewById(R.id.proValuesRow)
        proTabIso = findViewById(R.id.proTabIso)
        proTabShutter = findViewById(R.id.proTabShutter)
        proTabWb = findViewById(R.id.proTabWb)
        proTabFocus = findViewById(R.id.proTabFocus)
        proTabEv = findViewById(R.id.proTabEv)
        proTabRaw = findViewById(R.id.proTabRaw)
        looksScroll = findViewById(R.id.looksScroll)
        looksRow = findViewById(R.id.looksRow)
        zoomDial = findViewById(R.id.zoomDial)
        zoomBar = findViewById(R.id.zoomBar)
        modeBar = findViewById(R.id.modeBar)
        thumbnail = findViewById(R.id.thumbnail)
        shutterButton = findViewById(R.id.shutterButton)
        shutterInner = findViewById(R.id.shutterInner)
        btnFlip = findViewById(R.id.btnFlip)
        btnPause = findViewById(R.id.btnPause)
        btnPhotoWhileVideo = findViewById(R.id.btnPhotoWhileVideo)

        moreSheetContainer = findViewById(R.id.moreSheetContainer)
        dualPipContainer = findViewById(R.id.dualPipContainer)
        dualPipPreview = findViewById(R.id.dualPipPreview)
        qrResultContainer = findViewById(R.id.qrResultContainer)
        qrContentText = findViewById(R.id.qrContentText)
        tileDualCamera = findViewById(R.id.tileDualCamera)

        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        thumbnail.clipToOutline = true
        thumbnail.outlineProvider = ViewOutlineProvider.BACKGROUND

        modeViews[Mode.PHOTO] = findViewById(R.id.modePhoto)
        modeViews[Mode.VIDEO] = findViewById(R.id.modeVideo)
        modeViews[Mode.PORTRAIT] = findViewById(R.id.modePortrait)
        modeViews[Mode.NIGHT] = findViewById(R.id.modeNight)
        modeViews[Mode.PRO] = findViewById(R.id.modePro)
        modeViews[Mode.MORE] = findViewById(R.id.modeMore)
    }

    private fun setupTopBar() {
        btnFlash.setOnClickListener {
            flashIndex = if (mode == Mode.VIDEO) {
                if (flashIndex == 0) 3 else 0
            } else {
                (flashIndex + 1) % 4
            }
            applyFlash()
            refreshTopBar()
        }
        btnTimer.setOnClickListener {
            timerSeconds = when (timerSeconds) { 0 -> 3; 3 -> 10; else -> 0 }
            refreshTopBar()
        }
        btnRatio.setOnClickListener {
            if (recording != null) return@setOnClickListener
            ratioMode = (ratioMode + 1) % 3
            layoutPreview()
            refreshTopBar()
            bindCamera()
        }
        btnEnhance.setOnClickListener {
            prefs.autoEnhance = when (prefs.autoEnhance) {
                "Natural" -> "Strong"
                "Strong" -> "Off"
                else -> "Natural"
            }
            refreshTopBar()
            toast("Auto Enhance: ${prefs.autoEnhance}")
        }
        btnGrid.setOnClickListener {
            if (!prefs.grid && !prefs.levelLine) {
                prefs.grid = true
                prefs.levelLine = false
            } else if (prefs.grid && !prefs.levelLine) {
                prefs.grid = true
                prefs.levelLine = true
            } else {
                prefs.grid = false
                prefs.levelLine = false
            }
            refreshTopBar()
        }
        btnLooks.setOnClickListener {
            looksScroll.visibility = if (looksScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        btnFps.setOnClickListener {
            if (recording != null) return@setOnClickListener
            currentFps60 = !currentFps60
            prefs.videoFps60 = currentFps60
            refreshTopBar()
            bindCamera()
        }
        btnSettings.setOnClickListener {
            if (recording != null) return@setOnClickListener
            settingsOpened = true
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun setupModeBar() {
        for ((m, tv) in modeViews) {
            tv.setOnClickListener {
                if (m == Mode.MORE) {
                    showMoreSheet(true)
                } else {
                    setMode(m)
                }
            }
        }
    }

    private fun setupLooks() {
        looksRow.removeAllViews()
        lookChips.clear()
        for ((i, look) in Looks.ALL.withIndex()) {
            val tv = TextView(this)
            tv.text = look.name
            tv.textSize = 13f
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(14), 0, dp(14), 0)
            tv.setOnClickListener {
                lookIndex = i
                prefs.lookIndex = i
                refreshLooks()
                applyPreviewLook()
                refreshTopBar()
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(34))
            lp.marginStart = dp(5)
            lp.marginEnd = dp(5)
            looksRow.addView(tv, lp)
            lookChips.add(tv)
        }
    }

    private fun setupPortraitControls() {
        portraitBlurSeekBar.progress = (prefs.portraitBlur * 100f).toInt().coerceIn(10, 100)
        updateBlurLabel(prefs.portraitBlur)
        portraitBlurSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val strength = progress / 100f
                    prefs.portraitBlur = strength
                    updateBlurLabel(strength)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun updateBlurLabel(strength: Float) {
        val fVal = when {
            strength < 0.35f -> "f/4.0"
            strength < 0.70f -> "f/2.8"
            else -> "f/1.4"
        }
        blurLabel.text = fVal
    }

    private fun setupProControls() {
        val tabs = listOf(
            proTabIso to ProTab.ISO,
            proTabShutter to ProTab.SHUTTER,
            proTabWb to ProTab.WB,
            proTabFocus to ProTab.FOCUS,
            proTabEv to ProTab.EV
        )
        for ((view, tab) in tabs) {
            view.setOnClickListener {
                activeProTab = tab
                refreshProTabHighlight()
                populateProValues()
            }
        }
        proTabRaw.setOnClickListener {
            if (isRawSupported) {
                prefs.rawCapture = !prefs.rawCapture
                proTabRaw.text = if (prefs.rawCapture) "RAW+JPEG" else "JPEG"
                proTabRaw.setTextColor(if (prefs.rawCapture) yellow else Color.WHITE)
            } else {
                toast("RAW (DNG) is not supported by this camera sensor")
            }
        }
    }

    private fun refreshProTabHighlight() {
        val list = listOf(
            proTabIso to ProTab.ISO,
            proTabShutter to ProTab.SHUTTER,
            proTabWb to ProTab.WB,
            proTabFocus to ProTab.FOCUS,
            proTabEv to ProTab.EV
        )
        for ((v, t) in list) {
            val sel = t == activeProTab
            v.setTextColor(if (sel) yellow else Color.WHITE)
            v.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    private fun populateProValues() {
        proValuesRow.removeAllViews()
        when (activeProTab) {
            ProTab.ISO -> {
                val values = listOf(0, 100, 200, 400, 800, 1600, 3200, 6400)
                for (v in values) {
                    val label = if (v == 0) "Auto" else "$v"
                    addProChip(label, manualIso == v) {
                        manualIso = v
                        applyProSettings()
                        populateProValues()
                    }
                }
            }
            ProTab.SHUTTER -> {
                val labels = listOf("Auto", "1/4000", "1/2000", "1/1000", "1/500", "1/250", "1/125", "1/60", "1/30", "1/15", "1/8", "1/4", "1/2", "1s")
                val nsecs = listOf(
                    0L, 250_000L, 500_000L, 1_000_000L, 2_000_000L, 4_000_000L, 8_000_000L,
                    16_666_666L, 33_333_333L, 66_666_666L, 125_000_000L, 250_000_000L, 500_000_000L, 1_000_000_000L
                )
                for (i in labels.indices) {
                    val ns = nsecs[i]
                    addProChip(labels[i], manualShutterNs == ns) {
                        manualShutterNs = ns
                        applyProSettings()
                        populateProValues()
                    }
                }
            }
            ProTab.WB -> {
                val labels = listOf("Auto", "3000K", "4000K", "5500K", "6500K", "7500K")
                val modes = listOf(0, CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT, CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT, CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT, CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT, CaptureRequest.CONTROL_AWB_MODE_SHADE)
                for (i in labels.indices) {
                    val m = modes[i]
                    addProChip(labels[i], manualWb == m) {
                        manualWb = m
                        applyProSettings()
                        populateProValues()
                    }
                }
            }
            ProTab.FOCUS -> {
                val labels = listOf("Auto AF", "Macro", "Close", "Mid", "Far", "Infinity")
                val diopters = listOf(-1f, 10f, 5f, 1f, 0.2f, 0.0f)
                for (i in labels.indices) {
                    val d = diopters[i]
                    addProChip(labels[i], manualFocusDistance == d) {
                        manualFocusDistance = d
                        applyProSettings()
                        populateProValues()
                    }
                }
            }
            ProTab.EV -> {
                val evs = listOf(-3.0f, -2.0f, -1.0f, 0.0f, 1.0f, 2.0f, 3.0f)
                for (ev in evs) {
                    val label = if (ev > 0) "+$ev" else "$ev"
                    addProChip(label, manualEv == ev) {
                        manualEv = ev
                        val es = camera?.cameraInfo?.exposureState
                        if (es != null && es.isExposureCompensationSupported) {
                            val step = es.exposureCompensationStep.toFloat()
                            val idx = (ev / step).roundToInt().coerceIn(es.exposureCompensationRange.lower, es.exposureCompensationRange.upper)
                            camera?.cameraControl?.setExposureCompensationIndex(idx)
                        }
                        populateProValues()
                    }
                }
            }
        }
    }

    private fun addProChip(label: String, selected: Boolean, onClick: () -> Unit) {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 12f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(10), 0, dp(10), 0)
        tv.setTextColor(if (selected) Color.BLACK else Color.WHITE)
        tv.setBackgroundResource(if (selected) R.drawable.bg_chip_selected else R.drawable.bg_chip)
        tv.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(28))
        lp.marginStart = dp(4)
        lp.marginEnd = dp(4)
        proValuesRow.addView(tv, lp)
    }

    private fun applyProSettings() {
        val cam = camera ?: return
        val c2Control = Camera2CameraControl.from(cam.cameraControl)
        val builder = CaptureRequestOptions.Builder()

        // ISO & Shutter Speed
        if (manualIso > 0 || manualShutterNs > 0L) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            if (manualIso > 0) builder.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, manualIso)
            if (manualShutterNs > 0L) builder.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, manualShutterNs)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        }

        // White Balance
        if (manualWb > 0) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, manualWb)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        }

        // Focus Distance
        if (manualFocusDistance >= 0f) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            builder.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, manualFocusDistance)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        }

        c2Control.setCaptureRequestOptions(builder.build())
    }

    // ------------------------------------------------------------- Zoom Dial (Phase C)
    private fun setupZoomDial() {
        zoomDial.onZoomChanged = { zoomRatio ->
            camera?.cameraControl?.setZoomRatio(zoomRatio)
            highlightZoom(zoomRatio)
        }
    }

    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return false
                val zs = cam.cameraInfo.zoomState.value ?: return false
                val target = (zs.zoomRatio * detector.scaleFactor).coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
                cam.cameraControl.setZoomRatio(target)
                zoomDial.setZoom(target)
                highlightZoom(target)
                return true
            }
        })
        val gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                lastTapPoint = PointF(e.x, e.y)
                focusAt(e.x, e.y, false)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                lastTapPoint = PointF(e.x, e.y)
                focusAt(e.x, e.y, true)
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                val start = e1 ?: return false
                val dx = e2.x - start.x
                val dy = e2.y - start.y
                if (abs(dx) > dp(80) && abs(dx) > abs(dy) * 1.4f) {
                    val mainModes = listOf(Mode.PHOTO, Mode.VIDEO, Mode.PORTRAIT, Mode.NIGHT, Mode.PRO)
                    val curIdx = mainModes.indexOf(mode)
                    if (curIdx != -1) {
                        val next = if (dx < 0) curIdx + 1 else curIdx - 1
                        if (next in mainModes.indices) setMode(mainModes[next])
                    }
                    return true
                }
                return false
            }
        })
        previewView.setOnTouchListener { v, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) gestureDetector.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP) v.performClick()
            true
        }
    }

    private fun setupControls() {
        shutterButton.setOnClickListener {
            shutterInner.animate().scaleX(0.88f).scaleY(0.88f).setDuration(70).withEndAction {
                shutterInner.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
            }.start()
            onShutter()
        }

        btnFlip.setOnClickListener {
            if (recording != null) {
                // Flip camera while recording! (Phase C Requirement 11)
                flipCameraWhileRecording()
                return@setOnClickListener
            }
            if (nightBusy) return@setOnClickListener
            lensFront = !lensFront
            btnFlip.animate().rotationBy(180f).setDuration(250).start()
            bindCamera()
        }

        btnPause.setOnClickListener {
            val rec = recording ?: return@setOnClickListener
            if (paused) {
                rec.resume()
                paused = false
                btnPause.setImageResource(R.drawable.ic_pause)
            } else {
                rec.pause()
                paused = true
                btnPause.setImageResource(R.drawable.ic_play)
            }
        }

        btnPhotoWhileVideo.setOnClickListener {
            takePhotoWhileRecording()
        }

        thumbnail.setOnClickListener { openGallery() }

        exposureBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    camera?.cameraControl?.setExposureCompensationIndex(progress + expMin)
                    handler.removeCallbacks(hideExposure)
                    handler.postDelayed(hideExposure, 3500)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    // ------------------------------------------------------------- MORE Modes (Phase C, E)
    private fun setupMoreModes() {
        findViewById<View>(R.id.btnMoreClose).setOnClickListener { showMoreSheet(false) }

        findViewById<View>(R.id.tilePanorama).setOnClickListener {
            showMoreSheet(false)
            setMode(Mode.PANORAMA)
        }

        findViewById<View>(R.id.tilePhotoSphere).setOnClickListener {
            showMoreSheet(false)
            setMode(Mode.SPHERE)
        }

        tileDualCamera?.setOnClickListener {
            showMoreSheet(false)
            setMode(Mode.DUAL)
        }

        findViewById<View>(R.id.tileDocScan).setOnClickListener {
            showMoreSheet(false)
            setMode(Mode.DOC)
        }

        findViewById<View>(R.id.tileQrScan).setOnClickListener {
            if (mode == Mode.QR) {
                qrImagePicker.launch("image/*")
            } else {
                showMoreSheet(false)
                setMode(Mode.QR)
            }
        }

        findViewById<View>(R.id.btnQrClose).setOnClickListener {
            qrResultContainer.visibility = View.GONE
        }

        findViewById<View>(R.id.btnQrCopy).setOnClickListener {
            val text = qrContentText.text.toString()
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("QR Code", text))
            toast("Copied to clipboard")
            qrResultContainer.visibility = View.GONE
        }

        findViewById<View>(R.id.btnQrShare).setOnClickListener {
            val text = qrContentText.text.toString()
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(intent, "Share QR Content"))
            qrResultContainer.visibility = View.GONE
        }

        findViewById<View>(R.id.btnQrOpen).setOnClickListener {
            val text = qrContentText.text.toString()
            if (text.startsWith("http://") || text.startsWith("https://")) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(text))
                startActivity(intent)
            }
            qrResultContainer.visibility = View.GONE
        }

        dualPipContainer.setOnClickListener {
            // Tap PiP to swap cameras in Dual Camera mode
            lensFront = !lensFront
            bindCamera()
        }
    }

    private fun showQrActionSheet(content: String) {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        vibrator?.vibrate(50L)
        qrContentText.text = content
        val isUrl = content.startsWith("http://") || content.startsWith("https://")
        findViewById<View>(R.id.btnQrOpen).visibility = if (isUrl) View.VISIBLE else View.GONE
        qrResultContainer.visibility = View.VISIBLE
    }

    private fun showMoreSheet(show: Boolean) {
        moreSheetContainer.visibility = if (show) View.VISIBLE else View.GONE
    }

    // ----------------------------------------------------------------- Layout
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun hasPerm(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun layoutPreview() {
        val w = resources.displayMetrics.widthPixels
        val h = when (ratioMode) {
            1 -> w * 16 / 9
            2 -> w
            else -> w * 4 / 3
        }
        val topMargin = dp(64)
        val lp = FrameLayout.LayoutParams(w, h).apply { this.topMargin = topMargin }
        previewView.layoutParams = lp
        val lp2 = FrameLayout.LayoutParams(w, h).apply { this.topMargin = topMargin }
        gridOverlay.layoutParams = lp2
    }

    private fun setTopButton(tv: TextView, icon: Int, label: String, active: Boolean) {
        tv.setCompoundDrawablesWithIntrinsicBounds(0, icon, 0, 0)
        tv.text = label
        val color = if (active) yellow else Color.WHITE
        tv.setTextColor(color)
        tv.compoundDrawables[1]?.mutate()?.setTint(color)
    }

    private fun refreshTopBar() {
        val flashLabels = arrayOf("Off", "Auto", "On", "Torch")
        setTopButton(btnFlash, R.drawable.ic_flash, flashLabels[flashIndex], flashIndex != 0)
        setTopButton(btnTimer, R.drawable.ic_timer, if (timerSeconds == 0) "Off" else "${timerSeconds}s", timerSeconds != 0)
        val ratioText = when (ratioMode) { 1 -> "16:9"; 2 -> "1:1"; else -> "4:3" }
        setTopButton(btnRatio, R.drawable.ic_ratio, ratioText, false)

        val gridLabel = when {
            prefs.grid && prefs.levelLine -> "Grid+Lvl"
            prefs.grid -> "Grid"
            prefs.levelLine -> "Level"
            else -> "Grid Off"
        }
        setTopButton(btnGrid, R.drawable.ic_grid, gridLabel, prefs.grid || prefs.levelLine)
        gridOverlay.showGrid = prefs.grid
        gridOverlay.showLevel = prefs.levelLine

        btnEnhance.text = when (prefs.autoEnhance) {
            "Strong" -> "ENH: Str"
            "Off" -> "ENH: Off"
            else -> "ENH: Nat"
        }
        val enhanceActive = prefs.autoEnhance != "Off"
        btnEnhance.setTextColor(if (enhanceActive) yellow else Color.LTGRAY)

        setTopButton(btnLooks, R.drawable.ic_looks, Looks.ALL[lookIndex].name, lookIndex != 0)
        setTopButton(btnSettings, R.drawable.ic_settings, "Setup", false)

        if (mode == Mode.VIDEO && is60FpsSupported) {
            btnFps.visibility = View.VISIBLE
            btnFps.text = if (currentFps60) "60 FPS" else "30 FPS"
            btnFps.setTextColor(if (currentFps60) yellow else Color.WHITE)
        } else {
            btnFps.visibility = View.GONE
        }
    }

    private fun refreshLooks() {
        for ((i, tv) in lookChips.withIndex()) {
            val sel = i == lookIndex
            tv.setTextColor(if (sel) Color.BLACK else Color.WHITE)
            tv.setBackgroundResource(if (sel) R.drawable.bg_chip_selected else R.drawable.bg_chip)
        }
    }

    private fun refreshModeBar() {
        for ((m, tv) in modeViews) {
            val sel = m == mode
            tv.setTextColor(if (sel) yellow else Color.WHITE)
            tv.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            tv.alpha = if (sel) 1f else 0.70f
        }
        val res = when {
            mode == Mode.VIDEO && recording != null -> R.drawable.shutter_recording
            mode == Mode.VIDEO -> R.drawable.shutter_video
            else -> R.drawable.shutter_photo
        }
        shutterInner.setBackgroundResource(res)

        // Show/hide sub-panels and badges
        portraitBlurContainer.visibility = if (mode == Mode.PORTRAIT) View.VISIBLE else View.GONE
        portraitBadge.visibility = if (mode == Mode.PORTRAIT) View.VISIBLE else View.GONE
        livePortraitOverlay.visibility = if (mode == Mode.PORTRAIT) View.VISIBLE else View.GONE
        proControlsContainer.visibility = if (mode == Mode.PRO) View.VISIBLE else View.GONE
        dualPipContainer.visibility = if (mode == Mode.DUAL) View.VISIBLE else View.GONE

        gridOverlay.showPanoramaGuide = mode == Mode.PANORAMA
        gridOverlay.showSphereGuide = mode == Mode.SPHERE

        if (mode == Mode.PRO) {
            refreshProTabHighlight()
            populateProValues()
            proTabRaw.text = if (prefs.rawCapture) "RAW+JPEG" else "JPEG"
            proTabRaw.setTextColor(if (prefs.rawCapture) yellow else Color.WHITE)
        }
    }

    private fun refreshAll() {
        refreshTopBar()
        refreshLooks()
        refreshModeBar()
        applyPreviewLook()
    }

    /** Live look on preview */
    private fun applyPreviewLook() {
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(ColorOps.forProfile(profile, Looks.ALL[lookIndex]))
        previewView.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
    }

    private fun setStatus(text: String?, showProgress: Boolean = false, progress: Int = 0) {
        if (text == null) {
            statusContainer.visibility = View.GONE
        } else {
            statusText.text = text
            if (showProgress) {
                nightProgressBar.visibility = View.VISIBLE
                nightProgressBar.progress = progress
            } else {
                nightProgressBar.visibility = View.GONE
            }
            statusContainer.visibility = View.VISIBLE
        }
    }

    // ------------------------------------------------------------------ Modes
    private fun setMode(m: Mode) {
        if (m == mode || recording != null || nightBusy) return
        val wasVideo = mode == Mode.VIDEO
        mode = m
        if (mode == Mode.VIDEO && (flashIndex == 1 || flashIndex == 2)) flashIndex = 0

        gridOverlay.clearFaces()
        gridOverlay.documentQuad = null
        gridOverlay.qrBox = null
        peopleCountChip.visibility = View.GONE

        refreshModeBar()
        refreshTopBar()

        when (m) {
            Mode.PORTRAIT -> hint("Portrait: depth-aware background blur")
            Mode.NIGHT -> hint("Night: hold still, aligning & merging frames")
            Mode.PRO -> hint("Pro: manual ISO, shutter, white balance & focus")
            Mode.PANORAMA -> hint("Panorama: tap shutter and pan smoothly \u2192")
            Mode.SPHERE -> hint("Photo Sphere 360: rotate to align target dots")
            Mode.DUAL -> hint("Dual Camera: front and rear cameras picture-in-picture")
            Mode.DOC -> hint("Document Scan: high contrast crisp text")
            Mode.QR -> hint("QR Scan: point at any barcode or QR code")
            else -> setStatus(null)
        }

        if (wasVideo != (m == Mode.VIDEO) || m == Mode.DUAL) bindCamera() else applyFlash()
    }

    private fun hint(text: String) {
        setStatus(text)
        handler.postDelayed({ if (!nightBusy && recording == null && pending == 0 && !panoCapturing && !sphereCapturing) setStatus(null) }, 2500)
    }

    // ----------------------------------------------------------------- Camera
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            // Check concurrent camera support at runtime (Requirement 12)
            try {
                isConcurrentSupported = cameraProvider?.availableConcurrentCameraInfos?.isNotEmpty() == true
            } catch (e: Throwable) {
                isConcurrentSupported = false
            }
            tileDualCamera?.visibility = if (isConcurrentSupported) View.VISIBLE else View.GONE

            val extFuture = ExtensionsManager.getInstanceAsync(this, cameraProvider!!)
            extFuture.addListener({
                extensionsManager = extFuture.get()
                bindCamera()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    private fun resolutionSelector(forCapture: Boolean): ResolutionSelector {
        val b = ResolutionSelector.Builder()
        val aspect = when (ratioMode) {
            1 -> AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            else -> AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
        }
        b.setAspectRatioStrategy(aspect)
        if (forCapture) {
            val bw = sqrt(profile.maxMegapixels * 1_000_000.0 * 4.0 / 3.0).toInt()
            val bh = bw * 3 / 4
            b.setResolutionStrategy(
                ResolutionStrategy(Size(bw, bh), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
            )
        }
        return b.build()
    }

    private fun qualitySelector(): QualitySelector {
        val q = when (prefs.videoQuality) {
            "HD" -> Quality.HD
            "UHD" -> Quality.UHD
            else -> Quality.FHD
        }
        return QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))
    }

    private fun targetVideoBitrate(): Int {
        return when (prefs.videoBitrate) {
            "30 Mbps" -> 30_000_000
            "50 Mbps" -> 50_000_000
            else -> {
                when (prefs.videoQuality) {
                    "UHD" -> 45_000_000
                    "HD" -> 12_000_000
                    else -> 28_000_000
                }
            }
        }
    }

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        var selector = if (lensFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA

        // CameraX Extensions integration: only use one HDR method per shot
        val ext = extensionsManager
        if (ext != null) {
            val extMode = when (mode) {
                Mode.NIGHT -> ExtensionMode.NIGHT
                Mode.PORTRAIT -> ExtensionMode.BOKEH
                Mode.PHOTO -> if (prefs.smartHdr && !prefs.hdrPlus) ExtensionMode.HDR else ExtensionMode.NONE
                else -> ExtensionMode.NONE
            }
            if (extMode != ExtensionMode.NONE && ext.isExtensionAvailable(selector, extMode)) {
                selector = ext.getExtensionEnabledCameraSelector(selector, extMode)
            }
        }

        val previewBuilder = Preview.Builder().setResolutionSelector(resolutionSelector(false))

        // Video stabilization and 60 FPS Camera2Interop options
        if (mode == Mode.VIDEO) {
            val c2Extender = Camera2Interop.Extender(previewBuilder)
            if (prefs.videoStabilization) {
                c2Extender.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
                c2Extender.setCaptureRequestOption(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
            }
            if (currentFps60 && is60FpsSupported) {
                c2Extender.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(60, 60))
            }
        }

        val preview = previewBuilder.build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        // Live human face tracking and QR scanning analysis
        val analysisBuilder = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
        if (mode == Mode.QR) {
            analysisBuilder.setResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                    .build()
            )
        }
        val analysis = analysisBuilder.build()
        analysis.setAnalyzer(analysisExecutor) { imageProxy ->
            processImageAnalysis(imageProxy)
        }
        imageAnalysis = analysis

        try {
            if (mode == Mode.VIDEO) {
                val recorderBuilder = Recorder.Builder()
                    .setQualitySelector(qualitySelector())
                    .setTargetVideoEncodingBitRate(targetVideoBitrate())

                val recorder = recorderBuilder.build()
                val vc = VideoCapture.withOutput(recorder)
                videoCapture = vc
                val ic = ImageCapture.Builder().setResolutionSelector(resolutionSelector(true)).build()
                imageCapture = ic
                camera = provider.bindToLifecycle(this, selector, preview, vc, ic, analysis)
            } else {
                videoCapture = null
                val icBuilder = ImageCapture.Builder()
                    .setResolutionSelector(resolutionSelector(true))
                try {
                    icBuilder.setCaptureMode(ImageCapture.CAPTURE_MODE_ZERO_SHUTTER_LAG)
                } catch (e: Exception) {
                    icBuilder.setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                }
                val ic = icBuilder.build()
                imageCapture = ic
                camera = provider.bindToLifecycle(this, selector, preview, ic, analysis)
            }
            onCameraBound()

            if (isFlippingVideo) {
                isFlippingVideo = false
                resumeNextVideoSegment()
            }
        } catch (e: Exception) {
            toast("Camera error: " + (e.message ?: "unknown"))
        }
    }

    private fun onCameraBound() {
        val cam = camera ?: return
        btnFlash.visibility = if (cam.cameraInfo.hasFlashUnit()) View.VISIBLE else View.INVISIBLE
        applyFlash()

        val zs = cam.cameraInfo.zoomState.value
        val minZ = zs?.minZoomRatio ?: 1f
        val maxZ = zs?.maxZoomRatio ?: 10f

        zoomDial.minZoom = minZ
        zoomDial.maxZoom = maxZ
        zoomDial.opticalZoomMax = if (maxZ >= 2f) 2.0f else 1.0f
        zoomDial.setZoom(zs?.zoomRatio ?: 1f)

        buildZoomChips(minZ, maxZ)

        val es = cam.cameraInfo.exposureState
        if (es.isExposureCompensationSupported) {
            val r = es.exposureCompensationRange
            expMin = r.lower
            exposureBar.max = r.upper - r.lower
            exposureBar.progress = es.exposureCompensationIndex - r.lower
        }

        try {
            val c2Info = Camera2CameraInfo.from(cam.cameraInfo)
            val caps = c2Info.getCameraCharacteristic(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            isRawSupported = caps?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW) == true

            val fpsRanges = c2Info.getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            is60FpsSupported = fpsRanges?.any { it.upper >= 60 } == true
        } catch (e: Exception) {
            isRawSupported = false
            is60FpsSupported = false
        }

        refreshTopBar()
        applyPreviewLook()
        if (mode == Mode.PRO) applyProSettings()
    }

    // ------------------------------------------------ Live Face Tracking, QR & Document (P1 & P3)
    @SuppressLint("UnsafeOptInUsageError")
    private fun processImageAnalysis(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        // P1 Item 8: Turn analyzer off in QR, DOC, NIGHT, PANORAMA, SPHERE, and PRO (save battery)
        if (mode !in listOf(Mode.PHOTO, Mode.PORTRAIT, Mode.VIDEO, Mode.QR, Mode.DOC)) {
            imageProxy.close()
            return
        }

        val rot = imageProxy.imageInfo.rotationDegrees
        val inputImage = InputImage.fromMediaImage(mediaImage, rot)

        // 1. QR Scan Mode (P3 Item 16)
        if (mode == Mode.QR) {
            barcodeScanner.process(inputImage)
                .addOnSuccessListener { barcodes ->
                    if (barcodes.isNotEmpty()) {
                        val first = barcodes[0]
                        val raw = first.rawValue ?: first.displayValue ?: ""
                        val b = first.boundingBox
                        if (b != null) {
                            val previewW = previewView.width.toFloat()
                            val previewH = previewView.height.toFloat()
                            val imgW = if (rot == 90 || rot == 270) imageProxy.height.toFloat() else imageProxy.width.toFloat()
                            val imgH = if (rot == 90 || rot == 270) imageProxy.width.toFloat() else imageProxy.height.toFloat()
                            val scale = max(previewW / imgW, previewH / imgH)
                            val offX = (previewW - imgW * scale) / 2f
                            val offY = (previewH - imgH * scale) / 2f
                            var l = b.left.toFloat()
                            var r = b.right.toFloat()
                            if (lensFront) {
                                val ml = imgW - r
                                val mr = imgW - l
                                l = ml
                                r = mr
                            }
                            val box = RectF(
                                (l * scale + offX).coerceIn(0f, previewW),
                                (b.top * scale + offY).coerceIn(0f, previewH),
                                (r * scale + offX).coerceIn(0f, previewW),
                                (b.bottom * scale + offY).coerceIn(0f, previewH)
                            )
                            runOnUiThread { gridOverlay.qrBox = box }
                        }
                        if (raw.isNotEmpty() && qrResultContainer.visibility != View.VISIBLE) {
                            runOnUiThread { showQrActionSheet(raw) }
                        }
                    } else {
                        runOnUiThread { gridOverlay.qrBox = null }
                    }
                }
                .addOnCompleteListener { imageProxy.close() }
            return
        }

        // 2. Document Page Detection Mode (P3 Item 15)
        if (mode == Mode.DOC) {
            try {
                val bmp = imageProxy.toBitmap()
                val quad = DocumentScanManager.detectDocumentQuad(bmp)
                val previewW = previewView.width.toFloat()
                val previewH = previewView.height.toFloat()
                val imgW = if (rot == 90 || rot == 270) imageProxy.height.toFloat() else imageProxy.width.toFloat()
                val imgH = if (rot == 90 || rot == 270) imageProxy.width.toFloat() else imageProxy.height.toFloat()
                val scale = max(previewW / imgW, previewH / imgH)
                val offX = (previewW - imgW * scale) / 2f
                val offY = (previewH - imgH * scale) / 2f
                val pts = ArrayList<PointF>()
                for (pt in quad) {
                    val qx = pt.x * (imgW / bmp.width)
                    val qy = pt.y * (imgH / bmp.height)
                    pts.add(PointF(qx * scale + offX, qy * scale + offY))
                }
                bmp.recycle()
                runOnUiThread { gridOverlay.documentQuad = pts }
            } catch (ignored: Throwable) {}
            imageProxy.close()
            return
        }

        // 3. Live Face Tracking (P1 Items 9 & 10)
        liveFaceDetector.process(inputImage)
            .addOnSuccessListener { faces ->
                runOnUiThread {
                    if (faces.isEmpty()) {
                        gridOverlay.clearFaces()
                        peopleCountChip.visibility = View.GONE
                    } else {
                        peopleCountChip.text = if (faces.size == 1) "1 Person" else "${faces.size} People"
                        peopleCountChip.visibility = View.VISIBLE
                    }
                }
                if (faces.isNotEmpty()) {
                    val previewW = previewView.width.toFloat()
                    val previewH = previewView.height.toFloat()
                    val imgW = if (rot == 90 || rot == 270) imageProxy.height.toFloat() else imageProxy.width.toFloat()
                    val imgH = if (rot == 90 || rot == 270) imageProxy.width.toFloat() else imageProxy.height.toFloat()

                    // P1 Item 10: Exact FILL_CENTER transformation matrix
                    val scale = max(previewW / imgW, previewH / imgH)
                    val offX = (previewW - imgW * scale) / 2f
                    val offY = (previewH - imgH * scale) / 2f

                    val trackedList = ArrayList<TrackedFace>()
                    var primaryCenterX = 0f
                    var primaryCenterY = 0f

                    for (face in faces) {
                        val b = face.boundingBox
                        var l = b.left.toFloat()
                        var r = b.right.toFloat()
                        if (lensFront) {
                            val ml = imgW - r
                            val mr = imgW - l
                            l = ml
                            r = mr
                        }
                        val scL = (l * scale + offX).coerceIn(0f, previewW)
                        val scT = (b.top * scale + offY).coerceIn(0f, previewH)
                        val scR = (r * scale + offX).coerceIn(0f, previewW)
                        val scB = (b.bottom * scale + offY).coerceIn(0f, previewH)
                        trackedList.add(TrackedFace(face.trackingId ?: 1, RectF(scL, scT, scR, scB)))

                        if (primaryCenterX == 0f) {
                            primaryCenterX = (scL + scR) / 2f
                            primaryCenterY = (scT + scB) / 2f
                        }
                    }

                    runOnUiThread { gridOverlay.setFaces(trackedList) }

                    // Continuous focus & metering on primary face
                    val now = System.currentTimeMillis()
                    if (now - lastFaceMeteringTime > 1800L && primaryCenterX > 0f) {
                        lastFaceMeteringTime = now
                        val point = previewView.meteringPointFactory.createPoint(primaryCenterX, primaryCenterY)
                        val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                            .setAutoCancelDuration(2, TimeUnit.SECONDS)
                            .build()
                        camera?.cameraControl?.startFocusAndMetering(action)
                    }
                }
            }
            .addOnFailureListener {
                runOnUiThread {
                    gridOverlay.clearFaces()
                    peopleCountChip.visibility = View.GONE
                }
            }
            .addOnCompleteListener { imageProxy.close() }
    }

    private fun applyFlash() {
        val cam = camera ?: return
        val ic = imageCapture
        if (ic != null) {
            ic.flashMode = when (flashIndex) {
                1 -> ImageCapture.FLASH_MODE_AUTO
                2 -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
        }
        if (cam.cameraInfo.hasFlashUnit()) cam.cameraControl.enableTorch(flashIndex == 3)
    }

    private fun buildZoomChips(minZ: Float, maxZ: Float) {
        zoomBar.removeAllViews()
        zoomChips.clear()
        val wanted = ArrayList<Float>()
        if (minZ < 0.95f) wanted.add(minZ)
        wanted.add(1f)
        if (maxZ >= 2f) wanted.add(2f)
        if (maxZ >= 5f) wanted.add(5f)
        for (z in wanted) {
            if (z < minZ - 0.01f || z > maxZ + 0.01f) continue
            val tv = TextView(this)
            tv.text = if (z < 1f) String.format(Locale.US, "%.1f", z) else "${z.toInt()}x"
            tv.textSize = 12f
            tv.gravity = Gravity.CENTER
            tv.setOnClickListener {
                camera?.cameraControl?.setZoomRatio(z)
                zoomDial.setZoom(z)
                highlightZoom(z)
            }
            val lp = LinearLayout.LayoutParams(dp(44), dp(30))
            lp.marginStart = dp(4)
            lp.marginEnd = dp(4)
            zoomBar.addView(tv, lp)
            zoomChips.add(Pair(z, tv))
        }
        highlightZoom(1f)
    }

    private fun highlightZoom(ratio: Float) {
        var best = -1
        var bestDiff = Float.MAX_VALUE
        for ((i, p) in zoomChips.withIndex()) {
            val d = abs(p.first - ratio)
            if (d < bestDiff) {
                bestDiff = d
                best = i
            }
        }
        for ((i, p) in zoomChips.withIndex()) {
            val sel = i == best
            p.second.setTextColor(if (sel) Color.BLACK else Color.WHITE)
            p.second.setBackgroundResource(if (sel) R.drawable.bg_chip_selected else R.drawable.bg_chip)
        }
    }

    private fun focusAt(x: Float, y: Float, lock: Boolean) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val builder = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
        if (lock) builder.disableAutoCancel() else builder.setAutoCancelDuration(4, TimeUnit.SECONDS)
        cam.cameraControl.startFocusAndMetering(builder.build())
        showFocusRing(x, y)
        exposureBar.visibility = View.VISIBLE
        handler.removeCallbacks(hideExposure)
        handler.postDelayed(hideExposure, 3500)
        if (lock) hint("AE/AF LOCK")
    }

    private fun showFocusRing(x: Float, y: Float) {
        val size = dp(80)
        focusRing.x = x - size / 2f
        focusRing.y = previewView.top + y - size / 2f
        focusRing.animate().cancel()
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.scaleX = 1.4f
        focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(180).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300).withEndAction {
                focusRing.visibility = View.GONE
                focusRing.alpha = 1f
            }.start()
        }.start()
    }

    // ---------------------------------------------------------------- Shutter
    private fun playSound(which: Int) {
        if (prefs.shutterSound) sound.play(which)
    }

    private fun onShutter() {
        shutterButton.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        if (mode == Mode.VIDEO) {
            toggleRecording()
            return
        }
        if (mode == Mode.PANORAMA) {
            togglePanorama()
            return
        }
        if (mode == Mode.SPHERE) {
            toggleSphere()
            return
        }
        if (nightBusy) return

        if (countdownRunning) {
            handler.removeCallbacks(countdownTick)
            countdownRunning = false
            countdownText.visibility = View.GONE
            return
        }
        if (timerSeconds > 0) {
            countdownRunning = true
            countdownLeft = timerSeconds
            countdownText.visibility = View.VISIBLE
            countdownTick.run()
        } else {
            capture()
        }
    }

    private fun flashScreen() {
        shutterFlash.visibility = View.VISIBLE
        shutterFlash.alpha = 0.5f
        shutterFlash.animate().alpha(0f).setDuration(160).withEndAction {
            shutterFlash.visibility = View.GONE
        }.start()
    }

    private fun capture() {
        val ic = imageCapture ?: return
        flashScreen()
        when {
            mode == Mode.NIGHT -> captureFastNight(ic)
            mode == Mode.PHOTO && prefs.hdrPlus -> captureFastHdr(ic)
            mode == Mode.DOC -> captureDoc(ic)
            mode == Mode.DUAL && !isConcurrentSupported -> captureDualShot(ic)
            else -> captureSingle(ic)
        }
    }

    private fun toUpright(image: ImageProxy): Bitmap {
        val bmp = image.toBitmap()
        val rot = image.imageInfo.rotationDegrees
        image.close()
        return ImageProcessor.upright(bmp, rot, lensFront && prefs.mirrorSelfie)
    }

    private fun captureSingle(ic: ImageCapture) {
        val m = mode
        playSound(MediaActionSound.SHUTTER_CLICK)
        ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp: Bitmap? = try { toUpright(image) } catch (t: Throwable) { null }
                if (bmp == null) {
                    runOnUiThread { toast("Could not read photo") }
                    return
                }
                enqueueProcessing(bmp, m)
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { toast("Photo failed: " + exception.message) }
            }
        })
    }

    private fun captureDoc(ic: ImageCapture) {
        playSound(MediaActionSound.SHUTTER_CLICK)
        ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp = try { toUpright(image) } catch (t: Throwable) { null }
                if (bmp != null) {
                    processExecutor.execute {
                        val quad = DocumentScanManager.detectDocumentQuad(bmp)
                        val cropped = DocumentScanManager.perspectiveCrop(bmp, quad)
                        val enhanced = DocumentScanManager.removeShadowsAndProcess(cropped, DocumentScanManager.DocColorMode.COLOR)
                        DocumentScanManager.addPage(
                            DocumentScanManager.ScannedPage(
                                original = cropped,
                                processed = enhanced
                            )
                        )
                        val uri = ImageProcessor.saveJpeg(this@MainActivity, enhanced, 98, "PROCAM_DOC_")
                        ImageProcessor.recycleAll(bmp)
                        runOnUiThread {
                            if (uri != null) {
                                lastUri = uri
                                loadThumb(uri)
                                showDocExportDialog()
                            }
                        }
                    }
                }
            }
            override fun onError(exception: ImageCaptureException) {}
        })
    }

    private fun showDocExportDialog() {
        val count = DocumentScanManager.pageCount()
        android.app.AlertDialog.Builder(this)
            .setTitle("Document Page $count Scanned")
            .setMessage("Page added to document session. Would you like to export multi-page PDF now or scan another page?")
            .setPositiveButton("Export PDF ($count pages)") { _, _ ->
                processExecutor.execute {
                    val pages = DocumentScanManager.getPages().map { it.processed }
                    val pdfUri = DocumentScanManager.exportToPdf(this@MainActivity, pages)
                    DocumentScanManager.clearSession()
                    runOnUiThread {
                        if (pdfUri != null) {
                            lastUri = pdfUri
                            toast("Multi-page PDF saved to Documents/ProCam")
                        } else {
                            toast("Failed to generate PDF")
                        }
                    }
                }
            }
            .setNeutralButton("Scan Another", null)
            .show()
    }

    private fun captureDualShot(ic: ImageCapture) {
        playSound(MediaActionSound.SHUTTER_CLICK)
        flashScreen()
        setStatus("Capturing Dual Shot (Back lens)...")
        ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val backBmp = try { toUpright(image) } catch (t: Throwable) { null }
                if (backBmp == null) {
                    runOnUiThread { toast("Dual shot failed") }
                    return
                }
                // Switch lens to front for selfie
                runOnUiThread {
                    setStatus("Capturing Dual Shot (Front lens)...")
                    lensFront = true
                    bindCamera()
                    handler.postDelayed({
                        val frontIc = imageCapture ?: return@postDelayed
                        frontIc.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
                            override fun onCaptureSuccess(frontImg: ImageProxy) {
                                val frontBmp = try { toUpright(frontImg) } catch (t: Throwable) { null }
                                processExecutor.execute {
                                    val composite = if (frontBmp != null) {
                                        ImageProcessor.compositePip(backBmp, frontBmp)
                                    } else {
                                        backBmp
                                    }
                                    runOnUiThread {
                                        lensFront = false
                                        bindCamera()
                                        enqueueProcessing(composite, Mode.PHOTO)
                                    }
                                }
                            }
                            override fun onError(e: ImageCaptureException) {
                                runOnUiThread {
                                    lensFront = false
                                    bindCamera()
                                    enqueueProcessing(backBmp, Mode.PHOTO)
                                }
                            }
                        })
                    }, 800)
                }
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { toast("Dual shot failed: " + exception.message) }
            }
        })
    }

    // --------------------------------------------- Fast Burst Night (Phase A)
    private fun captureFastNight(ic: ImageCapture) {
        // Gyroscope shake gating: warn if phone is currently moving fast
        if (prefs.gyroShakeGating && gyroSpeed > 0.35f) {
            hint("\u26A0 Hold steady for Night shot!")
        }

        val totalFrames = if (isTripod) 8 else 6
        val frames = ArrayList<Bitmap>()
        nightBusy = true
        playSound(MediaActionSound.SHUTTER_CLICK)

        val cam = camera
        // Keep AE on, cap target FPS range to (30,30), merge more frames
        if (cam != null && !isTripod) {
            val c2Control = Camera2CameraControl.from(cam.cameraControl)
            val builder = CaptureRequestOptions.Builder()
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(30, 30))
            c2Control.setCaptureRequestOptions(builder.build())
        }

        fun finishNight() {
            nightBusy = false
            setStatus(null)

            if (frames.isNotEmpty()) {
                processExecutor.execute {
                    val merged = ImageProcessor.mergeFastBurst(frames, isTripod)
                    runOnUiThread { enqueueProcessing(merged, Mode.NIGHT) }
                }
            } else {
                toast("Night capture failed")
            }
        }

        fun step(i: Int) {
            val pct = ((i + 1) * 100 / totalFrames)
            setStatus("Hold still  ${i + 1}/$totalFrames", showProgress = true, progress = pct)

            ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    var ok = true
                    try {
                        // Reject frames taken during high gyro rotation (> 0.5 rad/s)
                        if (prefs.gyroShakeGating && gyroSpeed > 0.50f && frames.isNotEmpty()) {
                            image.close()
                        } else {
                            val frame = ImageProcessor.limit(toUpright(image), profile.maxMegapixels)
                            frames.add(frame)
                        }
                    } catch (t: Throwable) {
                        ok = false
                        try { image.close() } catch (ignored: Throwable) {}
                    }
                    runOnUiThread {
                        if (!ok || i + 1 >= totalFrames) finishNight()
                        else step(i + 1)
                    }
                }
                override fun onError(exception: ImageCaptureException) {
                    runOnUiThread { finishNight() }
                }
            })
        }
        step(0)
    }

    // ---------------------------------------------- Fast Burst HDR+ (Phase A)
    private fun captureFastHdr(ic: ImageCapture) {
        val total = 3
        val frames = ArrayList<Bitmap>()
        nightBusy = true
        playSound(MediaActionSound.SHUTTER_CLICK)

        fun finishHdr() {
            nightBusy = false
            setStatus(null)
            if (frames.isNotEmpty()) {
                processExecutor.execute {
                    val merged = ImageProcessor.mergeFastBurst(frames, isTripod)
                    runOnUiThread { enqueueProcessing(merged, Mode.PHOTO) }
                }
            } else {
                captureSingle(ic)
            }
        }

        fun step(i: Int) {
            setStatus("Capturing HDR+ (${i + 1}/$total)...")
            ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    try {
                        val frame = ImageProcessor.limit(toUpright(image), profile.maxMegapixels)
                        frames.add(frame)
                    } catch (t: Throwable) {
                        try { image.close() } catch (ignored: Throwable) {}
                    }
                    runOnUiThread {
                        if (i + 1 < total) step(i + 1) else finishHdr()
                    }
                }
                override fun onError(exception: ImageCaptureException) {
                    runOnUiThread { finishHdr() }
                }
            })
        }
        step(0)
    }

    // ------------------------------------------------ Panorama & Sphere (Phase E)
    private fun togglePanorama() {
        if (!panoCapturing) {
            panoCapturing = true
            panoStrips.clear()
            panoStartAngle = currentYaw
            gridOverlay.showPanoramaGuide = true
            setStatus("Pan slowly along the line \u2192")
            shutterInner.setBackgroundResource(R.drawable.shutter_recording)
            capturePanoStrips()
        } else {
            finishPanorama()
        }
    }

    private fun capturePanoStrips() {
        if (!panoCapturing) return
        val ic = imageCapture ?: return
        ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp = try { toUpright(image) } catch (t: Throwable) { null }
                if (bmp != null) panoStrips.add(ImageProcessor.limit(bmp, 8))
                handler.postDelayed({
                    if (panoCapturing && panoStrips.size < 6) capturePanoStrips()
                    else if (panoCapturing) finishPanorama()
                }, 500)
            }
            override fun onError(exception: ImageCaptureException) {
                finishPanorama()
            }
        })
    }

    private fun finishPanorama() {
        panoCapturing = false
        gridOverlay.showPanoramaGuide = false
        setStatus(null)
        shutterInner.setBackgroundResource(R.drawable.shutter_photo)

        if (panoStrips.isNotEmpty()) {
            processExecutor.execute {
                val pano = ImageProcessor.stitchPanorama(panoStrips)
                val uri = ImageProcessor.saveJpeg(this, pano, 97, "PROCAM_PANO_")
                for (s in panoStrips) ImageProcessor.recycleAll(s)
                panoStrips.clear()
                runOnUiThread {
                    if (uri != null) {
                        lastUri = uri
                        loadThumb(uri)
                        toast("Panorama saved to Pictures/ProCam")
                    }
                }
            }
        }
    }

    private fun toggleSphere() {
        if (!sphereCapturing) {
            sphereCapturing = true
            sphereCaptures.clear()
            for (t in sphereTargets) t.captured = false
            gridOverlay.showSphereGuide = true
            setStatus("Align crosshair with yellow dots")
            shutterInner.setBackgroundResource(R.drawable.shutter_recording)
        } else {
            finishSphere()
        }
    }

    private fun checkSphereAutoCapture() {
        if (!sphereCapturing) return
        val ic = imageCapture ?: return
        for (target in sphereTargets) {
            if (!target.captured) {
                val dPitch = abs(target.pitch - currentPitch)
                var dYaw = abs(target.yaw - currentYaw)
                while (dYaw > 180f) dYaw -= 360f
                if (dPitch < 5f && abs(dYaw) < 5f) {
                    target.captured = true
                    playSound(MediaActionSound.SHUTTER_CLICK)
                    ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
                        override fun onCaptureSuccess(image: ImageProxy) {
                            val bmp = try { toUpright(image) } catch (t: Throwable) { null }
                            if (bmp != null) sphereCaptures.add(ImageProcessor.limit(bmp, 6))
                            runOnUiThread {
                                if (sphereTargets.all { it.captured }) finishSphere()
                            }
                        }
                        override fun onError(exception: ImageCaptureException) {}
                    })
                    break
                }
            }
        }
    }

    private fun finishSphere() {
        sphereCapturing = false
        gridOverlay.showSphereGuide = false
        setStatus(null)
        shutterInner.setBackgroundResource(R.drawable.shutter_photo)

        if (sphereCaptures.isNotEmpty()) {
            processExecutor.execute {
                val sphere = ImageProcessor.stitchPhotoSphere(sphereCaptures)
                val uri = ImageProcessor.saveJpeg(this, sphere, 97, "PROCAM_SPHERE_", isPhotoSphere = true)
                for (c in sphereCaptures) ImageProcessor.recycleAll(c)
                sphereCaptures.clear()
                runOnUiThread {
                    if (uri != null) {
                        lastUri = uri
                        loadThumb(uri)
                        toast("Photo Sphere 360 saved with Google 360 metadata")
                    }
                }
            }
        }
    }

    // ------------------------------------------------ Photo Pipeline & Auto Enhance
    private fun enqueueProcessing(source: Bitmap, m: Mode) {
        val prof = profile
        val look = Looks.ALL[lookIndex]
        val hdr = prefs.smartHdr && !prefs.hdrPlus // Only one HDR method per shot
        val blur = prefs.portraitBlur
        val autoEnhanceMode = prefs.autoEnhance
        val skinSmoothMode = prefs.skinSmoothing
        val tapPt = lastTapPoint

        // Optional: Save original uncompressed photo (Phase A Requirement 5)
        if (prefs.saveOriginalToo) {
            processExecutor.execute {
                ImageProcessor.saveJpeg(this, source, 98, prefix = "PROCAM_ORIGINAL_")
            }
        }

        runOnUiThread {
            pending++
            setStatus("Processing & Enhancing...")
        }

        processExecutor.execute {
            var faceFound = true
            var uri: Uri? = null
            try {
                var work = ImageProcessor.limit(source, prof.maxMegapixels)
                if (m == Mode.PORTRAIT) {
                    // Portrait for groups & couples: combine segmentation with all face boxes
                    val r = ImageProcessor.portrait(work, blur, tapPt)
                    faceFound = r.faceFound
                    ImageProcessor.recycleAll(work)
                    work = r.bitmap
                }

                // Auto Enhance on every photo (Phase B Requirement 9)
                val out = ImageProcessor.autoEnhance(
                    work, prof, look, autoEnhanceMode, skinSmoothMode, hdr
                )
                uri = ImageProcessor.saveJpeg(this, out, prof.jpegQuality)
                ImageProcessor.recycleAll(work, out, source)
            } catch (t: Throwable) {
                ImageProcessor.recycleAll(source)
            }

            runOnUiThread {
                pending--
                if (pending <= 0 && recording == null && !nightBusy && !panoCapturing && !sphereCapturing) setStatus(null)
                if (uri != null) {
                    lastUri = uri
                    lastMime = "image/jpeg"
                    loadThumb(uri)
                    if (m == Mode.PORTRAIT && !faceFound) toast("Portrait depth blur applied")
                } else {
                    toast("Could not save photo")
                }
            }
        }
    }

    // ------------------------------------------------------------- Video Recording
    private fun toggleRecording() {
        val vc = videoCapture ?: return
        val active = recording
        if (active != null) {
            active.stop()
            return
        }
        startNewVideoRecordingSegment(vc)
    }

    private fun startNewVideoRecordingSegment(vc: VideoCapture<Recorder>) {
        val segFile = File(cacheDir, "procam_seg_${System.currentTimeMillis()}.mp4")
        val fileOptions = FileOutputOptions.Builder(segFile).build()

        var prepared = vc.output.prepareRecording(this, fileOptions)
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) {
            @SuppressLint("MissingPermission")
            prepared = prepared.withAudioEnabled()
        }
        recording = prepared.start(ContextCompat.getMainExecutor(this)) { event -> onVideoEvent(event, segFile) }
    }

    // Flip camera while recording (Phase C Requirement 11)
    private fun flipCameraWhileRecording() {
        val rec = recording ?: return
        isFlippingVideo = true
        toast("Switching lens...")
        rec.stop()
    }

    private fun resumeNextVideoSegment() {
        val vc = videoCapture ?: return
        startNewVideoRecordingSegment(vc)
    }

    private fun takePhotoWhileRecording() {
        val ic = imageCapture ?: return
        btnPhotoWhileVideo.animate().scaleX(0.85f).scaleY(0.85f).setDuration(70).withEndAction {
            btnPhotoWhileVideo.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
        }.start()
        playSound(MediaActionSound.SHUTTER_CLICK)
        flashScreen()
        ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp: Bitmap? = try { toUpright(image) } catch (t: Throwable) { null }
                if (bmp != null) enqueueProcessing(bmp, Mode.PHOTO)
            }
            override fun onError(exception: ImageCaptureException) {}
        })
    }

    private fun onVideoEvent(event: VideoRecordEvent, segmentFile: File) {
        when (event) {
            is VideoRecordEvent.Start -> {
                playSound(MediaActionSound.START_VIDEO_RECORDING)
                paused = false
                btnPause.setImageResource(R.drawable.ic_pause)
                showRecordingUi(true)
            }
            is VideoRecordEvent.Status -> {
                val s = event.recordingStats.recordedDurationNanos / 1_000_000_000L
                setStatus(String.format(Locale.US, "REC  %02d:%02d", s / 60, s % 60))
            }
            is VideoRecordEvent.Finalize -> {
                recording = null
                if (segmentFile.exists() && segmentFile.length() > 0L) {
                    recordedVideoSegments.add(segmentFile)
                }

                if (isFlippingVideo) {
                    // Rebind camera with other lens and continue recording next segment
                    lensFront = !lensFront
                    btnFlip.animate().rotationBy(180f).setDuration(250).start()
                    bindCamera()
                } else {
                    // Recording truly stopped: concatenate all segments into one MP4!
                    playSound(MediaActionSound.STOP_VIDEO_RECORDING)
                    showRecordingUi(false)
                    val segmentsToMerge = ArrayList(recordedVideoSegments)
                    recordedVideoSegments.clear()

                    processExecutor.execute {
                        val finalUri = VideoSegmentManager.concatenateSegments(this, segmentsToMerge)
                        runOnUiThread {
                            if (finalUri != null) {
                                lastUri = finalUri
                                lastMime = "video/mp4"
                                loadThumb(finalUri)
                                toast("Video saved to Movies/ProCam")
                            } else {
                                toast("Video error saving file")
                            }
                        }
                    }
                }
            }
            else -> {}
        }
    }

    private fun showRecordingUi(on: Boolean) {
        modeBar.visibility = if (on) View.INVISIBLE else View.VISIBLE
        btnFlip.visibility = View.VISIBLE // Keeps flip visible so user can flip while recording!
        btnPause.visibility = if (on) View.VISIBLE else View.GONE
        btnPhotoWhileVideo.visibility = if (on) View.VISIBLE else View.GONE
        thumbnail.isEnabled = !on
        if (!on) setStatus(null)
        refreshModeBar()
    }

    // --------------------------------------------------------------- Gallery
    private fun openGallery() {
        galleryLauncher.launch(Intent(this, GalleryActivity::class.java))
    }

    private fun loadThumb(uri: Uri) {
        Thread {
            var bmp: Bitmap? = null
            try {
                bmp = if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(uri, Size(256, 256), null)
                } else {
                    val o = BitmapFactory.Options()
                    o.inSampleSize = 8
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                }
            } catch (e: Exception) {
                bmp = null
            }
            val result = bmp
            runOnUiThread { if (result != null) thumbnail.setImageBitmap(result) }
        }.start()
    }

    private fun loadLastMedia() {
        Thread {
            try {
                val proj = arrayOf(
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.MEDIA_TYPE
                )
                val sel = MediaStore.MediaColumns.DATA + " LIKE ? AND (" +
                    MediaStore.Files.FileColumns.MEDIA_TYPE + "=? OR " +
                    MediaStore.Files.FileColumns.MEDIA_TYPE + "=?)"
                val args = arrayOf(
                    "%/ProCam/%",
                    MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
                    MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
                )
                contentResolver.query(
                    MediaStore.Files.getContentUri("external"), proj, sel, args,
                    MediaStore.MediaColumns.DATE_ADDED + " DESC"
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val id = c.getLong(0)
                        val type = c.getInt(1)
                        val isVideo = type == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                        val base = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        val uri = ContentUris.withAppendedId(base, id)
                        runOnUiThread {
                            lastUri = uri
                            lastMime = if (isVideo) "video/mp4" else "image/jpeg"
                            loadThumb(uri)
                        }
                    } else {
                        runOnUiThread {
                            thumbnail.setImageResource(R.drawable.bg_circle)
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore
            }
        }.start()
    }
}
