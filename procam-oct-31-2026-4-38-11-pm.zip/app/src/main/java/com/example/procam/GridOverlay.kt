package com.example.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.View
import kotlin.math.abs

data class TrackedFace(
    val id: Int,
    val bounds: RectF
)

data class SphereTarget(
    val pitch: Float,
    val yaw: Float,
    var captured: Boolean = false
)

/**
 * Viewfinder overlay supporting:
 * 1. Rule-of-thirds grid lines
 * 2. Electronic level / horizon line with angle indicator and snap feedback
 * 3. Live ML Kit face tracking bounding boxes with tracking IDs (Phase B)
 * 4. Gyroscope "Hold steady" indicator (Phase A)
 * 5. Panorama guided alignment arrow (Phase E)
 * 6. Photo Sphere 360 target dots (Phase E)
 */
class GridOverlay @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var showGrid: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var showLevel: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var showHoldSteady: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var showPanoramaGuide: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var showSphereGuide: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private var rollAngle: Float = 0f
    private var wasLevel: Boolean = false

    private val detectedFaces = ArrayList<TrackedFace>()

    // Panorama guide
    private var panoCurrentAngle: Float = 0f
    private var panoProgressPct: Float = 0f
    private var panoIsLevel: Boolean = true

    // Photo Sphere guide
    private val sphereTargets = ArrayList<SphereTarget>()
    private var spherePitch: Float = 0f
    private var sphereYaw: Float = 0f

    private val yellow = Color.parseColor("#FFD60A")

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x44FFFFFF
        strokeWidth = 1.5f
    }

    private val levelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAAFFFFFF.toInt()
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }

    private val levelSnappedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow
        strokeWidth = 4.5f
        strokeCap = Paint.Cap.ROUND
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
        textAlign = Paint.Align.CENTER
    }

    private val faceBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val faceTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 22f
        textAlign = Paint.Align.LEFT
    }

    private val faceTagBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow
        style = Paint.Style.FILL
    }

    private val steadyBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC000000.toInt()
        style = Paint.Style.FILL
    }

    private val steadyTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow
        textSize = 30f
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }

    private val guideFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow
        style = Paint.Style.FILL
    }

    fun updateOrientation(roll: Float) {
        if (!showLevel) return
        rollAngle = roll
        val isLevel = abs(rollAngle) < 1.0f
        if (isLevel && !wasLevel) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        wasLevel = isLevel
        invalidate()
    }

    fun setFaces(faces: List<TrackedFace>) {
        detectedFaces.clear()
        detectedFaces.addAll(faces)
        invalidate()
    }

    fun clearFaces() {
        if (detectedFaces.isNotEmpty()) {
            detectedFaces.clear()
            invalidate()
        }
    }

    fun updatePanorama(currentAngle: Float, progressPct: Float, isLevel: Boolean) {
        panoCurrentAngle = currentAngle
        panoProgressPct = progressPct
        panoIsLevel = isLevel
        invalidate()
    }

    fun updateSphere(targets: List<SphereTarget>, pitch: Float, yaw: Float) {
        sphereTargets.clear()
        sphereTargets.addAll(targets)
        spherePitch = pitch
        sphereYaw = yaw
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        // 1. Rule of thirds grid
        if (showGrid) {
            for (i in 1..2) {
                canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, gridPaint)
                canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, gridPaint)
            }
        }

        // 2. Horizon level line
        if (showLevel) {
            val cx = w / 2f
            val cy = h / 2f
            val barLen = w * 0.18f
            val isLevel = abs(rollAngle) < 1.0f
            val paint = if (isLevel) levelSnappedPaint else levelPaint

            // Reference dash marks on left & right
            val refLen = 32f
            val gap = barLen + 24f
            canvas.drawLine(cx - gap - refLen, cy, cx - gap, cy, gridPaint)
            canvas.drawLine(cx + gap, cy, cx + gap + refLen, cy, gridPaint)

            // Center rotating level line
            canvas.save()
            canvas.rotate(-rollAngle, cx, cy)
            canvas.drawLine(cx - barLen / 2f, cy, cx + barLen / 2f, cy, paint)
            canvas.drawCircle(cx, cy, 3.5f, paint)
            canvas.restore()

            // Display angle in degrees when tilted
            if (!isLevel && abs(rollAngle) >= 1.0f && abs(rollAngle) <= 45.0f) {
                val sign = if (rollAngle > 0) "+" else ""
                val angleText = String.format(java.util.Locale.US, "%s%.0f\u00B0", sign, rollAngle)
                canvas.drawText(angleText, cx, cy - 28f, textPaint)
            }
        }

        // 3. Live ML Kit Face Tracking boxes (Phase B)
        if (detectedFaces.isNotEmpty()) {
            for (face in detectedFaces) {
                val rect = face.bounds
                // Draw elegant corner brackets or rounded bounding box
                val r = 12f
                canvas.drawRoundRect(rect, r, r, faceBoxPaint)

                // Face Tag (ID badge)
                val tagText = "Face #${face.id}"
                val tagW = faceTextPaint.measureText(tagText) + 16f
                val tagH = 28f
                val tagRect = RectF(rect.left, rect.top - tagH, rect.left + tagW, rect.top)
                canvas.drawRoundRect(tagRect, 6f, 6f, faceTagBgPaint)
                canvas.drawText(tagText, rect.left + 8f, rect.top - 8f, faceTextPaint)
            }
        }

        // 4. "Hold steady" notification when gyro detects excess camera motion
        if (showHoldSteady) {
            val badgeW = 200f
            val badgeH = 50f
            val bx = (w - badgeW) / 2f
            val by = h * 0.22f
            val rect = RectF(bx, by, bx + badgeW, by + badgeH)
            canvas.drawRoundRect(rect, 25f, 25f, steadyBgPaint)
            canvas.drawText("\u26A0 Hold steady", w / 2f, by + 34f, steadyTextPaint)
        }

        // 5. Panorama Guide (Phase E)
        if (showPanoramaGuide) {
            drawPanoramaGuide(canvas, w, h)
        }

        // 6. Photo Sphere 360 Guide (Phase E)
        if (showSphereGuide) {
            drawSphereGuide(canvas, w, h)
        }
    }

    private fun drawPanoramaGuide(canvas: Canvas, w: Float, h: Float) {
        val cy = h / 2f
        val guideLen = w * 0.7f
        val startX = (w - guideLen) / 2f
        val endX = startX + guideLen

        // Center guidance line
        guidePaint.color = if (panoIsLevel) yellow else 0x88FFFFFF.toInt()
        canvas.drawLine(startX, cy, endX, cy, guidePaint)

        // Arrow indicating current panning direction & position
        val progressX = startX + (guideLen * panoProgressPct.coerceIn(0f, 1f))
        val arrowSize = 22f

        val path = Path()
        path.moveTo(progressX, cy - arrowSize)
        path.lineTo(progressX + arrowSize, cy)
        path.lineTo(progressX, cy + arrowSize)
        path.close()
        guideFillPaint.color = yellow
        canvas.drawPath(path, guideFillPaint)

        // Text instruction
        val text = if (!panoIsLevel) "Align arrow on horizontal line" else "Pan smoothly \u2192"
        canvas.drawText(text, w / 2f, cy - 36f, textPaint)
    }

    private fun drawSphereGuide(canvas: Canvas, w: Float, h: Float) {
        val cx = w / 2f
        val cy = h / 2f

        // Center reticle
        canvas.drawCircle(cx, cy, 32f, guidePaint)
        canvas.drawCircle(cx, cy, 4f, guideFillPaint)

        // Target dots projected onto viewfinder
        for (target in sphereTargets) {
            val dPitch = target.pitch - spherePitch
            var dYaw = target.yaw - sphereYaw
            while (dYaw > 180f) dYaw -= 360f
            while (dYaw < -180f) dYaw += 360f

            val px = cx + (dYaw * (w / 60f))
            val py = cy - (dPitch * (h / 60f))

            if (px in 0f..w && py in 0f..h) {
                if (target.captured) {
                    guideFillPaint.color = 0xAA00E676.toInt() // Green for captured
                    canvas.drawCircle(px, py, 14f, guideFillPaint)
                } else {
                    guideFillPaint.color = yellow
                    canvas.drawCircle(px, py, 18f, guideFillPaint)
                    guidePaint.color = Color.WHITE
                    canvas.drawCircle(px, py, 22f, guidePaint)
                }
            }
        }

        canvas.drawText("Align center with yellow dots", cx, cy - 60f, textPaint)
    }
}
