package com.example.procam

import android.content.Context

/** Wrapper around SharedPreferences for all camera settings and toggles. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("procam_prefs", Context.MODE_PRIVATE)

    var profileKey: String
        get() = sp.getString("profile", "AUTO") ?: "AUTO"
        set(v) { sp.edit().putString("profile", v).apply() }

    var shutterSound: Boolean
        get() = sp.getBoolean("shutter_sound", true)
        set(v) { sp.edit().putBoolean("shutter_sound", v).apply() }

    var smartHdr: Boolean
        get() = sp.getBoolean("smart_hdr", true)
        set(v) { sp.edit().putBoolean("smart_hdr", v).apply() }

    var grid: Boolean
        get() = sp.getBoolean("grid", false)
        set(v) { sp.edit().putBoolean("grid", v).apply() }

    var levelLine: Boolean
        get() = sp.getBoolean("level_line", false)
        set(v) { sp.edit().putBoolean("level_line", v).apply() }

    var mirrorSelfie: Boolean
        get() = sp.getBoolean("mirror_selfie", true)
        set(v) { sp.edit().putBoolean("mirror_selfie", v).apply() }

    /** 0.2 = subtle, 0.6 = natural f/2.8, 1.0 = deep bokeh f/1.4. */
    var portraitBlur: Float
        get() = sp.getFloat("portrait_blur", 0.6f)
        set(v) { sp.edit().putFloat("portrait_blur", v).apply() }

    /** "HD" (720p), "FHD" (1080p) or "UHD" (4K). */
    var videoQuality: String
        get() = sp.getString("video_quality", "FHD") ?: "FHD"
        set(v) { sp.edit().putString("video_quality", v).apply() }

    var videoFps60: Boolean
        get() = sp.getBoolean("video_fps_60", false)
        set(v) { sp.edit().putBoolean("video_fps_60", v).apply() }

    var videoStabilization: Boolean
        get() = sp.getBoolean("video_stabilization", true)
        set(v) { sp.edit().putBoolean("video_stabilization", v).apply() }

    var lookIndex: Int
        get() = sp.getInt("look_index", 0)
        set(v) { sp.edit().putInt("look_index", v).apply() }

    var rawCapture: Boolean
        get() = sp.getBoolean("raw_capture", false)
        set(v) { sp.edit().putBoolean("raw_capture", v).apply() }

    var hdrPlus: Boolean
        get() = sp.getBoolean("hdr_plus", true)
        set(v) { sp.edit().putBoolean("hdr_plus", v).apply() }

    var saveOriginalToo: Boolean
        get() = sp.getBoolean("save_original_too", false)
        set(v) { sp.edit().putBoolean("save_original_too", v).apply() }

    var videoBitrate: String
        get() = sp.getString("video_bitrate", "Auto (High)") ?: "Auto (High)"
        set(v) { sp.edit().putString("video_bitrate", v).apply() }

    var videoCodecHevc: Boolean
        get() = sp.getBoolean("video_codec_hevc", false)
        set(v) { sp.edit().putBoolean("video_codec_hevc", v).apply() }

    var autoEnhance: String
        get() = sp.getString("auto_enhance", "Natural") ?: "Natural"
        set(v) { sp.edit().putString("auto_enhance", v).apply() }

    var skinSmoothing: String
        get() = sp.getString("skin_smoothing", "Low") ?: "Low"
        set(v) { sp.edit().putString("skin_smoothing", v).apply() }

    var gyroShakeGating: Boolean
        get() = sp.getBoolean("gyro_shake_gating", true)
        set(v) { sp.edit().putBoolean("gyro_shake_gating", v).apply() }
}
