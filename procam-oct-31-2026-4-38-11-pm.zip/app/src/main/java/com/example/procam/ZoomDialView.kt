package com.example.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Smooth horizontal zoom dial above shutter with ticks at 0.5x, 1x, 2x, 5x, 10x.
 * Supports drag and touch. Shows floating bubble with "X.Xx" and "digital" indicator past optical limit.
 * Haptic feedback at major tick stops.
 */
class ZoomDialView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var minZoom: Float = 1.0f
        set(value) {
            field = value
            invalidate()
        }

    var maxZoom: Float = 10.0f
        set(value) {
            field = value
            invalidate()
        }

    var opticalZoomMax: Float = 2.0f // Zoom above this is marked "digital"

    var currentZoom: Float = 1.0f
        private set

    var onZoomChanged: ((Float) -> Unit)? = null

    private val yellow = Color.parseColor("#FFD60A")

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x88FFFFFF.toInt()
        strokeWidth = 2f
    }

    private val majorTickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 3.5f
    }

    private val selectedTickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow
        strokeWidth = 4f
    }

    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAAFFFFFF.toInt()
        textSize = 22f
        textAlign = Paint.Align.CENTER
    }

    private val bubbleBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xEE16181F.toInt()
        style = Paint.Style.FILL
    }

    private val bubbleBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }

    private val bubbleTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = yellow
        textSize = 30f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    private val digitalBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xBBFFFFFF.toInt()
        textSize = 18f
        textAlign = Paint.Align.CENTER
    }

    private val stops = listOf(0.5f, 1.0f, 2.0f, 5.0f, 10.0f)
    private var lastHapticStop = -1f
    private var isDragging = false
    private var lastTouchX = 0f

    fun setZoom(zoom: Float, fromUser: Boolean = false) {
        val clamped = zoom.coerceIn(minZoom, maxZoom)
        if (abs(currentZoom - clamped) > 0.01f) {
            currentZoom = clamped
            checkHaptic(clamped)
            invalidate()
            if (fromUser) {
                onZoomChanged?.invoke(currentZoom)
            }
        }
    }

    private fun checkHaptic(zoom: Float) {
        for (stop in stops) {
            if (abs(zoom - stop) < 0.08f) {
                if (lastHapticStop != stop) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    lastHapticStop = stop
                }
                return
            }
        }
        lastHapticStop = -1f
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                isDragging = true
                lastTouchX = event.x
                parent?.requestDisallowInterceptTouchEvent(true)
                handleDrag(event.x)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (isDragging) {
                    handleDrag(event.x)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun handleDrag(touchX: Float) {
        val w = width.toFloat()
        if (w <= 0f) return
        val cx = w / 2f
        val delta = (touchX - cx) / (w * 0.42f)
        // Logarithmic scale for natural zoom feel
        val logMin = log10(minZoom)
        val logMax = log10(maxZoom)
        val logCur = log10(currentZoom)

        val newLog = (logCur + (touchX - lastTouchX) * 0.005f).coerceIn(logMin, logMax)
        lastTouchX = touchX
        val newZoom = 10f.pow(newLog)
        setZoom(newZoom, true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        val cx = w / 2f
        val cy = h * 0.65f

        // Draw ticks horizontally
        val logCur = log10(currentZoom)
        val logMin = log10(minZoom)
        val logMax = log10(maxZoom)

        val pixelsPerDecade = w * 0.75f

        // Draw sub-ticks and stops
        for (stop in stops) {
            if (stop < minZoom - 0.05f || stop > maxZoom + 0.05f) continue
            val logStop = log10(stop)
            val x = cx + (logStop - logCur) * pixelsPerDecade

            if (x in -50f..(w + 50f)) {
                val isSelected = abs(currentZoom - stop) < 0.12f
                val paint = if (isSelected) selectedTickPaint else majorTickPaint
                val tickHeight = 22f
                canvas.drawLine(x, cy - tickHeight, x, cy + tickHeight, paint)

                val label = if (stop < 1f) String.format(Locale.US, "%.1fx", stop) else "${stop.toInt()}x"
                canvas.drawText(label, x, cy + tickHeight + 24f, labelPaint)
            }
        }

        // Draw intermediate minor ticks
        val minorValues = listOf(0.7f, 1.5f, 3.0f, 4.0f, 7.0f, 8.0f)
        for (v in minorValues) {
            if (v < minZoom || v > maxZoom) continue
            val logV = log10(v)
            val x = cx + (logV - logCur) * pixelsPerDecade
            if (x in 0f..w) {
                canvas.drawLine(x, cy - 10f, x, cy + 10f, tickPaint)
            }
        }

        // Center pointer
        canvas.drawLine(cx, cy - 28f, cx, cy + 28f, selectedTickPaint)

        // Center floating indicator bubble
        val bubbleW = 120f
        val bubbleH = 48f
        val bx = cx - bubbleW / 2f
        val by = cy - 64f
        val rect = RectF(bx, by, bx + bubbleW, by + bubbleH)
        canvas.drawRoundRect(rect, 16f, 16f, bubbleBgPaint)
        canvas.drawRoundRect(rect, 16f, 16f, bubbleBorderPaint)

        val zoomStr = String.format(Locale.US, "%.1fx", currentZoom)
        val isDigital = currentZoom > (opticalZoomMax + 0.15f)

        if (isDigital) {
            canvas.drawText(zoomStr, cx, by + 26f, bubbleTextPaint)
            canvas.drawText("digital", cx, by + 42f, digitalBadgePaint)
        } else {
            canvas.drawText(zoomStr, cx, by + 34f, bubbleTextPaint)
        }
    }
}
