package com.example.procam

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import java.util.Locale

/** Full offline camera settings screen built in code. */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        prefs = Prefs(this)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#0B0B0F"))
        container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setPadding(dp(16), dp(12), dp(16), dp(32))
        scroll.addView(container)
        setContentView(scroll)
        build()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun build() {
        container.removeAllViews()

        val back = text("<  Back to Camera", 16f, Color.parseColor("#FFD60A"), true)
        back.setPadding(0, dp(8), dp(16), dp(16))
        back.setOnClickListener { finish() }
        container.addView(back)
        container.addView(text("Settings", 28f, Color.WHITE, true))

        section("Phone tuning & Device Profiles")
        val active = Profiles.resolve(this, prefs.profileKey)
        val ram = String.format(Locale.US, "%.1f", Profiles.totalRamGb(this))
        note("Detected hardware: " + Profiles.deviceName() + " (" + ram + " GB RAM)\nActive profile: " + active.label)
        val currentProfileLabel = if (prefs.profileKey == "AUTO") "Auto (${active.label})" else active.label
        row("Device profile", currentProfileLabel) {
            val names = ArrayList<String>()
            names.add("Auto (detect my phone)")
            for (p in Profiles.ALL) names.add(p.label)
            val checked = if (prefs.profileKey == "AUTO") 0 else
                (Profiles.ALL.indexOfFirst { it.key == prefs.profileKey } + 1).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle("Select Device Profile")
                .setSingleChoiceItems(names.toTypedArray(), checked) { d, which ->
                    prefs.profileKey = if (which == 0) "AUTO" else Profiles.ALL[which - 1].key
                    d.dismiss()
                    build()
                }
                .setNeutralButton("Reset to Auto") { d, _ ->
                    prefs.profileKey = "AUTO"
                    d.dismiss()
                    build()
                }
                .show()
        }
        note("Profile parameters: Sharpening ${(active.sharpen * 100).toInt()}%, Noise Reduction ${(active.noiseReduction * 100).toInt()}%, HDR ${(active.hdrStrength * 100).toInt()}%, JPEG ${active.jpegQuality}%, Night frames: ${active.nightFrames}")

        section("Photo Processing & Quality")
        row("Auto Enhance", prefs.autoEnhance) {
            val options = arrayOf("Off", "Natural", "Strong")
            val checked = options.indexOf(prefs.autoEnhance).coerceAtLeast(1)
            AlertDialog.Builder(this)
                .setTitle("Auto Enhance")
                .setSingleChoiceItems(options, checked) { d, which ->
                    prefs.autoEnhance = options[which]
                    d.dismiss()
                    build()
                }
                .show()
        }
        note("Face-aware exposure, shadow lift, CLAHE local contrast, skin-tone protected AWB, and vibrance.")
        row("Skin smoothing", prefs.skinSmoothing) {
            val options = arrayOf("Off", "Low", "Medium")
            val checked = options.indexOf(prefs.skinSmoothing).coerceAtLeast(1)
            AlertDialog.Builder(this)
                .setTitle("Gentle skin smoothing")
                .setSingleChoiceItems(options, checked) { d, which ->
                    prefs.skinSmoothing = options[which]
                    d.dismiss()
                    build()
                }
                .show()
        }
        note("Applies gentle edge-preserving bilateral smoothing strictly inside detected face regions.")
        toggle("Save original too", "Saves uncompressed original photo alongside enhanced image", prefs.saveOriginalToo) { prefs.saveOriginalToo = it }
        toggle("Pixel-style HDR+ burst", "Captures aligned fast bracketed frames for crisp highlights & shadow detail", prefs.hdrPlus) { prefs.hdrPlus = it }
        toggle("Smart HDR tone", "Lifts deep shadows and calms highlight clipping", prefs.smartHdr) { prefs.smartHdr = it }
        toggle("Gyroscope shake gating", "Waits for phone to be calm and rejects shaky frames", prefs.gyroShakeGating) { prefs.gyroShakeGating = it }
        row("Portrait depth blur", blurName()) {
            val names = arrayOf("Soft (f/4.0)", "Natural (f/2.8)", "Strong (f/1.4)")
            val values = floatArrayOf(0.3f, 0.6f, 0.9f)
            var checked = 1
            for (i in values.indices) if (kotlin.math.abs(values[i] - prefs.portraitBlur) < 0.15f) checked = i
            AlertDialog.Builder(this)
                .setTitle("Portrait background blur")
                .setSingleChoiceItems(names, checked) { d, which ->
                    prefs.portraitBlur = values[which]
                    d.dismiss()
                    build()
                }
                .show()
        }
        toggle("Mirror front selfies", "Saved selfie matches viewfinder orientation", prefs.mirrorSelfie) { prefs.mirrorSelfie = it }

        section("Video")
        val bitrateDesc = when (prefs.videoQuality) {
            "UHD" -> "4K (3840x2160) @ ~45-50 Mbps target bitrate"
            "HD" -> "720p (1280x720) @ ~12 Mbps target bitrate"
            else -> "1080p (1920x1080) @ ~28-30 Mbps target bitrate"
        }
        row("Video resolution", qualityName() + " — " + bitrateDesc) {
            val names = arrayOf("HD 720p", "Full HD 1080p", "4K Ultra HD (if supported)")
            val keys = arrayOf("HD", "FHD", "UHD")
            val checked = keys.indexOf(prefs.videoQuality).coerceAtLeast(1)
            AlertDialog.Builder(this)
                .setTitle("Video resolution")
                .setSingleChoiceItems(names, checked) { d, which ->
                    prefs.videoQuality = keys[which]
                    d.dismiss()
                    build()
                }
                .show()
        }
        row("Video target bitrate", prefs.videoBitrate) {
            val options = arrayOf("Auto (High)", "30 Mbps", "50 Mbps")
            val checked = options.indexOf(prefs.videoBitrate).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle("Target encoding bitrate")
                .setSingleChoiceItems(options, checked) { d, which ->
                    prefs.videoBitrate = options[which]
                    d.dismiss()
                    build()
                }
                .show()
        }
        toggle("HEVC (H.265) video encoding", "More efficient compression if supported by hardware encoder", prefs.videoCodecHevc) { prefs.videoCodecHevc = it }
        toggle("High frame rate (60 FPS)", "Smooth motion when supported by camera sensor", prefs.videoFps60) { prefs.videoFps60 = it }
        toggle("Video stabilization (EIS / OIS)", "Reduces shake and camera movement during recording", prefs.videoStabilization) { prefs.videoStabilization = it }

        section("Camera Viewfinder")
        toggle("Shutter click sound", "Audible feedback for photos and video recording", prefs.shutterSound) { prefs.shutterSound = it }
        toggle("Rule-of-thirds grid", "Assists framing and compositional alignment", prefs.grid) { prefs.grid = it }
        toggle("Level / Horizon line", "Shows live roll angle and snaps gold when level", prefs.levelLine) { prefs.levelLine = it }

        section("Pro Mode & Advanced")
        toggle("RAW (DNG) capture in Pro mode", "Saves uncompressed DNG alongside JPEG if supported", prefs.rawCapture) { prefs.rawCapture = it }

        section("Privacy & Storage")
        note("ProCam runs 100% offline without the INTERNET permission. No trackers, no network calls, zero data leaves your phone. Photos are saved in Pictures/ProCam and videos in Movies/ProCam.")
    }

    private fun blurName(): String = when {
        prefs.portraitBlur < 0.45f -> "Soft (f/4.0)"
        prefs.portraitBlur < 0.75f -> "Natural (f/2.8)"
        else -> "Strong (f/1.4)"
    }

    private fun qualityName(): String = when (prefs.videoQuality) {
        "HD" -> "HD 720p"
        "UHD" -> "4K Ultra HD"
        else -> "Full HD 1080p"
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun section(title: String) {
        val tv = text(title.uppercase(), 12f, Color.parseColor("#7F8AA3"), true)
        tv.setPadding(0, dp(24), 0, dp(6))
        container.addView(tv)
    }

    private fun note(t: String) {
        val tv = text(t, 13f, Color.parseColor("#9AA3B5"), false)
        tv.setPadding(0, dp(6), 0, dp(6))
        container.addView(tv)
    }

    private fun row(title: String, value: String, onClick: () -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundResource(R.drawable.bg_row)
        box.setPadding(dp(16), dp(12), dp(16), dp(12))
        box.addView(text(title, 16f, Color.WHITE, false))
        box.addView(text(value, 13f, Color.parseColor("#FFD60A"), false))
        box.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6)
        container.addView(box, lp)
    }

    private fun toggle(title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setBackgroundResource(R.drawable.bg_row)
        box.setPadding(dp(16), dp(12), dp(16), dp(12))
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(text(title, 16f, Color.WHITE, false))
        left.addView(text(sub, 13f, Color.parseColor("#9AA3B5"), false))
        box.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(this)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        box.addView(sw)
        box.setOnClickListener { sw.toggle() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6)
        container.addView(box, lp)
    }
}
