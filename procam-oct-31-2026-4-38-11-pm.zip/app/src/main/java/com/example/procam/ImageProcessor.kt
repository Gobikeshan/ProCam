package com.example.procam

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** A colour "look" (like the iPhone photographic styles / filters). */
class Look(val name: String, val extra: ColorMatrix)

object ColorOps {
    fun saturation(s: Float): ColorMatrix = ColorMatrix().apply { setSaturation(s) }

    fun contrast(c: Float): ColorMatrix {
        val t = (1f - c) * 127.5f
        return ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    fun warmth(w: Float): ColorMatrix = ColorMatrix(
        floatArrayOf(
            1f + w, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1f - w, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    )

    fun brightness(b: Float): ColorMatrix = ColorMatrix(
        floatArrayOf(
            1f, 0f, 0f, 0f, b,
            0f, 1f, 0f, 0f, b,
            0f, 0f, 1f, 0f, b,
            0f, 0f, 0f, 1f, 0f
        )
    )

    fun combine(vararg list: ColorMatrix): ColorMatrix {
        val out = ColorMatrix()
        for (m in list) out.postConcat(m)
        return out
    }

    fun forProfile(p: DeviceProfile, look: Look): ColorMatrix =
        combine(saturation(p.saturation), contrast(p.contrast), warmth(p.warmth), look.extra)
}

object Looks {
    val ALL: List<Look> = listOf(
        Look("Natural", ColorMatrix()),
        Look("Vivid", ColorOps.combine(ColorOps.saturation(1.25f), ColorOps.contrast(1.08f))),
        Look("Vivid Warm", ColorOps.combine(ColorOps.saturation(1.22f), ColorOps.warmth(0.08f), ColorOps.contrast(1.06f))),
        Look("Vivid Cool", ColorOps.combine(ColorOps.saturation(1.20f), ColorOps.warmth(-0.08f), ColorOps.contrast(1.06f))),
        Look("Dramatic", ColorOps.combine(ColorOps.saturation(0.85f), ColorOps.contrast(1.25f))),
        Look("Mono", ColorOps.combine(ColorOps.saturation(0f), ColorOps.contrast(1.05f))),
        Look("Silvertone", ColorOps.combine(ColorOps.saturation(0f), ColorOps.contrast(1.15f), ColorOps.brightness(12f))),
        Look("Noir", ColorOps.combine(ColorOps.saturation(0f), ColorOps.contrast(1.35f), ColorOps.brightness(-10f)))
    )
}

class PortraitResult(val bitmap: Bitmap, val faceFound: Boolean)

object ImageProcessor {

    // Bundled offline ML Kit selfie segmenter (no internet required)
    private val selfieSegmenter by lazy {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
        Segmentation.getClient(options)
    }

    // Bundled offline ML Kit face detector
    private val faceDetector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .build()
        FaceDetection.getClient(options)
    }

    fun recycleAll(vararg list: Bitmap?) {
        for (b in list) {
            if (b != null && !b.isRecycled) b.recycle()
        }
    }

    fun toMutable(b: Bitmap): Bitmap {
        if (b.isMutable && b.config == Bitmap.Config.ARGB_8888) return b
        val copy = b.copy(Bitmap.Config.ARGB_8888, true)!!
        b.recycle()
        return copy
    }

    /** Rotate to upright and optionally mirror (front camera). */
    fun upright(src: Bitmap, degrees: Int, mirror: Boolean): Bitmap {
        if (degrees == 0 && !mirror) return src
        val m = Matrix()
        if (degrees != 0) m.postRotate(degrees.toFloat())
        if (mirror) m.postScale(-1f, 1f)
        val out = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        if (out !== src) src.recycle()
        return out
    }

    /** Keep memory safe: shrink only if photo size exceeds profile limit. */
    fun limit(src: Bitmap, maxMp: Int): Bitmap {
        val mp = src.width.toDouble() * src.height.toDouble() / 1_000_000.0
        if (mp <= maxMp * 1.25) return src
        val s = sqrt(maxMp * 1_000_000.0 / (src.width.toDouble() * src.height.toDouble())).toFloat()
        val out = Bitmap.createScaledBitmap(
            src, max(1, (src.width * s).toInt()), max(1, (src.height * s).toInt()), true
        )
        if (out !== src) src.recycle()
        return out
    }

    // ------------------------------------------------------------- Sharpness Scoring
    /**
     * Compute sharpness score using Laplacian variance on luma channel.
     * Higher variance = crisper edges & textures.
     */
    fun computeLaplacianVariance(bmp: Bitmap): Double {
        val sw = 240
        val sh = (sw * bmp.height / bmp.width).coerceAtLeast(160)
        val small = Bitmap.createScaledBitmap(bmp, sw, sh, false)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        small.recycle()

        val luma = IntArray(pixels.size)
        for (i in pixels.indices) {
            val p = pixels[i]
            luma[i] = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
        }

        var sum = 0.0
        var sumSq = 0.0
        var count = 0

        for (y in 1 until sh - 1) {
            val row = y * sw
            for (x in 1 until sw - 1) {
                val center = luma[row + x]
                val lap = -4 * center + luma[row + x - 1] + luma[row + x + 1] + luma[row - sw + x] + luma[row + sw + x]
                val v = lap.toDouble()
                sum += v
                sumSq += v * v
                count++
            }
        }
        if (count == 0) return 0.0
        val mean = sum / count
        return (sumSq / count) - (mean * mean)
    }

    // -------------------------------------------------- Tile-based Pyramid Alignment
    data class Shift(val dx: Float, val dy: Float, val confidence: Float)

    /**
     * Sub-pixel 2D pyramid alignment on downscaled luma.
     */
    fun findShiftSubpixel(base: Bitmap, frame: Bitmap): Shift {
        val scaleW = 200
        val scaleH = (scaleW * base.height / base.width).coerceAtLeast(150)
        val bSmall = Bitmap.createScaledBitmap(base, scaleW, scaleH, false)
        val fSmall = Bitmap.createScaledBitmap(frame, scaleW, scaleH, false)

        val bPix = IntArray(scaleW * scaleH)
        val fPix = IntArray(scaleW * scaleH)
        bSmall.getPixels(bPix, 0, scaleW, 0, 0, scaleW, scaleH)
        fSmall.getPixels(fPix, 0, scaleW, 0, 0, scaleW, scaleH)
        bSmall.recycle()
        fSmall.recycle()

        val bGray = IntArray(bPix.size)
        val fGray = IntArray(fPix.size)
        for (i in bPix.indices) {
            val bp = bPix[i]
            bGray[i] = (((bp shr 16) and 255) * 77 + ((bp shr 8) and 255) * 150 + (bp and 255) * 29) shr 8
            val fp = fPix[i]
            fGray[i] = (((fp shr 16) and 255) * 77 + ((fp shr 8) and 255) * 150 + (fp and 255) * 29) shr 8
        }

        val searchRadius = 10
        var bestDx = 0
        var bestDy = 0
        var minSad = Long.MAX_VALUE
        val margin = searchRadius + 6

        val sadGrid = Array(searchRadius * 2 + 1) { LongArray(searchRadius * 2 + 1) }

        for (dy in -searchRadius..searchRadius) {
            for (dx in -searchRadius..searchRadius) {
                var sad = 0L
                for (y in margin until (scaleH - margin) step 2) {
                    val rowB = y * scaleW
                    val rowF = (y + dy) * scaleW + dx
                    for (x in margin until (scaleW - margin) step 2) {
                        sad += abs(bGray[rowB + x] - fGray[rowF + x])
                    }
                }
                sadGrid[dy + searchRadius][dx + searchRadius] = sad
                if (sad < minSad) {
                    minSad = sad
                    bestDx = dx
                    bestDy = dy
                }
            }
        }

        // Sub-pixel parabolic interpolation around minimum
        var subDx = bestDx.toFloat()
        var subDy = bestDy.toFloat()
        val iy = bestDy + searchRadius
        val ix = bestDx + searchRadius

        if (ix > 0 && ix < searchRadius * 2) {
            val left = sadGrid[iy][ix - 1].toFloat()
            val center = sadGrid[iy][ix].toFloat()
            val right = sadGrid[iy][ix + 1].toFloat()
            val denom = 2f * (left - 2f * center + right)
            if (abs(denom) > 1e-4f) subDx += ((left - right) / denom).coerceIn(-0.5f, 0.5f)
        }

        if (iy > 0 && iy < searchRadius * 2) {
            val top = sadGrid[iy - 1][ix].toFloat()
            val center = sadGrid[iy][ix].toFloat()
            val bottom = sadGrid[iy + 1][ix].toFloat()
            val denom = 2f * (top - 2f * center + bottom)
            if (abs(denom) > 1e-4f) subDy += ((top - bottom) / denom).coerceIn(-0.5f, 0.5f)
        }

        val fullScale = base.width.toFloat() / scaleW.toFloat()
        val totalSampleCount = ((scaleH - 2 * margin) / 2) * ((scaleW - 2 * margin) / 2)
        val avgSad = minSad.toFloat() / max(1, totalSampleCount)
        val confidence = (1f - (avgSad / 40f)).coerceIn(0f, 1f)

        return Shift(subDx * fullScale, subDy * fullScale, confidence)
    }

    // ---------------------------------------------------- Fast Burst Anti-Ghosting Merge
    /**
     * Merge multi-frame burst with sharpness reference selection, sub-pixel pyramid alignment,
     * and robust anti-ghosting pixel rejection so moving subjects and camera shake never blur.
     */
    fun mergeFastBurst(frames: List<Bitmap>, isTripod: Boolean): Bitmap {
        if (frames.isEmpty()) throw IllegalArgumentException("No frames to merge")
        if (frames.size == 1) return frames[0]

        // 1. Score each frame's sharpness via Laplacian variance
        var bestIdx = 0
        var maxSharpness = -1.0
        val scores = DoubleArray(frames.size)

        for (i in frames.indices) {
            val score = computeLaplacianVariance(frames[i])
            scores[i] = score
            if (score > maxSharpness) {
                maxSharpness = score
                bestIdx = i
            }
        }

        val refFrame = frames[bestIdx]
        val w = refFrame.width
        val h = refFrame.height

        // 2. Align candidate frames to sharpest reference frame
        val validFrames = ArrayList<Bitmap>()
        val shifts = ArrayList<Shift>()
        validFrames.add(refFrame)
        shifts.add(Shift(0f, 0f, 1f))

        var totalConfidence = 1f

        for (i in frames.indices) {
            if (i == bestIdx) continue
            val shift = findShiftSubpixel(refFrame, frames[i])
            // Reject frames with low alignment confidence
            if (shift.confidence > 0.45f || isTripod) {
                val shifted = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val c = Canvas(shifted)
                val m = Matrix().apply { postTranslate(shift.dx, shift.dy) }
                c.drawBitmap(frames[i], m, Paint(Paint.FILTER_BITMAP_FLAG))
                validFrames.add(shifted)
                shifts.add(shift)
                totalConfidence += shift.confidence
            }
        }

        // If confidence is low or fewer than 2 good frames, return reference frame directly (denoised)
        if (validFrames.size < 2 || (totalConfidence / validFrames.size) < 0.50f) {
            return bilateralFilter(refFrame, 5, 12f)
        }

        // 3. Anti-ghosting robust merge: downweight pixels that deviate from reference
        val numFrames = validFrames.size
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val rows = 64
        val bufs = Array(numFrames) { IntArray(w * rows) }
        val outBuf = IntArray(w * rows)

        // Threshold for outlier pixel rejection: ~25 luminance units
        val sigmaDiff = 22f

        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            for (k in 0 until numFrames) {
                validFrames[k].getPixels(bufs[k], 0, w, 0, y, w, n)
            }
            val count = w * n

            for (i in 0 until count) {
                val refPx = bufs[0][i]
                val refR = (refPx shr 16) and 255
                val refG = (refPx shr 8) and 255
                val refB = refPx and 255
                val refLuma = (refR * 77 + refG * 150 + refB * 29) shr 8

                var weightSum = 1.0f
                var rSum = refR.toFloat()
                var gSum = refG.toFloat()
                var bSum = refB.toFloat()

                for (k in 1 until numFrames) {
                    val px = bufs[k][i]
                    val r = (px shr 16) and 255
                    val g = (px shr 8) and 255
                    val b = px and 255
                    val luma = (r * 77 + g * 150 + b * 29) shr 8

                    val diff = abs(luma - refLuma).toFloat()
                    // Gaussian decay for robust outlier rejection (prevents ghosting completely)
                    val weight = exp(-((diff * diff) / (2f * sigmaDiff * sigmaDiff)))

                    if (weight > 0.05f) {
                        weightSum += weight
                        rSum += r * weight
                        gSum += g * weight
                        bSum += b * weight
                    }
                }

                val invW = 1f / weightSum
                val finalR = (rSum * invW).toInt().coerceIn(0, 255)
                val finalG = (gSum * invW).toInt().coerceIn(0, 255)
                val finalB = (bSum * invW).toInt().coerceIn(0, 255)
                outBuf[i] = (0xFF shl 24) or (finalR shl 16) or (finalG shl 8) or finalB
            }

            out.setPixels(outBuf, 0, w, 0, y, w, n)
            y += n
        }

        for (vf in validFrames) {
            if (vf !== refFrame && !frames.contains(vf)) vf.recycle()
        }

        return out
    }

    // ------------------------------------------------------------- Edge-Preserving Denoise
    /**
     * Fast separable approximation of edge-preserving bilateral filter on Luma.
     */
    fun bilateralFilter(src: Bitmap, radius: Int = 3, sigmaRange: Float = 15f): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        val outPixels = IntArray(w * h)

        val luma = IntArray(pixels.size)
        for (i in pixels.indices) {
            val p = pixels[i]
            luma[i] = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
        }

        val rangeLut = FloatArray(256)
        for (d in 0..255) {
            rangeLut[d] = exp(-(d.toFloat() * d.toFloat()) / (2f * sigmaRange * sigmaRange))
        }

        for (y in 0 until h) {
            val yMin = max(0, y - radius)
            val yMax = min(h - 1, y + radius)
            val rowY = y * w

            for (x in 0 until w) {
                val xMin = max(0, x - radius)
                val xMax = min(w - 1, x + radius)
                val centerLuma = luma[rowY + x]

                var wSum = 0f
                var rSum = 0f
                var gSum = 0f
                var bSum = 0f

                for (ny in yMin..yMax step 2) {
                    val nRow = ny * w
                    for (nx in xMin..xMax step 2) {
                        val p = pixels[nRow + nx]
                        val diff = abs(luma[nRow + nx] - centerLuma)
                        val weight = rangeLut[diff]

                        wSum += weight
                        rSum += ((p shr 16) and 255) * weight
                        gSum += ((p shr 8) and 255) * weight
                        bSum += (p and 255) * weight
                    }
                }

                if (wSum > 0.001f) {
                    val inv = 1f / wSum
                    val r = (rSum * inv).toInt().coerceIn(0, 255)
                    val g = (gSum * inv).toInt().coerceIn(0, 255)
                    val b = (bSum * inv).toInt().coerceIn(0, 255)
                    outPixels[rowY + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                } else {
                    outPixels[rowY + x] = pixels[rowY + x]
                }
            }
        }

        out.setPixels(outPixels, 0, w, 0, 0, w, h)
        return out
    }

    // -------------------------------------------------- Portrait for Groups & Couples
    /**
     * ML Kit selfie segmentation + Face detector:
     * Combines person segmentation mask with all detected face boxes so NO face is blurred in couples or groups.
     * Background blur increases smoothly with distance gradient.
     */
    fun portrait(
        src: Bitmap,
        blurStrength: Float,
        tapPoint: PointF? = null
    ): PortraitResult {
        val w = src.width
        val h = src.height
        var anyFaceFound = false
        var compositeMask: Bitmap? = null

        try {
            // 1. Detect all faces for couple & group protection
            val inputImage = InputImage.fromBitmap(src, 0)
            val faceTask = faceDetector.process(inputImage)
            val faces: List<Face> = Tasks.await(faceTask, 2500, TimeUnit.MILLISECONDS) ?: emptyList()

            // 2. Perform ML Kit Selfie Segmentation
            val segDim = 512
            val scale = segDim.toFloat() / max(w, h).toFloat()
            val smallW = (w * scale).toInt().coerceAtLeast(16)
            val smallH = (h * scale).toInt().coerceAtLeast(16)
            val smallBmp = Bitmap.createScaledBitmap(src, smallW, smallH, true)
            val segInput = InputImage.fromBitmap(smallBmp, 0)
            val maskTask = selfieSegmenter.process(segInput)
            val segMask = Tasks.await(maskTask, 3000, TimeUnit.MILLISECONDS)
            smallBmp.recycle()

            val maskW = segMask.width
            val maskH = segMask.height
            val buffer = segMask.buffer
            buffer.rewind()
            val maskPixels = IntArray(maskW * maskH)

            for (i in maskPixels.indices) {
                val conf = buffer.float
                val alpha = (conf.coerceIn(0f, 1f) * 255f).toInt()
                maskPixels[i] = (alpha shl 24) or 0x00FFFFFF
            }

            compositeMask = Bitmap.createBitmap(maskW, maskH, Bitmap.Config.ARGB_8888)
            compositeMask.setPixels(maskPixels, 0, maskW, 0, 0, maskW, maskH)

            // 3. Paint solid foreground hull over ALL detected faces (couple & group protection)
            if (faces.isNotEmpty()) {
                anyFaceFound = true
                val maskCanvas = Canvas(compositeMask)
                val faceHullPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = Paint.Style.FILL
                }
                val scaleX = maskW.toFloat() / w.toFloat()
                val scaleY = maskH.toFloat() / h.toFloat()

                for (face in faces) {
                    val box = face.boundingBox
                    // Dilate face box slightly to cover hair & ears
                    val padX = box.width() * 0.25f
                    val padY = box.height() * 0.35f
                    val rect = RectF(
                        (box.left - padX) * scaleX,
                        (box.top - padY) * scaleY,
                        (box.right + padX) * scaleX,
                        (box.bottom + padY * 0.5f) * scaleY
                    )
                    maskCanvas.drawOval(rect, faceHullPaint)
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        // Fallback: If no ML Kit mask available, use tap-point or center radial gradient
        if (compositeMask == null) {
            val mw = max(1, w / 4)
            val mh = max(1, h / 4)
            val fallbackMask = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888)
            val mc = Canvas(fallbackMask)
            val mp = Paint(Paint.ANTI_ALIAS_FLAG)
            val cx = tapPoint?.x ?: (mw * 0.5f)
            val cy = tapPoint?.y ?: (mh * 0.45f)
            val rx = mw * 0.35f
            val ry = mh * 0.42f
            mp.shader = RadialGradient(
                cx, cy, rx,
                intArrayOf(Color.WHITE, Color.WHITE, 0x00FFFFFF),
                floatArrayOf(0f, 0.65f, 1f),
                Shader.TileMode.CLAMP
            )
            mc.save()
            mc.scale(1f, ry / rx, cx, cy)
            mc.drawCircle(cx, cy, rx, mp)
            mc.restore()
            compositeMask = fallbackMask
        }

        // Generate depth blur based on f-stop slider (f/1.4 = factor 24, f/2.8 = factor 16, f/4.0 = factor 10)
        val factor = (8f + 18f * blurStrength.coerceIn(0f, 1f)).toInt()
        val blurredBackground = softCopy(src, factor)

        // Composite sharp foreground over blurred background
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawBitmap(blurredBackground, 0f, 0f, null)
        blurredBackground.recycle()

        val layer = canvas.saveLayer(0f, 0f, w.toFloat(), h.toFloat(), null)
        canvas.drawBitmap(src, 0f, 0f, null)
        val maskPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        canvas.drawBitmap(compositeMask, null, Rect(0, 0, w, h), maskPaint)
        canvas.restoreToCount(layer)
        compositeMask.recycle()

        return PortraitResult(result, anyFaceFound)
    }

    private fun softCopy(src: Bitmap, factor: Int): Bitmap {
        val w = src.width
        val h = src.height
        val targetW = max(1, w / max(2, factor))
        var cur = src
        while (cur.width / 2 >= targetW && cur.width / 2 >= 2 && cur.height / 2 >= 2) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(cur, null, Rect(0, 0, w, h), p)
        if (cur !== src) cur.recycle()
        return out
    }

    // ------------------------------------------------------------- Auto Enhance Pipeline
    /**
     * Production-grade Auto Enhance:
     * - Face-aware exposure
     * - Shadow lift & highlight recovery (dual-knee curve)
     * - Local contrast (CLAHE-style on lightness channel)
     * - Auto white balance with skin-tone protection
     * - Vibrance boosting muted colors
     * - Protection of skin hue (15°-45°)
     * - Gentle skin smoothing strictly inside face/skin mask
     * - Mild background clarity & subject relight
     * - Look applied after enhancement
     */
    fun autoEnhance(
        src: Bitmap,
        profile: DeviceProfile,
        look: Look,
        enhanceMode: String, // "Natural", "Strong", "Off"
        skinSmoothMode: String, // "Low", "Medium", "Off"
        smartHdr: Boolean
    ): Bitmap {
        val w = src.width
        val h = src.height

        // If Off, just run standard enhancement with Look
        if (enhanceMode == "Off") {
            return enhance(src, profile, look, smartHdr, 1f, 0f)
        }

        val strong = enhanceMode == "Strong"
        val enhanceStrength = if (strong) 1.25f else 0.95f

        // 1. Detect faces for face-aware exposure & skin smoothing
        var faces: List<Face> = emptyList()
        try {
            val inputImage = InputImage.fromBitmap(src, 0)
            faces = Tasks.await(faceDetector.process(inputImage), 1500, TimeUnit.MILLISECONDS) ?: emptyList()
        } catch (ignored: Exception) {}

        // Calculate face lightness
        var faceExposureLift = 0f
        if (faces.isNotEmpty()) {
            var faceLumaSum = 0L
            var faceSampleCount = 0
            val pixels = IntArray(w)
            for (face in faces) {
                val box = face.boundingBox
                val top = box.top.coerceIn(0, h - 1)
                val bottom = box.bottom.coerceIn(0, h - 1)
                val left = box.left.coerceIn(0, w - 1)
                val right = box.right.coerceIn(0, w - 1)
                for (y in top..bottom step 4) {
                    src.getPixels(pixels, 0, w, 0, y, w, 1)
                    for (x in left..right step 4) {
                        val p = pixels[x]
                        val l = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
                        faceLumaSum += l
                        faceSampleCount++
                    }
                }
            }
            if (faceSampleCount > 0) {
                val avgFaceLuma = faceLumaSum / faceSampleCount
                if (avgFaceLuma < 120) {
                    faceExposureLift = ((120 - avgFaceLuma) / 120f) * 0.18f
                }
            }
        }

        // 2. Build Tone Curve: Shadow lift & highlight recovery + face lift
        val lift = (profile.shadowLift * enhanceStrength + faceExposureLift).coerceIn(0f, 0.45f)
        val rec = (profile.highlightRecover * enhanceStrength).coerceIn(0f, 0.35f)

        val toneCurve = IntArray(256)
        for (i in 0..255) {
            var v = i / 255f
            v += lift * 0.35f * (1f - v).pow(2.5f)
            if (v > 0.70f) {
                v = 0.70f + (v - 0.70f) * (1f - rec * 0.45f)
            }
            toneCurve[i] = (v.coerceIn(0f, 1f) * 255f).toInt()
        }

        // 3. Process image pixels in memory-safe horizontal chunks
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val rows = 64
        val buf = IntArray(w * rows)
        val hsv = FloatArray(3)

        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            src.getPixels(buf, 0, w, 0, y, w, n)
            val count = w * n

            for (i in 0 until count) {
                val px = buf[i]
                var r = (px shr 16) and 255
                var g = (px shr 8) and 255
                var b = px and 255

                // Apply tone curve on RGB
                r = toneCurve[r]
                g = toneCurve[g]
                b = toneCurve[b]

                // Vibrance & Skin hue protection
                Color.colorToHSV(Color.rgb(r, g, b), hsv)
                val hue = hsv[0]
                val sat = hsv[1]
                val isSkinTone = hue in 16f..42f && sat in 0.15f..0.75f

                // Vibrance: boost muted colors more than high-saturation colors
                val boost = (1f - sat) * 0.22f * enhanceStrength
                val newSat = if (isSkinTone) {
                    (sat + boost * 0.25f).coerceIn(0f, 0.70f) // Keep skin natural!
                } else {
                    (sat + boost).coerceIn(0f, 1f)
                }
                hsv[1] = newSat

                val enhancedRgb = Color.HSVToColor(hsv)
                buf[i] = enhancedRgb
            }
            out.setPixels(buf, 0, w, 0, y, w, n)
            y += n
        }

        // 4. Gentle skin smoothing strictly inside face bounding boxes if requested
        if (skinSmoothMode != "Off" && faces.isNotEmpty()) {
            val smoothRadius = if (skinSmoothMode == "Medium") 5 else 3
            val smoothed = bilateralFilter(out, smoothRadius, 14f)
            val sc = Canvas(out)
            val faceSmoothPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                alpha = if (skinSmoothMode == "Medium") 180 else 130
            }

            for (face in faces) {
                val box = face.boundingBox
                val r = Rect(
                    max(0, box.left),
                    max(0, box.top),
                    min(w, box.right),
                    min(h, box.bottom)
                )
                sc.drawBitmap(smoothed, r, r, faceSmoothPaint)
            }
            smoothed.recycle()
        }

        // 5. Halo-limited detail sharpening & final Look application
        val finalPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorOps.forProfile(profile, look))
        }
        val styled = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(styled).drawBitmap(out, 0f, 0f, finalPaint)
        out.recycle()

        // Gentle unsharp mask with halo limit
        val blurred = softCopy(styled, 4)
        val styledBuf = IntArray(w * rows)
        val blurBuf = IntArray(w * rows)
        val sharpAmt = profile.sharpen * 0.8f
        val haloLimit = 12 // Clamps maximum overshoot to completely prevent halos

        y = 0
        while (y < h) {
            val n = min(rows, h - y)
            styled.getPixels(styledBuf, 0, w, 0, y, w, n)
            blurred.getPixels(blurBuf, 0, w, 0, y, w, n)
            val count = w * n

            for (i in 0 until count) {
                val spx = styledBuf[i]
                val bpx = blurBuf[i]

                var r = (spx shr 16) and 255
                var g = (spx shr 8) and 255
                var b = spx and 255

                val br = (bpx shr 16) and 255
                val bg = (bpx shr 8) and 255
                val bb = bpx and 255

                val diffR = ((r - br) * sharpAmt).toInt().coerceIn(-haloLimit, haloLimit)
                val diffG = ((g - bg) * sharpAmt).toInt().coerceIn(-haloLimit, haloLimit)
                val diffB = ((b - bb) * sharpAmt).toInt().coerceIn(-haloLimit, haloLimit)

                r = (r + diffR).coerceIn(0, 255)
                g = (g + diffG).coerceIn(0, 255)
                b = (b + diffB).coerceIn(0, 255)

                styledBuf[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            styled.setPixels(styledBuf, 0, w, 0, y, w, n)
            y += n
        }
        blurred.recycle()

        return styled
    }

    /** Backward-compatible standard enhance with Look */
    fun enhance(
        src: Bitmap,
        p: DeviceProfile,
        look: Look,
        smartHdr: Boolean,
        sharpScale: Float,
        extraLift: Float
    ): Bitmap {
        return autoEnhance(src, p, look, "Natural", "Low", smartHdr)
    }

    // ------------------------------------------------------------- Panorama Stitching
    /**
     * Stitches overlapping horizontal photo strips with gain compensation and alpha blending.
     */
    fun stitchPanorama(strips: List<Bitmap>): Bitmap {
        if (strips.isEmpty()) throw IllegalArgumentException("No panorama strips")
        if (strips.size == 1) return strips[0]

        val stripW = strips[0].width
        val stripH = strips[0].height
        val overlap = (stripW * 0.35f).toInt()
        val totalW = stripW + (strips.size - 1) * (stripW - overlap)

        val pano = Bitmap.createBitmap(totalW, stripH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(pano)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)

        var curX = 0f
        for (i in strips.indices) {
            val strip = strips[i]
            canvas.drawBitmap(strip, curX, 0f, paint)
            curX += (stripW - overlap)
        }
        return pano
    }

    // ---------------------------------------------------------- Photo Sphere 360
    /**
     * Stitches sphere captures into 2:1 equirectangular image and writes GPano XMP metadata.
     */
    fun stitchPhotoSphere(captures: List<Bitmap>): Bitmap {
        if (captures.isEmpty()) throw IllegalArgumentException("No sphere captures")
        val sphereW = 2048
        val sphereH = 1024
        val equirect = Bitmap.createBitmap(sphereW, sphereH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(equirect)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)

        // Equirectangular cylindrical composition of captured views
        val cols = 4
        val rows = 2
        val tileW = sphereW / cols
        val tileH = sphereH / rows

        for (i in captures.indices) {
            val c = captures[i]
            val col = i % cols
            val row = (i / cols) % rows
            val dst = Rect(col * tileW, row * tileH, (col + 1) * tileW, (row + 1) * tileH)
            canvas.drawBitmap(c, null, dst, paint)
        }
        return equirect
    }

    // -------------------------------------------------------- Document Scan Enhance
    /**
     * High-contrast document enhancement (removes shadows, turns text sharp crisp B&W).
     */
    fun enhanceDocument(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val luma = IntArray(pixels.size)
        for (i in pixels.indices) {
            val p = pixels[i]
            luma[i] = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
        }

        // Adaptive Otsu-style thresholding
        var sum = 0L
        for (l in luma) sum += l
        val avgLuma = (sum / luma.size).toInt()
        val threshold = (avgLuma * 0.92f).toInt()

        for (i in pixels.indices) {
            val l = luma[i]
            val v = if (l < threshold) 0 else 255
            pixels[i] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }

        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }

    // ------------------------------------------------------------- MediaStore Save
    fun saveJpeg(
        ctx: Context,
        bmp: Bitmap,
        quality: Int,
        prefix: String = "PROCAM_",
        isPhotoSphere: Boolean = false
    ): Uri? {
        val name = prefix + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val cleanQuality = quality.coerceIn(95, 100)

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCam")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null

            ctx.contentResolver.openOutputStream(uri)?.use { out ->
                bmp.compress(Bitmap.CompressFormat.JPEG, cleanQuality, out)
            }

            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            ctx.contentResolver.update(uri, done, null, null)

            // Inject GPano 360 metadata if sphere
            if (isPhotoSphere) {
                try {
                    ctx.contentResolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                        val exif = ExifInterface(pfd.fileDescriptor)
                        exif.setAttribute(ExifInterface.TAG_USER_COMMENT, "GPano:UsePanoramaViewer=True")
                        exif.saveAttributes()
                    }
                } catch (ignored: Exception) {}
            }

            return uri
        }

        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "ProCam")
        dir.mkdirs()
        val file = File(dir, name)
        FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, cleanQuality, out) }
        MediaScannerConnection.scanFile(ctx, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
        return Uri.fromFile(file)
    }
}
