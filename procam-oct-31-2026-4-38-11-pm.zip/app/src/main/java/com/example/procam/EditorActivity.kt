package com.example.procam

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * In-App Gallery Photo Editor (Phase D):
 * - Crop / rotate / straighten
 * - Adjust: brightness, contrast, highlights, shadows, saturation, warmth, tint, sharpness, vignette
 * - Looks: all 8 iPhone-style photographic styles
 * - Skin smoothing slider
 * - Undo / Redo history
 * - Hold to compare
 * - Save as copy (never overwrite)
 */
class EditorActivity : AppCompatActivity() {

    private lateinit var originalBitmap: Bitmap
    private var displayBitmap: Bitmap? = null

    private lateinit var imageView: ImageView
    private lateinit var seekBar: SeekBar
    private lateinit var sliderLabel: TextView
    private lateinit var subToolsRow: LinearLayout
    private lateinit var btnUndo: TextView
    private lateinit var btnRedo: TextView
    private lateinit var btnSaveCopy: TextView
    private lateinit var btnHoldCompare: TextView

    private lateinit var tabCrop: TextView
    private lateinit var tabAdjust: TextView
    private lateinit var tabLooks: TextView
    private lateinit var tabSkin: TextView

    private val yellow = Color.parseColor("#FFD60A")

    enum class MainTab { CROP, ADJUST, LOOKS, SKIN }
    private var currentTab = MainTab.ADJUST

    enum class AdjustParam(val label: String, val minVal: Int, val maxVal: Int, val defVal: Int) {
        BRIGHTNESS("Brightness", -100, 100, 0),
        CONTRAST("Contrast", -100, 100, 0),
        HIGHLIGHTS("Highlights", -100, 100, 0),
        SHADOWS("Shadows", -100, 100, 0),
        SATURATION("Saturation", -100, 100, 0),
        WARMTH("Warmth", -100, 100, 0),
        TINT("Tint", -100, 100, 0),
        SHARPNESS("Sharpness", 0, 100, 0),
        VIGNETTE("Vignette", 0, 100, 0)
    }

    private var activeAdjustParam = AdjustParam.BRIGHTNESS

    data class EditState(
        var rotationDegrees: Int = 0,
        var straightenAngle: Float = 0f,
        var flippedHorizontal: Boolean = false,
        var lookIndex: Int = 0,
        var skinSmoothing: Int = 0,
        val adjustments: MutableMap<AdjustParam, Int> = mutableMapOf()
    ) {
        fun copyState(): EditState {
            val copy = EditState(
                rotationDegrees,
                straightenAngle,
                flippedHorizontal,
                lookIndex,
                skinSmoothing
            )
            copy.adjustments.putAll(adjustments)
            return copy
        }
    }

    private var currentState = EditState()
    private val undoStack = ArrayList<EditState>()
    private val redoStack = ArrayList<EditState>()

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(R.layout.activity_editor)

        val uriString = intent.getStringExtra("EXTRA_IMAGE_URI")
        if (uriString == null) {
            Toast.makeText(this, "No image to edit", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val uri = Uri.parse(uriString)
        val loaded = loadBitmap(uri)
        if (loaded == null) {
            Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        originalBitmap = loaded

        bindViews()
        setupListeners()
        selectTab(MainTab.ADJUST)
        pushState()
        applyCurrentState()
    }

    private fun bindViews() {
        imageView = findViewById(R.id.editorImageView)
        seekBar = findViewById(R.id.editorSeekBar)
        sliderLabel = findViewById(R.id.sliderValueLabel)
        subToolsRow = findViewById(R.id.subToolsRow)
        btnUndo = findViewById(R.id.btnUndo)
        btnRedo = findViewById(R.id.btnRedo)
        btnSaveCopy = findViewById(R.id.btnSaveCopy)
        btnHoldCompare = findViewById(R.id.btnHoldCompare)
        tabCrop = findViewById(R.id.tabCrop)
        tabAdjust = findViewById(R.id.tabAdjust)
        tabLooks = findViewById(R.id.tabLooks)
        tabSkin = findViewById(R.id.tabSkin)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupListeners() {
        findViewById<View>(R.id.btnEditorBack).setOnClickListener { finish() }

        btnSaveCopy.setOnClickListener { saveAsCopy() }

        btnUndo.setOnClickListener {
            if (undoStack.size > 1) {
                val current = undoStack.removeAt(undoStack.size - 1)
                redoStack.add(current)
                currentState = undoStack.last().copyState()
                updateUndoRedoUi()
                refreshTabSubviews()
                applyCurrentState()
            }
        }

        btnRedo.setOnClickListener {
            if (redoStack.isNotEmpty()) {
                val state = redoStack.removeAt(redoStack.size - 1)
                undoStack.add(state.copyState())
                currentState = state.copyState()
                updateUndoRedoUi()
                refreshTabSubviews()
                applyCurrentState()
            }
        }

        // Hold to Compare original
        btnHoldCompare.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    imageView.setImageBitmap(originalBitmap)
                    btnHoldCompare.setTextColor(yellow)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    imageView.setImageBitmap(displayBitmap ?: originalBitmap)
                    btnHoldCompare.setTextColor(Color.WHITE)
                    true
                }
                else -> false
            }
        }

        tabCrop.setOnClickListener { selectTab(MainTab.CROP) }
        tabAdjust.setOnClickListener { selectTab(MainTab.ADJUST) }
        tabLooks.setOnClickListener { selectTab(MainTab.LOOKS) }
        tabSkin.setOnClickListener { selectTab(MainTab.SKIN) }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                when (currentTab) {
                    MainTab.ADJUST -> {
                        val v = progress + activeAdjustParam.minVal
                        currentState.adjustments[activeAdjustParam] = v
                        sliderLabel.text = "${activeAdjustParam.label}: ${if (v > 0) "+$v" else "$v"}"
                        applyCurrentState()
                    }
                    MainTab.CROP -> {
                        val angle = (progress - 45).toFloat()
                        currentState.straightenAngle = angle
                        sliderLabel.text = String.format(Locale.US, "Straighten: %.1f\u00B0", angle)
                        applyCurrentState()
                    }
                    MainTab.SKIN -> {
                        currentState.skinSmoothing = progress
                        sliderLabel.text = "Skin Smoothing: $progress%"
                        applyCurrentState()
                    }
                    else -> {}
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                pushState()
            }
        })
    }

    private fun pushState() {
        undoStack.add(currentState.copyState())
        redoStack.clear()
        updateUndoRedoUi()
    }

    private fun updateUndoRedoUi() {
        btnUndo.isEnabled = undoStack.size > 1
        btnUndo.setTextColor(if (btnUndo.isEnabled) Color.WHITE else 0x66FFFFFF)

        btnRedo.isEnabled = redoStack.isNotEmpty()
        btnRedo.setTextColor(if (btnRedo.isEnabled) Color.WHITE else 0x66FFFFFF)
    }

    private fun selectTab(tab: MainTab) {
        currentTab = tab
        val tabs = listOf(
            tabCrop to MainTab.CROP,
            tabAdjust to MainTab.ADJUST,
            tabLooks to MainTab.LOOKS,
            tabSkin to MainTab.SKIN
        )
        for ((v, t) in tabs) {
            val sel = t == tab
            v.setTextColor(if (sel) yellow else Color.WHITE)
        }
        refreshTabSubviews()
    }

    private fun refreshTabSubviews() {
        subToolsRow.removeAllViews()
        when (currentTab) {
            MainTab.CROP -> {
                seekBar.visibility = View.VISIBLE
                seekBar.max = 90
                seekBar.progress = (currentState.straightenAngle + 45f).toInt().coerceIn(0, 90)
                sliderLabel.text = String.format(Locale.US, "Straighten: %.1f\u00B0", currentState.straightenAngle)

                addToolChip("Rotate 90\u00B0") {
                    currentState.rotationDegrees = (currentState.rotationDegrees + 90) % 360
                    pushState()
                    applyCurrentState()
                }
                addToolChip("Flip Horiz") {
                    currentState.flippedHorizontal = !currentState.flippedHorizontal
                    pushState()
                    applyCurrentState()
                }
                addToolChip("Reset Crop") {
                    currentState.rotationDegrees = 0
                    currentState.straightenAngle = 0f
                    currentState.flippedHorizontal = false
                    seekBar.progress = 45
                    pushState()
                    applyCurrentState()
                }
            }
            MainTab.ADJUST -> {
                seekBar.visibility = View.VISIBLE
                val curVal = currentState.adjustments[activeAdjustParam] ?: activeAdjustParam.defVal
                val range = activeAdjustParam.maxVal - activeAdjustParam.minVal
                seekBar.max = range
                seekBar.progress = curVal - activeAdjustParam.minVal
                sliderLabel.text = "${activeAdjustParam.label}: ${if (curVal > 0) "+$curVal" else "$curVal"}"

                for (param in AdjustParam.values()) {
                    val sel = param == activeAdjustParam
                    addToolChip(param.label, sel) {
                        activeAdjustParam = param
                        refreshTabSubviews()
                    }
                }
            }
            MainTab.LOOKS -> {
                seekBar.visibility = View.GONE
                sliderLabel.text = "Photographic Style Look"
                for ((idx, look) in Looks.ALL.withIndex()) {
                    val sel = idx == currentState.lookIndex
                    addToolChip(look.name, sel) {
                        currentState.lookIndex = idx
                        pushState()
                        refreshTabSubviews()
                        applyCurrentState()
                    }
                }
            }
            MainTab.SKIN -> {
                seekBar.visibility = View.VISIBLE
                seekBar.max = 100
                seekBar.progress = currentState.skinSmoothing
                sliderLabel.text = "Skin Smoothing: ${currentState.skinSmoothing}%"
            }
        }
    }

    private fun addToolChip(label: String, selected: Boolean = false, onClick: () -> Unit) {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 12f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(12), 0, dp(12), 0)
        tv.setTextColor(if (selected) Color.BLACK else Color.WHITE)
        tv.setBackgroundResource(if (selected) R.drawable.bg_chip_selected else R.drawable.bg_chip)
        tv.setOnClickListener { onClick() }

        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(30))
        lp.marginStart = dp(4)
        lp.marginEnd = dp(4)
        subToolsRow.addView(tv, lp)
    }

    private fun applyCurrentState() {
        val base = originalBitmap
        var work = base

        // 1. Crop / Rotate / Straighten
        val totalRot = (currentState.rotationDegrees.toFloat() + currentState.straightenAngle)
        if (totalRot != 0f || currentState.flippedHorizontal) {
            val m = Matrix()
            if (currentState.flippedHorizontal) m.postScale(-1f, 1f, base.width / 2f, base.height / 2f)
            if (totalRot != 0f) m.postRotate(totalRot, base.width / 2f, base.height / 2f)
            work = Bitmap.createBitmap(base, 0, 0, base.width, base.height, m, true)
        }

        // 2. Adjustments & Color Look
        val look = Looks.ALL[currentState.lookIndex]
        val adj = currentState.adjustments

        val brightnessVal = (adj[AdjustParam.BRIGHTNESS] ?: 0) * 1.2f
        val contrastVal = 1f + (adj[AdjustParam.CONTRAST] ?: 0) * 0.008f
        val saturationVal = 1f + (adj[AdjustParam.SATURATION] ?: 0) * 0.01f
        val warmthVal = (adj[AdjustParam.WARMTH] ?: 0) * 0.004f

        val cm = ColorOps.combine(
            ColorOps.brightness(brightnessVal),
            ColorOps.contrast(contrastVal),
            ColorOps.saturation(saturationVal),
            ColorOps.warmth(warmthVal),
            look.extra
        )

        val out = Bitmap.createBitmap(work.width, work.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
        canvas.drawBitmap(work, 0f, 0f, paint)

        // 3. Vignette
        val vignetteVal = (adj[AdjustParam.VIGNETTE] ?: 0)
        if (vignetteVal > 0) {
            val cx = out.width / 2f
            val cy = out.height / 2f
            val radius = max(out.width, out.height) * 0.7f
            val vigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                val alpha = (vignetteVal * 2.2f).toInt().coerceIn(0, 220)
                shader = RadialGradient(
                    cx, cy, radius,
                    intArrayOf(Color.TRANSPARENT, Color.argb(alpha, 0, 0, 0)),
                    floatArrayOf(0.4f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, out.width.toFloat(), out.height.toFloat(), vigPaint)
        }

        // 4. Skin Smoothing
        if (currentState.skinSmoothing > 0) {
            val smoothed = ImageProcessor.bilateralFilter(out, 4, 15f)
            val smoothAlpha = (currentState.skinSmoothing * 2.55f).toInt().coerceIn(0, 255)
            val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = smoothAlpha }
            canvas.drawBitmap(smoothed, 0f, 0f, sp)
            smoothed.recycle()
        }

        if (work !== base) work.recycle()

        displayBitmap?.recycle()
        displayBitmap = out
        imageView.setImageBitmap(out)
    }

    private fun saveAsCopy() {
        val bmp = displayBitmap ?: return
        val quality = 97
        val uri = ImageProcessor.saveJpeg(this, bmp, quality, prefix = "PROCAM_EDIT_")
        if (uri != null) {
            Toast.makeText(this, "Saved as copy to Pictures/ProCam", Toast.LENGTH_SHORT).show()
            setResult(Activity.RESULT_OK)
            finish()
        } else {
            Toast.makeText(this, "Failed to save copy", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            val maxDim = max(opts.outWidth, opts.outHeight)
            while (maxDim / sample > 2560) sample *= 2
            val loadOpts = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, loadOpts) }
        } catch (e: Exception) {
            null
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        super.onDestroy()
        displayBitmap?.recycle()
        if (::originalBitmap.isInitialized && !originalBitmap.isRecycled) {
            originalBitmap.recycle()
        }
    }
}
