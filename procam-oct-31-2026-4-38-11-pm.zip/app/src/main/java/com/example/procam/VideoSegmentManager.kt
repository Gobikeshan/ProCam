package com.example.procam

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Manages multiple recorded video segments (e.g. when flipping camera while recording)
 * and seamlessly joins them into a single MP4 file using native MediaExtractor and MediaMuxer.
 * 100% offline, fast, and does not require third-party libraries.
 */
object VideoSegmentManager {

    fun concatenateSegments(context: Context, segmentFiles: List<File>): Uri? {
        if (segmentFiles.isEmpty()) return null
        if (segmentFiles.size == 1) {
            return saveFinalVideo(context, segmentFiles[0])
        }

        val tempMerged = File(context.cacheDir, "temp_merged_${System.currentTimeMillis()}.mp4")
        var muxer: MediaMuxer? = null

        try {
            muxer = MediaMuxer(tempMerged.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // Inspect tracks across segments
            val firstExtractor = MediaExtractor().apply { setDataSource(segmentFiles[0].absolutePath) }
            val trackCount = firstExtractor.trackCount

            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var muxerVideoTrackIndex = -1
            var muxerAudioTrackIndex = -1

            for (i in 0 until trackCount) {
                val format = firstExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") && videoTrackIndex == -1) {
                    videoTrackIndex = i
                    muxerVideoTrackIndex = muxer.addTrack(format)
                } else if (mime.startsWith("audio/") && audioTrackIndex == -1) {
                    audioTrackIndex = i
                    muxerAudioTrackIndex = muxer.addTrack(format)
                }
            }
            firstExtractor.release()

            muxer.start()

            val bufferSize = 1024 * 1024
            val buffer = ByteBuffer.allocate(bufferSize)
            val bufferInfo = MediaCodec.BufferInfo()

            var videoTimeOffsetUs = 0L
            var audioTimeOffsetUs = 0L

            for (file in segmentFiles) {
                if (!file.exists() || file.length() == 0L) continue
                val extractor = MediaExtractor()
                extractor.setDataSource(file.absolutePath)

                var maxVideoPtsInSegment = 0L
                var maxAudioPtsInSegment = 0L

                // Extract Video
                if (videoTrackIndex != -1 && muxerVideoTrackIndex != -1) {
                    var segVideoTrack = -1
                    for (i in 0 until extractor.trackCount) {
                        val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                        if (mime.startsWith("video/")) {
                            segVideoTrack = i
                            break
                        }
                    }

                    if (segVideoTrack != -1) {
                        extractor.selectTrack(segVideoTrack)
                        while (true) {
                            buffer.clear()
                            val sampleSize = extractor.readSampleData(buffer, 0)
                            if (sampleSize < 0) break

                            val sampleTime = extractor.sampleTime
                            val sampleFlags = extractor.sampleFlags
                            if (sampleTime > maxVideoPtsInSegment) maxVideoPtsInSegment = sampleTime

                            bufferInfo.offset = 0
                            bufferInfo.size = sampleSize
                            bufferInfo.presentationTimeUs = videoTimeOffsetUs + sampleTime
                            bufferInfo.flags = sampleFlags

                            muxer.writeSampleData(muxerVideoTrackIndex, buffer, bufferInfo)
                            extractor.advance()
                        }
                        extractor.unselectTrack(segVideoTrack)
                    }
                }

                // Extract Audio
                if (audioTrackIndex != -1 && muxerAudioTrackIndex != -1) {
                    var segAudioTrack = -1
                    for (i in 0 until extractor.trackCount) {
                        val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                        if (mime.startsWith("audio/")) {
                            segAudioTrack = i
                            break
                        }
                    }

                    if (segAudioTrack != -1) {
                        extractor.selectTrack(segAudioTrack)
                        while (true) {
                            buffer.clear()
                            val sampleSize = extractor.readSampleData(buffer, 0)
                            if (sampleSize < 0) break

                            val sampleTime = extractor.sampleTime
                            val sampleFlags = extractor.sampleFlags
                            if (sampleTime > maxAudioPtsInSegment) maxAudioPtsInSegment = sampleTime

                            bufferInfo.offset = 0
                            bufferInfo.size = sampleSize
                            bufferInfo.presentationTimeUs = audioTimeOffsetUs + sampleTime
                            bufferInfo.flags = sampleFlags

                            muxer.writeSampleData(muxerAudioTrackIndex, buffer, bufferInfo)
                            extractor.advance()
                        }
                        extractor.unselectTrack(segAudioTrack)
                    }
                }

                extractor.release()

                videoTimeOffsetUs += maxVideoPtsInSegment + 33_333L // ~1 frame at 30fps
                audioTimeOffsetUs += maxAudioPtsInSegment + 20_000L
            }

            muxer.stop()
            muxer.release()
            muxer = null

            // Clean up temporary segment files
            for (f in segmentFiles) {
                try { f.delete() } catch (ignored: Exception) {}
            }

            return saveFinalVideo(context, tempMerged)
        } catch (e: Exception) {
            e.printStackTrace()
            try { muxer?.release() } catch (ignored: Exception) {}
            // Fallback to first segment if stitching failed
            if (segmentFiles.isNotEmpty() && segmentFiles[0].exists()) {
                return saveFinalVideo(context, segmentFiles[0])
            }
            return null
        }
    }

    private fun saveFinalVideo(context: Context, sourceFile: File): Uri? {
        val name = "PROCAM_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ProCam")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null

        try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                sourceFile.inputStream().use { input ->
                    input.copyTo(out)
                }
            }

            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                context.contentResolver.update(uri, done, null, null)
            }
            sourceFile.delete()
            return uri
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
}
