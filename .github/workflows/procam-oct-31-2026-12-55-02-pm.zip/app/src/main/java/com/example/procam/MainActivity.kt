package com.example.procam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    // iPhone-style look: slightly warmer, more contrast, richer color
    private fun iphoneLook(): ColorMatrix {
        val saturation = ColorMatrix().apply { setSaturation(1.12f) }
        val c = 1.10f
        val t = (1f - c) / 2f * 255f
        val contrast = ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        ))
        val warm = ColorMatrix(floatArrayOf(
            1.03f, 0f, 0f, 0f, 0f,
            0f, 1.00f, 0f, 0f, 0f,
            0f, 0f, 0.97f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
        return ColorMatrix().apply {
            postConcat(saturation)
            postConcat(contrast)
            postConcat(warm)
        }
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            startCamera()
        } else {
            Toast.makeText(this, "Camera and Audio permissions are required", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)

        // Live preview filter (applied on the GPU)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(iphoneLook()) }
        previewView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, paint)

        findViewById<Button>(R.id.photoButton).setOnClickListener { takePhoto() }
        findViewById<Button>(R.id.videoButton).setOnClickListener { toggleRecording(it as Button) }

        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            startCamera()
        } else {
            permLauncher.launch(needed)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .build()
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            Quality.FHD,
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.FHD)
                        )
                    ).build()
                videoCapture = VideoCapture.withOutput(recorder)

                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA,
                    preview, imageCapture, videoCapture
                )
            } catch (e: Exception) {
                Log.e("ProCam", "Camera initialization failed", e)
                Toast.makeText(this@MainActivity, "Failed to start camera: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val temp = File(cacheDir, "temp.jpg")
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(temp).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    saveFiltered(temp)
                }
                override fun onError(e: ImageCaptureException) {
                    Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    // Apply the same look to the saved photo
    private fun saveFiltered(file: File) {
        try {
            val src = BitmapFactory.decodeFile(file.absolutePath)
            if (src == null) {
                Toast.makeText(this, "Could not process captured image", Toast.LENGTH_SHORT).show()
                return
            }
            val rotation = androidx.exifinterface.media.ExifInterface(file.absolutePath)
                .rotationDegrees.toFloat()
            val m = Matrix().apply { postRotate(rotation) }
            val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            val out = Bitmap.createBitmap(rotated.width, rotated.height, Bitmap.Config.ARGB_8888)
            Canvas(out).drawBitmap(
                rotated, 0f, 0f,
                Paint().apply { colorFilter = ColorMatrixColorFilter(iphoneLook()) }
            )

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ProCam_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCam")
            }
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)?.let { uri ->
                contentResolver.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                Toast.makeText(this, "Photo saved", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("ProCam", "Failed to save photo", e)
            Toast.makeText(this, "Error saving photo: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            file.delete()
        }
    }

    @SuppressLint("MissingPermission")
    private fun toggleRecording(button: Button) {
        val vc = videoCapture ?: return
        recording?.let {
            it.stop()
            recording = null
            button.text = "Record"
            return
        }

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "ProCam_${System.currentTimeMillis()}")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ProCam")
        }
        val options = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        val pendingRecording = vc.output.prepareRecording(this, options)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pendingRecording.withAudioEnabled()
        }

        recording = pendingRecording.start(ContextCompat.getMainExecutor(this)) { event ->
            if (event is VideoRecordEvent.Finalize) {
                if (!event.hasError()) {
                    Toast.makeText(this, "Video saved", Toast.LENGTH_SHORT).show()
                } else {
                    Log.e("ProCam", "Video recording error: ${event.error}", event.cause)
                    Toast.makeText(this, "Video error: ${event.cause?.message ?: "unknown"}", Toast.LENGTH_SHORT).show()
                }
            }
        }
        button.text = "Stop"
    }
}
