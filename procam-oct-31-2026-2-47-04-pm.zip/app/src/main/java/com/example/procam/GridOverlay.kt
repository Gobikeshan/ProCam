package com.example.procam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.View
import kotlin.math.abs

/**
 * Viewfinder overlay supporting:
 * 1. Rule-of-thirds grid lines
 * 2. Electronic level / horizon line with angle indicator and snap feedback
 */
class GridOverlay @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var showGrid: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var showLevel: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private var rollAngle: Float = 0f
    private var wasLevel: Boolean = false

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x55FFFFFF
        strokeWidth = 1.5f
    }

    private val levelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAAFFFFFF.toInt()
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }

    private val levelSnappedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD60A")
        strokeWidth = 4f
        strokeCap = Paint.Cap.ROUND
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
        textAlign = Paint.Align.CENTER
    }

    fun updateOrientation(roll: Float) {
        if (!showLevel) return
        rollAngle = roll
        val isLevel = abs(rollAngle) < 1.0f
        if (isLevel && !wasLevel) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        wasLevel = isLevel
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        // 1. Rule of thirds grid
        if (showGrid) {
            for (i in 1..2) {
                canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, gridPaint)
                canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, gridPaint)
            }
        }

        // 2. Horizon level line
        if (showLevel) {
            val cx = w / 2f
            val cy = h / 2f
            val barLen = w * 0.18f
            val isLevel = abs(rollAngle) < 1.0f
            val paint = if (isLevel) levelSnappedPaint else levelPaint

            // Reference dash marks on left & right
            val refLen = 32f
            val gap = barLen + 24f
            canvas.drawLine(cx - gap - refLen, cy, cx - gap, cy, gridPaint)
            canvas.drawLine(cx + gap, cy, cx + gap + refLen, cy, gridPaint)

            // Center rotating level line
            canvas.save()
            canvas.rotate(-rollAngle, cx, cy)
            canvas.drawLine(cx - barLen / 2f, cy, cx + barLen / 2f, cy, paint)
            canvas.drawCircle(cx, cy, 3.5f, paint)
            canvas.restore()

            // Display angle in degrees when tilted
            if (!isLevel && abs(rollAngle) >= 1.0f && abs(rollAngle) <= 45.0f) {
                val sign = if (rollAngle > 0) "+" else ""
                val angleText = String.format(java.util.Locale.US, "%s%.0f°", sign, rollAngle)
                canvas.drawText(angleText, cx, cy - 28f, textPaint)
            }
        }
    }
}
