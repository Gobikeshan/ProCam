package com.example.procam

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.media.FaceDetector
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** A colour "look" (like the iPhone photographic styles / filters). */
class Look(val name: String, val extra: ColorMatrix)

object ColorOps {
    fun saturation(s: Float): ColorMatrix = ColorMatrix().apply { setSaturation(s) }

    fun contrast(c: Float): ColorMatrix {
        val t = (1f - c) * 127.5f
        return ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    fun warmth(w: Float): ColorMatrix = ColorMatrix(
        floatArrayOf(
            1f + w, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1f - w, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    )

    fun brightness(b: Float): ColorMatrix = ColorMatrix(
        floatArrayOf(
            1f, 0f, 0f, 0f, b,
            0f, 1f, 0f, 0f, b,
            0f, 0f, 1f, 0f, b,
            0f, 0f, 0f, 1f, 0f
        )
    )

    fun combine(vararg list: ColorMatrix): ColorMatrix {
        val out = ColorMatrix()
        for (m in list) out.postConcat(m)
        return out
    }

    fun forProfile(p: DeviceProfile, look: Look): ColorMatrix =
        combine(saturation(p.saturation), contrast(p.contrast), warmth(p.warmth), look.extra)
}

object Looks {
    val ALL: List<Look> = listOf(
        Look("Natural", ColorMatrix()),
        Look("Vivid", ColorOps.combine(ColorOps.saturation(1.25f), ColorOps.contrast(1.08f))),
        Look("Vivid Warm", ColorOps.combine(ColorOps.saturation(1.22f), ColorOps.warmth(0.08f), ColorOps.contrast(1.06f))),
        Look("Vivid Cool", ColorOps.combine(ColorOps.saturation(1.20f), ColorOps.warmth(-0.08f), ColorOps.contrast(1.06f))),
        Look("Dramatic", ColorOps.combine(ColorOps.saturation(0.85f), ColorOps.contrast(1.25f))),
        Look("Mono", ColorOps.combine(ColorOps.saturation(0f), ColorOps.contrast(1.05f))),
        Look("Silvertone", ColorOps.combine(ColorOps.saturation(0f), ColorOps.contrast(1.15f), ColorOps.brightness(12f))),
        Look("Noir", ColorOps.combine(ColorOps.saturation(0f), ColorOps.contrast(1.35f), ColorOps.brightness(-10f)))
    )
}

class PortraitResult(val bitmap: Bitmap, val faceFound: Boolean)

object ImageProcessor {

    // Lazy initialize bundled offline ML Kit selfie segmenter (no internet required)
    private val selfieSegmenter by lazy {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
        Segmentation.getClient(options)
    }

    fun recycleAll(vararg list: Bitmap?) {
        for (b in list) {
            if (b != null && !b.isRecycled) b.recycle()
        }
    }

    fun toMutable(b: Bitmap): Bitmap {
        if (b.isMutable && b.config == Bitmap.Config.ARGB_8888) return b
        val copy = b.copy(Bitmap.Config.ARGB_8888, true)!!
        b.recycle()
        return copy
    }

    /** Rotate to upright and optionally mirror (front camera). */
    fun upright(src: Bitmap, degrees: Int, mirror: Boolean): Bitmap {
        if (degrees == 0 && !mirror) return src
        val m = Matrix()
        if (degrees != 0) m.postRotate(degrees.toFloat())
        if (mirror) m.postScale(-1f, 1f)
        val out = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        if (out !== src) src.recycle()
        return out
    }

    /** Keep memory safe: shrink if the photo is much bigger than the profile limit. */
    fun limit(src: Bitmap, maxMp: Int): Bitmap {
        val mp = src.width.toDouble() * src.height.toDouble() / 1_000_000.0
        if (mp <= maxMp * 1.15) return src
        val s = sqrt(maxMp * 1_000_000.0 / (src.width.toDouble() * src.height.toDouble())).toFloat()
        val out = Bitmap.createScaledBitmap(
            src, max(1, (src.width * s).toInt()), max(1, (src.height * s).toInt()), true
        )
        if (out !== src) src.recycle()
        return out
    }

    /** Soft copy made by repeated halving, then smooth up-scaling. Returns a mutable bitmap. */
    fun softCopy(src: Bitmap, factor: Int): Bitmap {
        val w = src.width
        val h = src.height
        val targetW = max(1, w / max(2, factor))
        var cur = src
        while (cur.width / 2 >= targetW && cur.width / 2 >= 2 && cur.height / 2 >= 2) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(cur, null, Rect(0, 0, w, h), p)
        if (cur !== src) cur.recycle()
        return out
    }

    // --------------------------------------------------------- 2D Frame Alignment

    data class Shift(val dx: Int, val dy: Int)

    /**
     * Compute 2D translational alignment offset between base and frame to keep
     * handheld multi-frame shots sharp and blur-free.
     */
    fun findShift(base: Bitmap, frame: Bitmap): Shift {
        val scaleW = 160
        val scaleH = (scaleW * base.height / base.width).coerceAtLeast(120)
        val bSmall = Bitmap.createScaledBitmap(base, scaleW, scaleH, false)
        val fSmall = Bitmap.createScaledBitmap(frame, scaleW, scaleH, false)

        val bPix = IntArray(scaleW * scaleH)
        val fPix = IntArray(scaleW * scaleH)
        bSmall.getPixels(bPix, 0, scaleW, 0, 0, scaleW, scaleH)
        fSmall.getPixels(fPix, 0, scaleW, 0, 0, scaleW, scaleH)
        bSmall.recycle()
        fSmall.recycle()

        // Grayscale conversion
        val bGray = IntArray(bPix.size)
        val fGray = IntArray(fPix.size)
        for (i in bPix.indices) {
            val bp = bPix[i]
            bGray[i] = (((bp shr 16) and 255) * 77 + ((bp shr 8) and 255) * 150 + (bp and 255) * 29) shr 8
            val fp = fPix[i]
            fGray[i] = (((fp shr 16) and 255) * 77 + ((fp shr 8) and 255) * 150 + (fp and 255) * 29) shr 8
        }

        // Search window of [-8, +8] in small scale (corresponds to ~60-100px in full res)
        val searchRadius = 8
        var bestDx = 0
        var bestDy = 0
        var minSad = Long.MAX_VALUE

        val margin = searchRadius + 4
        for (dy in -searchRadius..searchRadius) {
            for (dx in -searchRadius..searchRadius) {
                var sad = 0L
                for (y in margin until (scaleH - margin) step 2) {
                    val rowB = y * scaleW
                    val rowF = (y + dy) * scaleW + dx
                    for (x in margin until (scaleW - margin) step 2) {
                        sad += abs(bGray[rowB + x] - fGray[rowF + x])
                    }
                }
                if (sad < minSad) {
                    minSad = sad
                    bestDx = dx
                    bestDy = dy
                }
            }
        }

        val scaleRatio = base.width.toFloat() / scaleW.toFloat()
        return Shift((bestDx * scaleRatio).toInt(), (bestDy * scaleRatio).toInt())
    }

    /** Blend aligned frame into base accumulator */
    fun blendAlignedFrame(base: Bitmap, frame: Bitmap, alpha: Float, shift: Shift) {
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.alpha = (alpha * 255f).toInt().coerceIn(1, 255)
        val canvas = Canvas(base)
        if (shift.dx == 0 && shift.dy == 0) {
            canvas.drawBitmap(frame, 0f, 0f, paint)
        } else {
            val m = Matrix().apply { postTranslate(shift.dx.toFloat(), shift.dy.toFloat()) }
            canvas.drawBitmap(frame, m, paint)
        }
    }

    // --------------------------------------------------------------- Portrait Mode (ML Kit)

    /**
     * Portrait mode with ML Kit selfie/subject segmentation (bundled offline model).
     * Smooth depth-style background blur with adjustable blur slider.
     */
    fun portrait(src: Bitmap, blurStrength: Float): PortraitResult {
        val w = src.width
        val h = src.height
        var faceOrPersonFound = false
        var maskBitmap: Bitmap? = null

        try {
            // Process on a moderately sized bitmap for high-performance segmentation
            val targetDim = 512
            val scale = targetDim.toFloat() / max(w, h).toFloat()
            val smallW = (w * scale).toInt().coerceAtLeast(16)
            val smallH = (h * scale).toInt().coerceAtLeast(16)
            val smallBmp = Bitmap.createScaledBitmap(src, smallW, smallH, true)

            val inputImage = InputImage.fromBitmap(smallBmp, 0)
            val maskTask = selfieSegmenter.process(inputImage)
            val segmentationMask = Tasks.await(maskTask, 3000, TimeUnit.MILLISECONDS)
            smallBmp.recycle()

            val maskWidth = segmentationMask.width
            val maskHeight = segmentationMask.height
            val buffer = segmentationMask.buffer
            buffer.rewind()

            val maskPixels = IntArray(maskWidth * maskHeight)
            var subjectPixelCount = 0

            for (i in maskPixels.indices) {
                val confidence = buffer.float
                if (confidence > 0.4f) subjectPixelCount++
                // Smooth confidence curve for natural depth transition
                val alpha = (confidence.coerceIn(0f, 1f) * 255f).toInt()
                maskPixels[i] = (alpha shl 24) or 0x00FFFFFF
            }

            if (subjectPixelCount > (maskPixels.size * 0.02f)) {
                faceOrPersonFound = true
                maskBitmap = Bitmap.createBitmap(maskWidth, maskHeight, Bitmap.Config.ARGB_8888)
                maskBitmap.setPixels(maskPixels, 0, maskWidth, 0, 0, maskWidth, maskHeight)
            }
        } catch (e: Throwable) {
            // ML Kit failed or timed out, will fall back below
            faceOrPersonFound = false
        }

        // Fallback: If no person was segmented, use a soft center-weighted portrait oval
        if (maskBitmap == null) {
            val mw = max(1, w / 4)
            val mh = max(1, h / 4)
            val fallbackMask = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888)
            val mc = Canvas(fallbackMask)
            val mp = Paint(Paint.ANTI_ALIAS_FLAG)
            val cx = mw * 0.5f
            val cy = mh * 0.45f
            val rx = mw * 0.35f
            val ry = mh * 0.40f
            mp.shader = RadialGradient(
                cx, cy, rx,
                intArrayOf(Color.WHITE, Color.WHITE, 0x00FFFFFF),
                floatArrayOf(0f, 0.6f, 1f),
                Shader.TileMode.CLAMP
            )
            mc.save()
            mc.scale(1f, ry / rx, cx, cy)
            mc.drawCircle(cx, cy, rx, mp)
            mc.restore()
            maskBitmap = fallbackMask
        }

        // Generate depth blur based on adjustable blur slider
        val factor = (8f + 16f * blurStrength.coerceIn(0f, 1f)).toInt()
        val blurredBackground = softCopy(src, factor)

        // Composite sharp foreground subject over blurred background using alpha mask
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawBitmap(blurredBackground, 0f, 0f, null)
        blurredBackground.recycle()

        val layer = canvas.saveLayer(0f, 0f, w.toFloat(), h.toFloat(), null)
        canvas.drawBitmap(src, 0f, 0f, null)
        val maskPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        canvas.drawBitmap(maskBitmap, null, Rect(0, 0, w, h), maskPaint)
        canvas.restoreToCount(layer)
        maskBitmap.recycle()

        return PortraitResult(result, faceOrPersonFound)
    }

    // --------------------------------------------------------------- HDR+ Burst Fusion

    /**
     * Merge exposure-bracketed frames with handheld alignment & Mertens well-exposedness fusion.
     */
    fun mergeHdrPlus(frames: List<Bitmap>, profile: DeviceProfile): Bitmap {
        if (frames.isEmpty()) throw IllegalArgumentException("No frames for HDR+")
        if (frames.size == 1) return frames[0]

        val w = frames[0].width
        val h = frames[0].height
        val baseFrame = frames[frames.size / 2] // use mid-exposure as base

        // Align all other frames to base
        val alignedFrames = ArrayList<Bitmap>()
        for (f in frames) {
            if (f === baseFrame) {
                alignedFrames.add(f)
            } else {
                val shift = findShift(baseFrame, f)
                val shifted = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val c = Canvas(shifted)
                val m = Matrix().apply { postTranslate(shift.dx.toFloat(), shift.dy.toFloat()) }
                c.drawBitmap(f, m, Paint(Paint.FILTER_BITMAP_FLAG))
                alignedFrames.add(shifted)
            }
        }

        // Exposure fusion weights: w = exp(-(I - 0.5)^2 / (2 * 0.2^2))
        val lut = FloatArray(256)
        val sigma = 0.22f
        for (i in 0..255) {
            val norm = i / 255f
            val d = norm - 0.5f
            lut[i] = exp(-(d * d) / (2f * sigma * sigma))
        }

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val numFrames = alignedFrames.size
        val rows = 64
        val bufs = Array(numFrames) { IntArray(w * rows) }
        val outBuf = IntArray(w * rows)

        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            for (k in 0 until numFrames) {
                alignedFrames[k].getPixels(bufs[k], 0, w, 0, y, w, n)
            }
            val count = w * n
            for (i in 0 until count) {
                var weightSum = 0f
                var rSum = 0f
                var gSum = 0f
                var bSum = 0f

                for (k in 0 until numFrames) {
                    val p = bufs[k][i]
                    val r = (p shr 16) and 255
                    val g = (p shr 8) and 255
                    val b = p and 255
                    val luma = (r * 77 + g * 150 + b * 29) shr 8
                    val weight = lut[luma]
                    weightSum += weight
                    rSum += r * weight
                    gSum += g * weight
                    bSum += b * weight
                }

                val invW = if (weightSum > 0.0001f) 1f / weightSum else 1f / numFrames
                val outR = (rSum * invW).toInt().coerceIn(0, 255)
                val outG = (gSum * invW).toInt().coerceIn(0, 255)
                val outB = (bSum * invW).toInt().coerceIn(0, 255)
                outBuf[i] = (0xFF shl 24) or (outR shl 16) or (outG shl 8) or outB
            }
            out.setPixels(outBuf, 0, w, 0, y, w, n)
            y += n
        }

        for (af in alignedFrames) {
            if (af !== baseFrame && !frames.contains(af)) af.recycle()
        }
        return out
    }

    // ---------------------------------------------------------------- Enhance & Polish

    private fun buildGain(p: DeviceProfile, extraLift: Float): IntArray {
        val lift = (p.shadowLift + extraLift) * p.hdrStrength
        val gain = IntArray(256)
        for (i in 0..255) {
            var v = i / 255f
            v += lift * 0.4f * (1f - v).pow(3)
            if (v > 0.75f) v = 0.75f + (v - 0.75f) * (1f - p.highlightRecover * 0.5f)
            v = v.coerceIn(0f, 1f)
            val target = v * 255f
            val g = ((target + 1f) / (i + 1f)).coerceAtMost(3f)
            gain[i] = (g * 256f).toInt()
        }
        return gain
    }

    /**
     * Look + Smart HDR tone curve + detail sharpening + noise reduction.
     */
    fun enhance(
        src: Bitmap,
        p: DeviceProfile,
        look: Look,
        smartHdr: Boolean,
        sharpScale: Float,
        extraLift: Float
    ): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(ColorOps.forProfile(p, look))
        Canvas(out).drawBitmap(src, 0f, 0f, paint)

        val amount = p.sharpen * sharpScale
        val doSharp = amount > 0.01f
        val doNoiseReduction = p.noiseReduction > 0.1f

        if (!smartHdr && !doSharp && !doNoiseReduction) return out

        val gain = buildGain(p, extraLift)
        val blurred: Bitmap? = if (doSharp || doNoiseReduction) softCopy(out, 4) else null

        val rows = 64
        val buf = IntArray(w * rows)
        val bbuf = IntArray(w * rows)
        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            out.getPixels(buf, 0, w, 0, y, w, n)
            blurred?.getPixels(bbuf, 0, w, 0, y, w, n)
            val count = w * n
            for (i in 0 until count) {
                val px = buf[i]
                var r = (px shr 16) and 255
                var g = (px shr 8) and 255
                var b = px and 255
                val yl = (r * 77 + g * 150 + b * 29) shr 8

                var add = 0
                if (blurred != null) {
                    val bp = bbuf[i]
                    val bl = ((((bp shr 16) and 255) * 77) + (((bp shr 8) and 255) * 150) + ((bp and 255) * 29)) shr 8
                    val d = yl - bl
                    // Unsharp masking for crisp edge details
                    val dd = if (d > 3) d - 3 else if (d < -3) d + 3 else 0
                    add = (dd * amount).toInt()

                    // Subtle noise reduction in smooth areas
                    if (doNoiseReduction && abs(d) < 8) {
                        val smoothAmount = p.noiseReduction * 0.5f
                        r = (r * (1f - smoothAmount) + ((bp shr 16) and 255) * smoothAmount).toInt()
                        g = (g * (1f - smoothAmount) + ((bp shr 8) and 255) * smoothAmount).toInt()
                        b = (b * (1f - smoothAmount) + (bp and 255) * smoothAmount).toInt()
                    }
                }
                if (smartHdr) {
                    val gf = gain[yl]
                    r = (r * gf) shr 8
                    g = (g * gf) shr 8
                    b = (b * gf) shr 8
                }
                r += add
                g += add
                b += add
                if (r < 0) r = 0 else if (r > 255) r = 255
                if (g < 0) g = 0 else if (g > 255) g = 255
                if (b < 0) b = 0 else if (b > 255) b = 255
                buf[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            out.setPixels(buf, 0, w, 0, y, w, n)
            y += n
        }
        blurred?.recycle()
        return out
    }

    // ------------------------------------------------------------------- Save

    fun saveJpeg(ctx: Context, bmp: Bitmap, quality: Int): Uri? {
        val name = "PROCAM_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCam")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null
            ctx.contentResolver.openOutputStream(uri)?.use {
                bmp.compress(Bitmap.CompressFormat.JPEG, quality, it)
            }
            val done = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0)
            }
            ctx.contentResolver.update(uri, done, null, null)
            return uri
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "ProCam")
        dir.mkdirs()
        val file = File(dir, name)
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
        MediaScannerConnection.scanFile(ctx, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
        return Uri.fromFile(file)
    }
}
