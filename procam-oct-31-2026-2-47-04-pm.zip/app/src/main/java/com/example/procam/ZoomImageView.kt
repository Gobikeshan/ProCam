package com.example.procam

import android.content.Context
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.max
import kotlin.math.min

/**
 * ImageView supporting pinch-to-zoom, pan, and double-tap zoom for the in-app gallery.
 * Cooperates with ViewPager2 by allowing parent swipe when not zoomed.
 */
class ZoomImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : AppCompatImageView(context, attrs) {

    private val matrixValues = FloatArray(9)
    private val currentMatrix = Matrix()
    private val viewRect = RectF()
    private val drawableRect = RectF()

    private var minScale = 1.0f
    private var maxScale = 5.0f
    private var currentScale = 1.0f
    private var isZoomed = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val factor = detector.scaleFactor
            val targetScale = (currentScale * factor).coerceIn(minScale, maxScale)
            val actualFactor = targetScale / currentScale
            currentScale = targetScale

            currentMatrix.postScale(actualFactor, actualFactor, detector.focusX, detector.focusY)
            checkBoundsAndApply()
            updateParentDisallow()
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (currentScale > 1.2f) {
                resetZoom()
            } else {
                val target = 2.5f
                val factor = target / currentScale
                currentScale = target
                currentMatrix.postScale(factor, factor, e.x, e.y)
                checkBoundsAndApply()
            }
            updateParentDisallow()
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (currentScale > 1.05f) {
                currentMatrix.postTranslate(-distanceX, -distanceY)
                checkBoundsAndApply()
                return true
            }
            return false
        }
    })

    init {
        scaleType = ScaleType.MATRIX
    }

    override fun setImageDrawable(drawable: Drawable?) {
        super.setImageDrawable(drawable)
        resetZoom()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fitImageToView()
    }

    private fun fitImageToView() {
        val d = drawable ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (vw <= 0f || vh <= 0f || dw <= 0f || dh <= 0f) return

        viewRect.set(0f, 0f, vw, vh)
        drawableRect.set(0f, 0f, dw, dh)

        currentMatrix.reset()
        val scale = min(vw / dw, vh / dh)
        val dx = (vw - dw * scale) / 2f
        val dy = (vh - dh * scale) / 2f
        currentMatrix.postScale(scale, scale)
        currentMatrix.postTranslate(dx, dy)
        imageMatrix = currentMatrix
        currentScale = 1.0f
        isZoomed = false
    }

    fun resetZoom() {
        fitImageToView()
        updateParentDisallow()
    }

    private fun updateParentDisallow() {
        isZoomed = currentScale > 1.05f
        parent?.requestDisallowInterceptTouchEvent(isZoomed)
    }

    private fun checkBoundsAndApply() {
        val d = drawable ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (vw <= 0f || vh <= 0f || dw <= 0f || dh <= 0f) return

        val rect = RectF(0f, 0f, dw, dh)
        currentMatrix.mapRect(rect)

        var deltaX = 0f
        var deltaY = 0f

        if (rect.width() <= vw) {
            deltaX = (vw - rect.width()) / 2f - rect.left
        } else if (rect.left > 0f) {
            deltaX = -rect.left
        } else if (rect.right < vw) {
            deltaX = vw - rect.right
        }

        if (rect.height() <= vh) {
            deltaY = (vh - rect.height()) / 2f - rect.top
        } else if (rect.top > 0f) {
            deltaY = -rect.top
        } else if (rect.bottom < vh) {
            deltaY = vh - rect.bottom
        }

        currentMatrix.postTranslate(deltaX, deltaY)
        imageMatrix = currentMatrix
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
            updateParentDisallow()
        }
        return true
    }
}
