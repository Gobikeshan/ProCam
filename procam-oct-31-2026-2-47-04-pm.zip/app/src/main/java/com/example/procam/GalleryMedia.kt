package com.example.procam

import android.net.Uri

data class GalleryMedia(
    val id: Long,
    val uri: Uri,
    val isVideo: Boolean,
    val name: String,
    val dateAdded: Long,
    val mimeType: String
)
