package com.example.procam

import android.app.ActivityManager
import android.content.Context
import android.os.Build

/**
 * Tuning values for specific device hardware.
 * Adjusts sharpening, noise reduction, HDR strength, color tone, and memory safeguards.
 */
data class DeviceProfile(
    val key: String,
    val label: String,
    val sharpen: Float,             // 0 = none, 1 = strong sharpening
    val noiseReduction: Float,      // 0 = none, 1 = heavy noise smoothing
    val hdrStrength: Float,         // 0 = subtle, 1 = vivid HDR tone mapping
    val saturation: Float,          // 1 = unchanged
    val contrast: Float,            // 1 = unchanged
    val warmth: Float,              // + warmer, - cooler
    val shadowLift: Float,          // brighten dark areas (Smart HDR)
    val highlightRecover: Float,    // calm very bright areas (Smart HDR)
    val jpegQuality: Int,           // 90..100
    val nightFrames: Int,           // frames merged in Night mode
    val maxMegapixels: Int          // photo size limit, protects memory
)

object Profiles {
    val HONOR_200_SMART = DeviceProfile(
        key = "HONOR_200_SMART",
        label = "Honor 200 Smart",
        sharpen = 0.60f,
        noiseReduction = 0.45f,
        hdrStrength = 0.70f,
        saturation = 1.10f,
        contrast = 1.06f,
        warmth = 0.02f,
        shadowLift = 0.30f,
        highlightRecover = 0.20f,
        jpegQuality = 95,
        nightFrames = 5,
        maxMegapixels = 16
    )

    val BUDGET = DeviceProfile(
        key = "BUDGET",
        label = "Generic Budget",
        sharpen = 0.50f,
        noiseReduction = 0.55f,
        hdrStrength = 0.60f,
        saturation = 1.08f,
        contrast = 1.05f,
        warmth = 0.02f,
        shadowLift = 0.30f,
        highlightRecover = 0.15f,
        jpegQuality = 92,
        nightFrames = 5,
        maxMegapixels = 8
    )

    val MIDRANGE = DeviceProfile(
        key = "MIDRANGE",
        label = "Generic Mid-range",
        sharpen = 0.55f,
        noiseReduction = 0.40f,
        hdrStrength = 0.75f,
        saturation = 1.10f,
        contrast = 1.06f,
        warmth = 0.02f,
        shadowLift = 0.25f,
        highlightRecover = 0.20f,
        jpegQuality = 94,
        nightFrames = 4,
        maxMegapixels = 12
    )

    val FLAGSHIP = DeviceProfile(
        key = "FLAGSHIP",
        label = "Generic Flagship",
        sharpen = 0.45f,
        noiseReduction = 0.30f,
        hdrStrength = 0.85f,
        saturation = 1.08f,
        contrast = 1.05f,
        warmth = 0.01f,
        shadowLift = 0.15f,
        highlightRecover = 0.25f,
        jpegQuality = 96,
        nightFrames = 3,
        maxMegapixels = 16
    )

    private val dynamicProfiles = LinkedHashMap<String, DeviceProfile>()

    init {
        registerProfile(HONOR_200_SMART)
        registerProfile(BUDGET)
        registerProfile(MIDRANGE)
        registerProfile(FLAGSHIP)
    }

    /** Register or override a profile for any phone model named in the future. */
    fun registerProfile(profile: DeviceProfile) {
        dynamicProfiles[profile.key] = profile
    }

    val ALL: List<DeviceProfile>
        get() = dynamicProfiles.values.toList()

    fun resolve(context: Context, key: String): DeviceProfile {
        if (key != "AUTO") {
            val found = dynamicProfiles[key]
            if (found != null) return found
        }
        return detect(context)
    }

    fun detect(context: Context): DeviceProfile {
        val model = Build.MODEL.lowercase()
        val maker = Build.MANUFACTURER.lowercase()
        if (maker.contains("honor") && (model.contains("200 smart") || model.contains("clk-lx"))) {
            return HONOR_200_SMART
        }
        val ramGb = totalRamGb(context)
        return when {
            ramGb < 3.6 -> BUDGET
            ramGb < 7.2 -> MIDRANGE
            else -> FLAGSHIP
        }
    }

    fun totalRamGb(context: Context): Double {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.totalMem / 1_000_000_000.0
    }

    fun deviceName(): String = Build.MANUFACTURER + " " + Build.MODEL
}
