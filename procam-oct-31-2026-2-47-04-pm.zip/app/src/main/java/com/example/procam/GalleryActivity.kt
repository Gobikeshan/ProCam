package com.example.procam

import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class GalleryActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var titleText: TextView
    private lateinit var nameText: TextView
    private lateinit var dateText: TextView
    private lateinit var emptyText: TextView

    private val mediaList = ArrayList<GalleryMedia>()
    private var adapter: GalleryAdapter? = null
    private var barsVisible = true
    private var deletedAny = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(R.layout.activity_gallery)

        pager = findViewById(R.id.galleryPager)
        topBar = findViewById(R.id.topGalleryBar)
        bottomBar = findViewById(R.id.bottomGalleryBar)
        titleText = findViewById(R.id.galleryTitle)
        nameText = findViewById(R.id.galleryItemName)
        dateText = findViewById(R.id.galleryItemDate)
        emptyText = findViewById(R.id.galleryEmptyText)

        findViewById<View>(R.id.btnGalleryBack).setOnClickListener { finishWithResult() }
        findViewById<View>(R.id.btnGalleryShare).setOnClickListener { shareCurrent() }
        findViewById<View>(R.id.btnGalleryDelete).setOnClickListener { confirmDeleteCurrent() }

        loadMedia()
    }

    private fun loadMedia() {
        mediaList.clear()
        try {
            val proj = arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.MEDIA_TYPE,
                MediaStore.Files.FileColumns.DATE_ADDED,
                MediaStore.Files.FileColumns.MIME_TYPE
            )
            val sel = MediaStore.MediaColumns.DATA + " LIKE ? AND (" +
                MediaStore.Files.FileColumns.MEDIA_TYPE + "=? OR " +
                MediaStore.Files.FileColumns.MEDIA_TYPE + "=?)"
            val args = arrayOf(
                "%/ProCam/%",
                MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
                MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
            )
            contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                proj,
                sel,
                args,
                MediaStore.MediaColumns.DATE_ADDED + " DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val typeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED)
                val mimeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)

                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val name = c.getString(nameCol) ?: "Media_$id"
                    val type = c.getInt(typeCol)
                    val date = c.getLong(dateCol)
                    val mime = c.getString(mimeCol) ?: if (type == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO) "video/mp4" else "image/jpeg"
                    val isVideo = type == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                    val base = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    val uri = ContentUris.withAppendedId(base, id)
                    mediaList.add(GalleryMedia(id, uri, isVideo, name, date, mime))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (mediaList.isEmpty()) {
            emptyText.visibility = View.VISIBLE
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
        } else {
            emptyText.visibility = View.GONE
            adapter = GalleryAdapter(mediaList) { toggleBars() }
            pager.adapter = adapter
            pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    updateHeaderAndFooter(position)
                }
            })
            updateHeaderAndFooter(0)
        }
    }

    private fun updateHeaderAndFooter(position: Int) {
        if (position !in mediaList.indices) return
        val item = mediaList[position]
        titleText.text = "${position + 1} of ${mediaList.size}"
        nameText.text = item.name
        val formattedDate = SimpleDateFormat("MMM d, yyyy  h:mm a", Locale.getDefault()).format(Date(item.dateAdded * 1000L))
        dateText.text = formattedDate
    }

    private fun toggleBars() {
        barsVisible = !barsVisible
        val alpha = if (barsVisible) 1f else 0f
        topBar.animate().alpha(alpha).setDuration(200).withEndAction {
            topBar.visibility = if (barsVisible) View.VISIBLE else View.GONE
        }.start()
        bottomBar.animate().alpha(alpha).setDuration(200).withEndAction {
            bottomBar.visibility = if (barsVisible) View.VISIBLE else View.GONE
        }.start()
    }

    private fun shareCurrent() {
        val pos = pager.currentItem
        if (pos !in mediaList.indices) return
        val item = mediaList[pos]
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = item.mimeType
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "Share with"))
    }

    private fun confirmDeleteCurrent() {
        val pos = pager.currentItem
        if (pos !in mediaList.indices) return
        val item = mediaList[pos]

        AlertDialog.Builder(this)
            .setTitle("Delete")
            .setMessage("Delete this ${if (item.isVideo) "video" else "photo"}?")
            .setPositiveButton("Delete") { _, _ -> deleteMedia(pos, item) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteMedia(pos: Int, item: GalleryMedia) {
        try {
            contentResolver.delete(item.uri, null, null)
            mediaList.removeAt(pos)
            deletedAny = true
            adapter?.notifyItemRemoved(pos)
            if (mediaList.isEmpty()) {
                emptyText.visibility = View.VISIBLE
                topBar.visibility = View.GONE
                bottomBar.visibility = View.GONE
            } else {
                val nextPos = minOf(pos, mediaList.size - 1)
                updateHeaderAndFooter(nextPos)
            }
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not delete: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun finishWithResult() {
        val intent = Intent()
        if (deletedAny) {
            setResult(Activity.RESULT_OK, intent)
        } else {
            setResult(Activity.RESULT_CANCELED)
        }
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finishWithResult()
    }

    // ----------------------------------------------------------------- Adapter

    inner class GalleryAdapter(
        private val items: List<GalleryMedia>,
        private val onTap: () -> Unit
    ) : RecyclerView.Adapter<GalleryAdapter.ViewHolder>() {

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val imageView: ZoomImageView = view.findViewById(R.id.galleryImage)
            val videoContainer: View = view.findViewById(R.id.videoContainer)
            val videoView: VideoView = view.findViewById(R.id.galleryVideo)
            val btnPlay: ImageView = view.findViewById(R.id.btnVideoPlay)
            val videoControls: View = view.findViewById(R.id.videoControls)
            val currentTime: TextView = view.findViewById(R.id.videoCurrentTime)
            val totalTime: TextView = view.findViewById(R.id.videoTotalTime)
            val seekBar: SeekBar = view.findViewById(R.id.videoSeekBar)
            var videoHandler: Handler? = null
            var updateProgressRunnable: Runnable? = null
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_gallery_media, parent, false)
            return ViewHolder(v)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            if (item.isVideo) {
                holder.imageView.visibility = View.GONE
                holder.videoContainer.visibility = View.VISIBLE
                setupVideoHolder(holder, item)
            } else {
                holder.videoContainer.visibility = View.GONE
                holder.imageView.visibility = View.VISIBLE
                setupImageHolder(holder, item)
            }
        }

        private fun setupImageHolder(holder: ViewHolder, item: GalleryMedia) {
            holder.imageView.setOnClickListener { onTap() }
            Thread {
                try {
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(item.uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    val maxDim = max(opts.outWidth, opts.outHeight)
                    var sample = 1
                    while (maxDim / sample > 2048) sample *= 2
                    val loadOpts = BitmapFactory.Options().apply { inSampleSize = sample }
                    val bmp = contentResolver.openInputStream(item.uri)?.use { BitmapFactory.decodeStream(it, null, loadOpts) }
                    runOnUiThread {
                        if (bmp != null) holder.imageView.setImageBitmap(bmp)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }.start()
        }

        private fun setupVideoHolder(holder: ViewHolder, item: GalleryMedia) {
            holder.videoView.setVideoURI(item.uri)
            holder.btnPlay.visibility = View.VISIBLE
            holder.btnPlay.setImageResource(R.drawable.ic_play)
            holder.videoControls.visibility = View.GONE

            holder.videoHandler = Handler(Looper.getMainLooper())
            holder.updateProgressRunnable = object : Runnable {
                override fun run() {
                    if (holder.videoView.isPlaying) {
                        val current = holder.videoView.currentPosition
                        val total = holder.videoView.duration
                        if (total > 0) {
                            holder.seekBar.progress = (current * 1000L / total).toInt()
                            holder.currentTime.text = formatTime(current)
                            holder.totalTime.text = formatTime(total)
                        }
                        holder.videoHandler?.postDelayed(this, 300)
                    }
                }
            }

            holder.videoView.setOnPreparedListener { mp ->
                val total = mp.duration
                holder.totalTime.text = formatTime(total)
                holder.currentTime.text = "00:00"
            }

            holder.videoView.setOnCompletionListener {
                holder.btnPlay.visibility = View.VISIBLE
                holder.btnPlay.setImageResource(R.drawable.ic_play)
                holder.videoControls.visibility = View.GONE
                holder.seekBar.progress = 0
                holder.currentTime.text = "00:00"
            }

            holder.videoContainer.setOnClickListener {
                if (holder.videoView.isPlaying) {
                    holder.videoView.pause()
                    holder.btnPlay.setImageResource(R.drawable.ic_play)
                    holder.btnPlay.visibility = View.VISIBLE
                    holder.videoControls.visibility = View.VISIBLE
                } else {
                    onTap()
                }
            }

            holder.btnPlay.setOnClickListener {
                if (holder.videoView.isPlaying) {
                    holder.videoView.pause()
                    holder.btnPlay.setImageResource(R.drawable.ic_play)
                } else {
                    holder.videoView.start()
                    holder.btnPlay.setImageResource(R.drawable.ic_pause)
                    holder.btnPlay.visibility = View.GONE
                    holder.videoControls.visibility = View.VISIBLE
                    holder.updateProgressRunnable?.run()
                }
            }

            holder.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val total = holder.videoView.duration
                        if (total > 0) {
                            val seekTo = (progress * total.toLong() / 1000L).toInt()
                            holder.videoView.seekTo(seekTo)
                            holder.currentTime.text = formatTime(seekTo)
                        }
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }

        private fun formatTime(millis: Int): String {
            val totalSeconds = millis / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }

        override fun getItemCount(): Int = items.size
    }
}
