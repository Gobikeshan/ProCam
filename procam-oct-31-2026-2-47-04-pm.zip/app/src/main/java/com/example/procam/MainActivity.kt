package com.example.procam

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.media.MediaActionSound
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.atan2
import kotlin.math.roundToInt
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), SensorEventListener {

    enum class Mode { PHOTO, VIDEO, PORTRAIT, NIGHT, PRO }

    private val yellow = Color.parseColor("#FFD60A")

    private lateinit var prefs: Prefs
    private lateinit var profile: DeviceProfile

    // Views
    private lateinit var previewView: PreviewView
    private lateinit var gridOverlay: GridOverlay
    private lateinit var focusRing: View
    private lateinit var shutterFlash: View
    private lateinit var statusContainer: View
    private lateinit var statusText: TextView
    private lateinit var nightProgressBar: ProgressBar
    private lateinit var countdownText: TextView
    private lateinit var btnFlash: TextView
    private lateinit var btnTimer: TextView
    private lateinit var btnRatio: TextView
    private lateinit var btnGrid: TextView
    private lateinit var btnLooks: TextView
    private lateinit var btnFps: TextView
    private lateinit var btnSettings: TextView
    private lateinit var exposureBar: SeekBar
    private lateinit var portraitBlurContainer: View
    private lateinit var blurLabel: TextView
    private lateinit var portraitBlurSeekBar: SeekBar
    private lateinit var proControlsContainer: View
    private lateinit var proValuesScroll: HorizontalScrollView
    private lateinit var proValuesRow: LinearLayout
    private lateinit var proTabIso: TextView
    private lateinit var proTabShutter: TextView
    private lateinit var proTabWb: TextView
    private lateinit var proTabFocus: TextView
    private lateinit var proTabEv: TextView
    private lateinit var proTabRaw: TextView
    private lateinit var looksScroll: HorizontalScrollView
    private lateinit var looksRow: LinearLayout
    private lateinit var zoomBar: LinearLayout
    private lateinit var modeBar: LinearLayout
    private lateinit var thumbnail: ImageView
    private lateinit var shutterButton: FrameLayout
    private lateinit var shutterInner: View
    private lateinit var btnFlip: ImageView
    private lateinit var btnPause: ImageView
    private lateinit var btnPhotoWhileVideo: ImageView

    private val modeViews = LinkedHashMap<Mode, TextView>()
    private val zoomChips = ArrayList<Pair<Float, TextView>>()
    private val lookChips = ArrayList<TextView>()

    // CameraX
    private var cameraProvider: ProcessCameraProvider? = null
    private var extensionsManager: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    // Sensor for Level / Horizon line
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null

    // State
    private var mode = Mode.PHOTO
    private var lensFront = false
    private var ratioMode = 0 // 0 = 4:3, 1 = 16:9, 2 = 1:1
    private var flashIndex = 0 // 0 off, 1 auto, 2 on, 3 torch
    private var timerSeconds = 0
    private var lookIndex = 0
    private var expMin = 0
    private var countdownLeft = 0
    private var countdownRunning = false
    private var nightBusy = false
    private var paused = false
    private var pending = 0
    private var settingsOpened = false
    private var is60FpsSupported = false
    private var currentFps60 = false
    private var isRawSupported = false
    private var lastUri: Uri? = null
    private var lastMime = "image/jpeg"

    // Pro Mode Manual Settings
    private enum class ProTab { ISO, SHUTTER, WB, FOCUS, EV }
    private var activeProTab = ProTab.ISO
    private var manualIso = 0 // 0 = Auto
    private var manualShutterNs = 0L // 0 = Auto
    private var manualWb = 0 // 0 = Auto
    private var manualFocusDistance = -1f // -1 = Auto AF
    private var manualEv = 0f

    private val handler = Handler(Looper.getMainLooper())
    private val captureExecutor = Executors.newSingleThreadExecutor()
    private val processExecutor = Executors.newSingleThreadExecutor()
    private val sound = MediaActionSound()

    private val hideExposure = Runnable { exposureBar.visibility = View.GONE }

    private val countdownTick = object : Runnable {
        override fun run() {
            if (countdownLeft > 0) {
                countdownText.text = countdownLeft.toString()
                countdownLeft--
                handler.postDelayed(this, 1000)
            } else {
                countdownRunning = false
                countdownText.visibility = View.GONE
                capture()
            }
        }
    }

    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            loadLastMedia()
        }
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.CAMERA] == true) {
            startCamera()
        } else {
            toast("Camera permission is required")
            finish()
        }
    }

    // ------------------------------------------------------------------ Setup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        profile = Profiles.resolve(this, prefs.profileKey)
        lookIndex = prefs.lookIndex.coerceIn(0, Looks.ALL.size - 1)
        currentFps60 = prefs.videoFps60

        bindViews()
        initSensors()

        sound.load(MediaActionSound.SHUTTER_CLICK)
        sound.load(MediaActionSound.START_VIDEO_RECORDING)
        sound.load(MediaActionSound.STOP_VIDEO_RECORDING)

        setupTopBar()
        setupModeBar()
        setupLooks()
        setupPortraitControls()
        setupProControls()
        setupGestures()
        setupControls()
        layoutPreview()
        refreshAll()
        loadLastMedia()

        val needed = ArrayList<String>()
        needed.add(Manifest.permission.CAMERA)
        needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (needed.all { hasPerm(it) }) startCamera() else permLauncher.launch(needed.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        if (settingsOpened) {
            settingsOpened = false
            profile = Profiles.resolve(this, prefs.profileKey)
            currentFps60 = prefs.videoFps60
            refreshAll()
            if (cameraProvider != null && recording == null) bindCamera()
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager?.unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        captureExecutor.shutdown()
        processExecutor.shutdown()
        sound.release()
    }

    private fun initSensors() {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || !prefs.levelLine) return
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val ax = event.values[0]
            val ay = event.values[1]
            val rollDegrees = Math.toDegrees(atan2(ax.toDouble(), ay.toDouble())).toFloat()
            // Normalize roll relative to nearest 90-degree orientation
            var normRoll = rollDegrees
            while (normRoll > 45f) normRoll -= 90f
            while (normRoll < -45f) normRoll += 90f
            gridOverlay.updateOrientation(normRoll)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun bindViews() {
        previewView = findViewById(R.id.previewView)
        gridOverlay = findViewById(R.id.gridOverlay)
        focusRing = findViewById(R.id.focusRing)
        shutterFlash = findViewById(R.id.shutterFlash)
        statusContainer = findViewById(R.id.statusContainer)
        statusText = findViewById(R.id.statusText)
        nightProgressBar = findViewById(R.id.nightProgressBar)
        countdownText = findViewById(R.id.countdownText)
        btnFlash = findViewById(R.id.btnFlash)
        btnTimer = findViewById(R.id.btnTimer)
        btnRatio = findViewById(R.id.btnRatio)
        btnGrid = findViewById(R.id.btnGrid)
        btnLooks = findViewById(R.id.btnLooks)
        btnFps = findViewById(R.id.btnFps)
        btnSettings = findViewById(R.id.btnSettings)
        exposureBar = findViewById(R.id.exposureBar)
        portraitBlurContainer = findViewById(R.id.portraitBlurContainer)
        blurLabel = findViewById(R.id.blurLabel)
        portraitBlurSeekBar = findViewById(R.id.portraitBlurSeekBar)
        proControlsContainer = findViewById(R.id.proControlsContainer)
        proValuesScroll = findViewById(R.id.proValuesScroll)
        proValuesRow = findViewById(R.id.proValuesRow)
        proTabIso = findViewById(R.id.proTabIso)
        proTabShutter = findViewById(R.id.proTabShutter)
        proTabWb = findViewById(R.id.proTabWb)
        proTabFocus = findViewById(R.id.proTabFocus)
        proTabEv = findViewById(R.id.proTabEv)
        proTabRaw = findViewById(R.id.proTabRaw)
        looksScroll = findViewById(R.id.looksScroll)
        looksRow = findViewById(R.id.looksRow)
        zoomBar = findViewById(R.id.zoomBar)
        modeBar = findViewById(R.id.modeBar)
        thumbnail = findViewById(R.id.thumbnail)
        shutterButton = findViewById(R.id.shutterButton)
        shutterInner = findViewById(R.id.shutterInner)
        btnFlip = findViewById(R.id.btnFlip)
        btnPause = findViewById(R.id.btnPause)
        btnPhotoWhileVideo = findViewById(R.id.btnPhotoWhileVideo)

        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        thumbnail.clipToOutline = true
        thumbnail.outlineProvider = ViewOutlineProvider.BACKGROUND

        modeViews[Mode.PHOTO] = findViewById(R.id.modePhoto)
        modeViews[Mode.VIDEO] = findViewById(R.id.modeVideo)
        modeViews[Mode.PORTRAIT] = findViewById(R.id.modePortrait)
        modeViews[Mode.NIGHT] = findViewById(R.id.modeNight)
        modeViews[Mode.PRO] = findViewById(R.id.modePro)
    }

    private fun setupTopBar() {
        btnFlash.setOnClickListener {
            flashIndex = if (mode == Mode.VIDEO) {
                if (flashIndex == 0) 3 else 0
            } else {
                (flashIndex + 1) % 4
            }
            applyFlash()
            refreshTopBar()
        }
        btnTimer.setOnClickListener {
            timerSeconds = when (timerSeconds) { 0 -> 3; 3 -> 10; else -> 0 }
            refreshTopBar()
        }
        btnRatio.setOnClickListener {
            if (recording != null) return@setOnClickListener
            ratioMode = (ratioMode + 1) % 3
            layoutPreview()
            refreshTopBar()
            bindCamera()
        }
        btnGrid.setOnClickListener {
            if (!prefs.grid && !prefs.levelLine) {
                prefs.grid = true
                prefs.levelLine = false
            } else if (prefs.grid && !prefs.levelLine) {
                prefs.grid = true
                prefs.levelLine = true
            } else {
                prefs.grid = false
                prefs.levelLine = false
            }
            refreshTopBar()
        }
        btnLooks.setOnClickListener {
            looksScroll.visibility = if (looksScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        btnFps.setOnClickListener {
            if (recording != null) return@setOnClickListener
            currentFps60 = !currentFps60
            prefs.videoFps60 = currentFps60
            refreshTopBar()
            bindCamera()
        }
        btnSettings.setOnClickListener {
            if (recording != null) return@setOnClickListener
            settingsOpened = true
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun setupModeBar() {
        for ((m, tv) in modeViews) {
            tv.setOnClickListener { setMode(m) }
        }
    }

    private fun setupLooks() {
        looksRow.removeAllViews()
        lookChips.clear()
        for ((i, look) in Looks.ALL.withIndex()) {
            val tv = TextView(this)
            tv.text = look.name
            tv.textSize = 13f
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(14), 0, dp(14), 0)
            tv.setOnClickListener {
                lookIndex = i
                prefs.lookIndex = i
                refreshLooks()
                applyPreviewLook()
                refreshTopBar()
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(34))
            lp.marginStart = dp(5)
            lp.marginEnd = dp(5)
            looksRow.addView(tv, lp)
            lookChips.add(tv)
        }
    }

    private fun setupPortraitControls() {
        portraitBlurSeekBar.progress = (prefs.portraitBlur * 100f).toInt().coerceIn(10, 100)
        updateBlurLabel(prefs.portraitBlur)
        portraitBlurSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val strength = progress / 100f
                    prefs.portraitBlur = strength
                    updateBlurLabel(strength)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun updateBlurLabel(strength: Float) {
        val fVal = when {
            strength < 0.35f -> "f/4.0"
            strength < 0.70f -> "f/2.8"
            else -> "f/1.4"
        }
        blurLabel.text = fVal
    }

    private fun setupProControls() {
        val tabs = listOf(
            proTabIso to ProTab.ISO,
            proTabShutter to ProTab.SHUTTER,
            proTabWb to ProTab.WB,
            proTabFocus to ProTab.FOCUS,
            proTabEv to ProTab.EV
        )
        for ((view, tab) in tabs) {
            view.setOnClickListener {
                activeProTab = tab
                refreshProTabHighlight()
                populateProValues()
            }
        }
        proTabRaw.setOnClickListener {
            if (isRawSupported) {
                prefs.rawCapture = !prefs.rawCapture
                proTabRaw.text = if (prefs.rawCapture) "RAW+JPEG" else "JPEG"
                proTabRaw.setTextColor(if (prefs.rawCapture) yellow else Color.WHITE)
            } else {
                toast("RAW (DNG) is not supported by this camera sensor")
            }
        }
    }

    private fun refreshProTabHighlight() {
        val list = listOf(
            proTabIso to ProTab.ISO,
            proTabShutter to ProTab.SHUTTER,
            proTabWb to ProTab.WB,
            proTabFocus to ProTab.FOCUS,
            proTabEv to ProTab.EV
        )
        for ((v, t) in list) {
            val sel = t == activeProTab
            v.setTextColor(if (sel) yellow else Color.WHITE)
            v.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    private fun populateProValues() {
        proValuesRow.removeAllViews()
        when (activeProTab) {
            ProTab.ISO -> {
                val values = listOf(0, 100, 200, 400, 800, 1600, 3200, 6400)
                for (v in values) {
                    val label = if (v == 0) "Auto" else "$v"
                    addProChip(label, manualIso == v) {
                        manualIso = v
                        applyProSettings()
                        populateProValues()
                    }
                }
            }
            ProTab.SHUTTER -> {
                val labels = listOf("Auto", "1/4000", "1/2000", "1/1000", "1/500", "1/250", "1/125", "1/60", "1/30", "1/15", "1/8", "1/4", "1/2", "1s")
                val nsecs = listOf(
                    0L, 250_000L, 500_000L, 1_000_000L, 2_000_000L, 4_000_000L, 8_000_000L,
                    16_666_666L, 33_333_333L, 66_666_666L, 125_000_000L, 250_000_000L, 500_000_000L, 1_000_000_000L
                )
                for (i in labels.indices) {
                    val ns = nsecs[i]
                    addProChip(labels[i], manualShutterNs == ns) {
                        manualShutterNs = ns
                        applyProSettings()
                        populateProValues()
                    }
                }
            }
            ProTab.WB -> {
                val labels = listOf("Auto", "3000K", "4000K", "5500K", "6500K", "7500K")
                val modes = listOf(0, CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT, CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT, CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT, CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT, CaptureRequest.CONTROL_AWB_MODE_SHADE)
                for (i in labels.indices) {
                    val m = modes[i]
                    addProChip(labels[i], manualWb == m) {
                        manualWb = m
                        applyProSettings()
                        populateProValues()
                    }
                }
            }
            ProTab.FOCUS -> {
                val labels = listOf("Auto AF", "Macro", "Close", "Mid", "Far", "Infinity")
                val diopters = listOf(-1f, 10f, 5f, 1f, 0.2f, 0.0f)
                for (i in labels.indices) {
                    val d = diopters[i]
                    addProChip(labels[i], manualFocusDistance == d) {
                        manualFocusDistance = d
                        applyProSettings()
                        populateProValues()
                    }
                }
            }
            ProTab.EV -> {
                val evs = listOf(-3.0f, -2.0f, -1.0f, 0.0f, 1.0f, 2.0f, 3.0f)
                for (ev in evs) {
                    val label = if (ev > 0) "+$ev" else "$ev"
                    addProChip(label, manualEv == ev) {
                        manualEv = ev
                        val es = camera?.cameraInfo?.exposureState
                        if (es != null && es.isExposureCompensationSupported) {
                            val step = es.exposureCompensationStep.toFloat()
                            val idx = (ev / step).roundToInt().coerceIn(es.exposureCompensationRange.lower, es.exposureCompensationRange.upper)
                            camera?.cameraControl?.setExposureCompensationIndex(idx)
                        }
                        populateProValues()
                    }
                }
            }
        }
    }

    private fun addProChip(label: String, selected: Boolean, onClick: () -> Unit) {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 12f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(10), 0, dp(10), 0)
        tv.setTextColor(if (selected) Color.BLACK else Color.WHITE)
        tv.setBackgroundResource(if (selected) R.drawable.bg_chip_selected else R.drawable.bg_chip)
        tv.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(28))
        lp.marginStart = dp(4)
        lp.marginEnd = dp(4)
        proValuesRow.addView(tv, lp)
    }

    private fun applyProSettings() {
        val cam = camera ?: return
        val c2Control = Camera2CameraControl.from(cam.cameraControl)
        val builder = CaptureRequestOptions.Builder()

        // ISO & Shutter Speed
        if (manualIso > 0 || manualShutterNs > 0L) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            if (manualIso > 0) builder.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, manualIso)
            if (manualShutterNs > 0L) builder.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, manualShutterNs)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        }

        // White Balance
        if (manualWb > 0) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, manualWb)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        }

        // Focus Distance
        if (manualFocusDistance >= 0f) {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            builder.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, manualFocusDistance)
        } else {
            builder.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        }

        c2Control.setCaptureRequestOptions(builder.build())
    }

    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return false
                val zs = cam.cameraInfo.zoomState.value ?: return false
                val target = (zs.zoomRatio * detector.scaleFactor).coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
                cam.cameraControl.setZoomRatio(target)
                highlightZoom(target)
                return true
            }
        })
        val gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusAt(e.x, e.y, false)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                focusAt(e.x, e.y, true)
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                val start = e1 ?: return false
                val dx = e2.x - start.x
                val dy = e2.y - start.y
                if (kotlin.math.abs(dx) > dp(80) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.4f) {
                    val all = Mode.values()
                    val next = if (dx < 0) mode.ordinal + 1 else mode.ordinal - 1
                    if (next in all.indices) setMode(all[next])
                    return true
                }
                return false
            }
        })
        previewView.setOnTouchListener { v, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) gestureDetector.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP) v.performClick()
            true
        }
    }

    private fun setupControls() {
        shutterButton.setOnClickListener {
            shutterInner.animate().scaleX(0.88f).scaleY(0.88f).setDuration(70).withEndAction {
                shutterInner.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
            }.start()
            onShutter()
        }
        btnFlip.setOnClickListener {
            if (recording != null || nightBusy) return@setOnClickListener
            lensFront = !lensFront
            btnFlip.animate().rotationBy(180f).setDuration(250).start()
            bindCamera()
        }
        btnPause.setOnClickListener {
            val rec = recording ?: return@setOnClickListener
            if (paused) {
                rec.resume()
                paused = false
                btnPause.setImageResource(R.drawable.ic_pause)
            } else {
                rec.pause()
                paused = true
                btnPause.setImageResource(R.drawable.ic_play)
            }
        }
        btnPhotoWhileVideo.setOnClickListener {
            takePhotoWhileRecording()
        }
        thumbnail.setOnClickListener { openGallery() }
        exposureBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    camera?.cameraControl?.setExposureCompensationIndex(progress + expMin)
                    handler.removeCallbacks(hideExposure)
                    handler.postDelayed(hideExposure, 3500)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    // ----------------------------------------------------------------- Layout

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private val Int.sp: Float get() = this.toFloat()

    private fun hasPerm(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun layoutPreview() {
        val w = resources.displayMetrics.widthPixels
        val h = when (ratioMode) {
            1 -> w * 16 / 9
            2 -> w
            else -> w * 4 / 3
        }
        val topMargin = dp(64)
        val lp = FrameLayout.LayoutParams(w, h).apply { this.topMargin = topMargin }
        previewView.layoutParams = lp
        val lp2 = FrameLayout.LayoutParams(w, h).apply { this.topMargin = topMargin }
        gridOverlay.layoutParams = lp2
    }

    private fun setTopButton(tv: TextView, icon: Int, label: String, active: Boolean) {
        tv.setCompoundDrawablesWithIntrinsicBounds(0, icon, 0, 0)
        tv.text = label
        val color = if (active) yellow else Color.WHITE
        tv.setTextColor(color)
        tv.compoundDrawables[1]?.mutate()?.setTint(color)
    }

    private fun refreshTopBar() {
        val flashLabels = arrayOf("Off", "Auto", "On", "Torch")
        setTopButton(btnFlash, R.drawable.ic_flash, flashLabels[flashIndex], flashIndex != 0)
        setTopButton(btnTimer, R.drawable.ic_timer, if (timerSeconds == 0) "Off" else "${timerSeconds}s", timerSeconds != 0)
        val ratioText = when (ratioMode) { 1 -> "16:9"; 2 -> "1:1"; else -> "4:3" }
        setTopButton(btnRatio, R.drawable.ic_ratio, ratioText, false)

        val gridLabel = when {
            prefs.grid && prefs.levelLine -> "Grid+Lvl"
            prefs.grid -> "Grid"
            prefs.levelLine -> "Level"
            else -> "Grid Off"
        }
        setTopButton(btnGrid, R.drawable.ic_grid, gridLabel, prefs.grid || prefs.levelLine)
        gridOverlay.showGrid = prefs.grid
        gridOverlay.showLevel = prefs.levelLine

        setTopButton(btnLooks, R.drawable.ic_looks, Looks.ALL[lookIndex].name, lookIndex != 0)
        setTopButton(btnSettings, R.drawable.ic_settings, "Setup", false)

        if (mode == Mode.VIDEO && is60FpsSupported) {
            btnFps.visibility = View.VISIBLE
            btnFps.text = if (currentFps60) "60 FPS" else "30 FPS"
            btnFps.setTextColor(if (currentFps60) yellow else Color.WHITE)
        } else {
            btnFps.visibility = View.GONE
        }
    }

    private fun refreshLooks() {
        for ((i, tv) in lookChips.withIndex()) {
            val sel = i == lookIndex
            tv.setTextColor(if (sel) Color.BLACK else Color.WHITE)
            tv.setBackgroundResource(if (sel) R.drawable.bg_chip_selected else R.drawable.bg_chip)
        }
    }

    private fun refreshModeBar() {
        for ((m, tv) in modeViews) {
            val sel = m == mode
            tv.setTextColor(if (sel) yellow else Color.WHITE)
            tv.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            tv.alpha = if (sel) 1f else 0.70f
        }
        val res = when {
            mode == Mode.VIDEO && recording != null -> R.drawable.shutter_recording
            mode == Mode.VIDEO -> R.drawable.shutter_video
            else -> R.drawable.shutter_photo
        }
        shutterInner.setBackgroundResource(res)

        // Show/hide sub-panels
        portraitBlurContainer.visibility = if (mode == Mode.PORTRAIT) View.VISIBLE else View.GONE
        proControlsContainer.visibility = if (mode == Mode.PRO) View.VISIBLE else View.GONE
        if (mode == Mode.PRO) {
            refreshProTabHighlight()
            populateProValues()
            proTabRaw.text = if (prefs.rawCapture) "RAW+JPEG" else "JPEG"
            proTabRaw.setTextColor(if (prefs.rawCapture) yellow else Color.WHITE)
        }
    }

    private fun refreshAll() {
        refreshTopBar()
        refreshLooks()
        refreshModeBar()
        applyPreviewLook()
    }

    /** Live look on the preview */
    private fun applyPreviewLook() {
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(ColorOps.forProfile(profile, Looks.ALL[lookIndex]))
        previewView.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
    }

    private fun setStatus(text: String?, showProgress: Boolean = false, progress: Int = 0) {
        if (text == null) {
            statusContainer.visibility = View.GONE
        } else {
            statusText.text = text
            if (showProgress) {
                nightProgressBar.visibility = View.VISIBLE
                nightProgressBar.progress = progress
            } else {
                nightProgressBar.visibility = View.GONE
            }
            statusContainer.visibility = View.VISIBLE
        }
    }

    // ------------------------------------------------------------------ Modes

    private fun setMode(m: Mode) {
        if (m == mode || recording != null || nightBusy) return
        val wasVideo = mode == Mode.VIDEO
        mode = m
        if (mode == Mode.VIDEO && (flashIndex == 1 || flashIndex == 2)) flashIndex = 0
        refreshModeBar()
        refreshTopBar()
        when (m) {
            Mode.PORTRAIT -> hint("Portrait: depth-aware background blur")
            Mode.NIGHT -> hint("Night: hold still, aligning & merging frames")
            Mode.PRO -> hint("Pro: manual ISO, shutter, white balance & focus")
            else -> setStatus(null)
        }
        if (wasVideo != (m == Mode.VIDEO)) bindCamera() else applyFlash()
    }

    private fun hint(text: String) {
        setStatus(text)
        handler.postDelayed({ if (!nightBusy && recording == null && pending == 0) setStatus(null) }, 2500)
    }

    // ----------------------------------------------------------------- Camera

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            val extFuture = ExtensionsManager.getInstanceAsync(this, cameraProvider!!)
            extFuture.addListener({
                extensionsManager = extFuture.get()
                bindCamera()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    private fun resolutionSelector(forCapture: Boolean): ResolutionSelector {
        val b = ResolutionSelector.Builder()
        val aspect = when (ratioMode) {
            1 -> AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            else -> AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
        }
        b.setAspectRatioStrategy(aspect)
        if (forCapture) {
            val bw = sqrt(profile.maxMegapixels * 1_000_000.0 * 4.0 / 3.0).toInt()
            val bh = bw * 3 / 4
            b.setResolutionStrategy(
                ResolutionStrategy(Size(bw, bh), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
            )
        }
        return b.build()
    }

    private fun qualitySelector(): QualitySelector {
        val q = when (prefs.videoQuality) {
            "HD" -> Quality.HD
            "UHD" -> Quality.UHD
            else -> Quality.FHD
        }
        return QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))
    }

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        var selector = if (lensFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA

        // CameraX Extensions integration
        val ext = extensionsManager
        if (ext != null) {
            val extMode = when (mode) {
                Mode.NIGHT -> ExtensionMode.NIGHT
                Mode.PORTRAIT -> ExtensionMode.BOKEH
                Mode.PHOTO -> if (prefs.smartHdr) ExtensionMode.HDR else ExtensionMode.NONE
                else -> ExtensionMode.NONE
            }
            if (extMode != ExtensionMode.NONE && ext.isExtensionAvailable(selector, extMode)) {
                selector = ext.getExtensionEnabledCameraSelector(selector, extMode)
            }
        }

        val previewBuilder = Preview.Builder().setResolutionSelector(resolutionSelector(false))

        // Video stabilization and 60 FPS Camera2Interop options
        if (mode == Mode.VIDEO) {
            val c2Extender = Camera2Interop.Extender(previewBuilder)
            if (prefs.videoStabilization) {
                c2Extender.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
                c2Extender.setCaptureRequestOption(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
            }
            if (currentFps60 && is60FpsSupported) {
                c2Extender.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(60, 60))
            }
        }

        val preview = previewBuilder.build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        try {
            if (mode == Mode.VIDEO) {
                // Bind both video and image capture so photo-while-recording works!
                val recorder = Recorder.Builder().setQualitySelector(qualitySelector()).build()
                val vc = VideoCapture.withOutput(recorder)
                videoCapture = vc
                val ic = ImageCapture.Builder().setResolutionSelector(resolutionSelector(true)).build()
                imageCapture = ic
                camera = provider.bindToLifecycle(this, selector, preview, vc, ic)
            } else {
                videoCapture = null
                val ic = ImageCapture.Builder()
                    .setResolutionSelector(resolutionSelector(true))
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .build()
                imageCapture = ic
                camera = provider.bindToLifecycle(this, selector, preview, ic)
            }
            onCameraBound()
        } catch (e: Exception) {
            toast("Camera error: " + (e.message ?: "unknown"))
        }
    }

    private fun onCameraBound() {
        val cam = camera ?: return
        btnFlash.visibility = if (cam.cameraInfo.hasFlashUnit()) View.VISIBLE else View.INVISIBLE
        applyFlash()

        val zs = cam.cameraInfo.zoomState.value
        buildZoomChips(zs?.minZoomRatio ?: 1f, zs?.maxZoomRatio ?: 1f)

        val es = cam.cameraInfo.exposureState
        if (es.isExposureCompensationSupported) {
            val r = es.exposureCompensationRange
            expMin = r.lower
            exposureBar.max = r.upper - r.lower
            exposureBar.progress = es.exposureCompensationIndex - r.lower
        }

        // Query Camera2 hardware capabilities
        try {
            val c2Info = Camera2CameraInfo.from(cam.cameraInfo)
            val caps = c2Info.getCameraCharacteristic(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            isRawSupported = caps?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW) == true

            val fpsRanges = c2Info.getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            is60FpsSupported = fpsRanges?.any { it.upper >= 60 } == true
        } catch (e: Exception) {
            isRawSupported = false
            is60FpsSupported = false
        }

        refreshTopBar()
        applyPreviewLook()
        if (mode == Mode.PRO) applyProSettings()
    }

    private fun applyFlash() {
        val cam = camera ?: return
        val ic = imageCapture
        if (ic != null) {
            ic.flashMode = when (flashIndex) {
                1 -> ImageCapture.FLASH_MODE_AUTO
                2 -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
        }
        if (cam.cameraInfo.hasFlashUnit()) cam.cameraControl.enableTorch(flashIndex == 3)
    }

    private fun buildZoomChips(minZ: Float, maxZ: Float) {
        zoomBar.removeAllViews()
        zoomChips.clear()
        val wanted = ArrayList<Float>()
        if (minZ < 0.95f) wanted.add(minZ)
        wanted.add(1f)
        if (maxZ >= 2f) wanted.add(2f)
        if (maxZ >= 5f) wanted.add(5f)
        for (z in wanted) {
            if (z < minZ - 0.01f || z > maxZ + 0.01f) continue
            val tv = TextView(this)
            tv.text = if (z < 1f) String.format(Locale.US, "%.1f", z) else "${z.toInt()}x"
            tv.textSize = 13f
            tv.gravity = Gravity.CENTER
            tv.setOnClickListener {
                camera?.cameraControl?.setZoomRatio(z)
                highlightZoom(z)
            }
            val lp = LinearLayout.LayoutParams(dp(46), dp(34))
            lp.marginStart = dp(5)
            lp.marginEnd = dp(5)
            zoomBar.addView(tv, lp)
            zoomChips.add(Pair(z, tv))
        }
        highlightZoom(1f)
    }

    private fun highlightZoom(ratio: Float) {
        var best = -1
        var bestDiff = Float.MAX_VALUE
        for ((i, p) in zoomChips.withIndex()) {
            val d = kotlin.math.abs(p.first - ratio)
            if (d < bestDiff) {
                bestDiff = d
                best = i
            }
        }
        for ((i, p) in zoomChips.withIndex()) {
            val sel = i == best
            p.second.setTextColor(if (sel) Color.BLACK else Color.WHITE)
            p.second.setBackgroundResource(if (sel) R.drawable.bg_chip_selected else R.drawable.bg_chip)
        }
    }

    private fun focusAt(x: Float, y: Float, lock: Boolean) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val builder = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
        if (lock) builder.disableAutoCancel() else builder.setAutoCancelDuration(4, TimeUnit.SECONDS)
        cam.cameraControl.startFocusAndMetering(builder.build())
        showFocusRing(x, y)
        exposureBar.visibility = View.VISIBLE
        handler.removeCallbacks(hideExposure)
        handler.postDelayed(hideExposure, 3500)
        if (lock) hint("AE/AF LOCK")
    }

    private fun showFocusRing(x: Float, y: Float) {
        val size = dp(80)
        focusRing.x = x - size / 2f
        focusRing.y = previewView.top + y - size / 2f
        focusRing.animate().cancel()
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.scaleX = 1.4f
        focusRing.scaleY = 1.4f
        focusRing.animate().scaleX(1f).scaleY(1f).setDuration(180).withEndAction {
            focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300).withEndAction {
                focusRing.visibility = View.GONE
                focusRing.alpha = 1f
            }.start()
        }.start()
    }

    // ---------------------------------------------------------------- Shutter

    private fun playSound(which: Int) {
        if (prefs.shutterSound) sound.play(which)
    }

    private fun onShutter() {
        shutterButton.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        if (mode == Mode.VIDEO) {
            toggleRecording()
            return
        }
        if (nightBusy) return
        if (countdownRunning) {
            handler.removeCallbacks(countdownTick)
            countdownRunning = false
            countdownText.visibility = View.GONE
            return
        }
        if (timerSeconds > 0) {
            countdownRunning = true
            countdownLeft = timerSeconds
            countdownText.visibility = View.VISIBLE
            countdownTick.run()
        } else {
            capture()
        }
    }

    private fun flashScreen() {
        shutterFlash.visibility = View.VISIBLE
        shutterFlash.alpha = 0.5f
        shutterFlash.animate().alpha(0f).setDuration(160).withEndAction {
            shutterFlash.visibility = View.GONE
        }.start()
    }

    private fun capture() {
        val ic = imageCapture ?: return
        flashScreen()
        when {
            mode == Mode.NIGHT -> captureNight(ic)
            mode == Mode.PHOTO && prefs.hdrPlus -> captureHdrPlus(ic)
            else -> captureSingle(ic)
        }
    }

    private fun toUpright(image: ImageProxy): Bitmap {
        val bmp = image.toBitmap()
        val rot = image.imageInfo.rotationDegrees
        image.close()
        return ImageProcessor.upright(bmp, rot, lensFront && prefs.mirrorSelfie)
    }

    private fun captureSingle(ic: ImageCapture) {
        val m = mode
        playSound(MediaActionSound.SHUTTER_CLICK)
        ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp: Bitmap? = try {
                    toUpright(image)
                } catch (t: Throwable) {
                    try { image.close() } catch (ignored: Throwable) {}
                    null
                }
                if (bmp == null) {
                    runOnUiThread { toast("Could not read photo") }
                    return
                }
                enqueueProcessing(bmp, m)
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { toast("Photo failed: " + exception.message) }
            }
        })
    }

    /**
     * Handheld Aligned Night Mode with Progress Bar
     */
    private fun captureNight(ic: ImageCapture) {
        val total = profile.nightFrames
        val cam = camera
        val es = cam?.cameraInfo?.exposureState
        val savedEv = es?.exposureCompensationIndex ?: 0
        nightBusy = true

        if (cam != null && es != null && es.isExposureCompensationSupported) {
            val up = es.exposureCompensationRange.upper
            cam.cameraControl.setExposureCompensationIndex((up * 0.7f).roundToInt())
        }
        playSound(MediaActionSound.SHUTTER_CLICK)

        var acc: Bitmap? = null
        val mp = profile.maxMegapixels

        fun finishNight(ok: Boolean) {
            cam?.cameraControl?.setExposureCompensationIndex(savedEv)
            nightBusy = false
            setStatus(null)
            val result = acc
            if (ok && result != null) {
                enqueueProcessing(result, Mode.NIGHT)
            } else {
                ImageProcessor.recycleAll(result)
                toast("Night shot failed")
            }
        }

        fun step(i: Int) {
            val pct = ((i + 1) * 100 / total)
            setStatus("Hold still  ${i + 1}/$total", showProgress = true, progress = pct)
            ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    var ok = true
                    try {
                        val frame = ImageProcessor.limit(toUpright(image), mp)
                        val base = acc
                        if (base == null) {
                            acc = ImageProcessor.toMutable(frame)
                        } else {
                            // Compute 2D translational alignment shift to eliminate handheld camera shake
                            val shift = ImageProcessor.findShift(base, frame)
                            ImageProcessor.blendAlignedFrame(base, frame, 1f / (i + 1), shift)
                            ImageProcessor.recycleAll(frame)
                        }
                    } catch (t: Throwable) {
                        ok = false
                        try { image.close() } catch (ignored: Throwable) {}
                    }
                    runOnUiThread {
                        if (!ok) finishNight(false)
                        else if (i + 1 < total) step(i + 1)
                        else finishNight(true)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    runOnUiThread { finishNight(false) }
                }
            })
        }
        step(0)
    }

    /**
     * Pixel-Style HDR+ Burst with Exposure Bracketing & Fusion
     */
    private fun captureHdrPlus(ic: ImageCapture) {
        val cam = camera
        val es = cam?.cameraInfo?.exposureState
        if (cam == null || es == null || !es.isExposureCompensationSupported) {
            captureSingle(ic)
            return
        }

        val savedEv = es.exposureCompensationIndex
        val r = es.exposureCompensationRange
        val stepEv = es.exposureCompensationStep.toFloat()
        val underEv = (-1.5f / stepEv).roundToInt().coerceIn(r.lower, r.upper)
        val overEv = (1.5f / stepEv).roundToInt().coerceIn(r.lower, r.upper)
        val evTargets = listOf(underEv, savedEv, overEv)
        val frames = ArrayList<Bitmap>()
        val mp = profile.maxMegapixels
        nightBusy = true

        playSound(MediaActionSound.SHUTTER_CLICK)

        fun finishHdr(ok: Boolean) {
            cam.cameraControl.setExposureCompensationIndex(savedEv)
            nightBusy = false
            setStatus(null)
            if (ok && frames.isNotEmpty()) {
                processExecutor.execute {
                    try {
                        val merged = ImageProcessor.mergeHdrPlus(frames, profile)
                        runOnUiThread { enqueueProcessing(merged, Mode.PHOTO) }
                    } catch (t: Throwable) {
                        runOnUiThread {
                            if (frames.isNotEmpty()) enqueueProcessing(frames[0], Mode.PHOTO)
                        }
                    }
                }
            } else {
                for (f in frames) ImageProcessor.recycleAll(f)
                captureSingle(ic)
            }
        }

        fun step(index: Int) {
            val ev = evTargets[index]
            cam.cameraControl.setExposureCompensationIndex(ev)
            setStatus("Capturing HDR+ (${index + 1}/3)...")
            ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    var ok = true
                    try {
                        val frame = ImageProcessor.limit(toUpright(image), mp)
                        frames.add(frame)
                    } catch (t: Throwable) {
                        ok = false
                        try { image.close() } catch (ignored: Throwable) {}
                    }
                    runOnUiThread {
                        if (!ok) finishHdr(false)
                        else if (index + 1 < evTargets.size) step(index + 1)
                        else finishHdr(true)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    runOnUiThread { finishHdr(false) }
                }
            })
        }
        step(0)
    }

    private fun enqueueProcessing(source: Bitmap, m: Mode) {
        val prof = profile
        val look = Looks.ALL[lookIndex]
        val hdr = prefs.smartHdr
        val blur = prefs.portraitBlur
        runOnUiThread {
            pending++
            setStatus("Processing...")
        }
        processExecutor.execute {
            var faceFound = true
            var uri: Uri? = null
            try {
                var work = ImageProcessor.limit(source, prof.maxMegapixels)
                if (m == Mode.PORTRAIT) {
                    val r = ImageProcessor.portrait(work, blur)
                    faceFound = r.faceFound
                    ImageProcessor.recycleAll(work)
                    work = r.bitmap
                }
                val night = m == Mode.NIGHT
                val out = ImageProcessor.enhance(
                    work, prof, look, hdr,
                    if (night) 0.7f else 1f,
                    if (night) 0.25f else 0f
                )
                uri = ImageProcessor.saveJpeg(this, out, prof.jpegQuality)
                ImageProcessor.recycleAll(work, out, source)
            } catch (t: Throwable) {
                ImageProcessor.recycleAll(source)
            }
            runOnUiThread {
                pending--
                if (pending <= 0 && recording == null && !nightBusy) setStatus(null)
                if (uri != null) {
                    lastUri = uri
                    lastMime = "image/jpeg"
                    loadThumb(uri)
                    if (m == Mode.PORTRAIT && !faceFound) toast("Portrait depth blur applied")
                } else {
                    toast("Could not save photo")
                }
            }
        }
    }

    // ------------------------------------------------------------------ Video

    private fun toggleRecording() {
        val vc = videoCapture ?: return
        val active = recording
        if (active != null) {
            active.stop()
            return
        }
        val name = "PROCAM_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/ProCam")
        }
        val options = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values)
            .build()
        var prepared = vc.output.prepareRecording(this, options)
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) {
            @SuppressLint("MissingPermission")
            prepared = prepared.withAudioEnabled()
        }
        recording = prepared.start(ContextCompat.getMainExecutor(this)) { event -> onVideoEvent(event) }
    }

    private fun takePhotoWhileRecording() {
        val ic = imageCapture ?: return
        btnPhotoWhileVideo.animate().scaleX(0.85f).scaleY(0.85f).setDuration(70).withEndAction {
            btnPhotoWhileVideo.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
        }.start()
        playSound(MediaActionSound.SHUTTER_CLICK)
        flashScreen()

        ic.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp: Bitmap? = try { toUpright(image) } catch (t: Throwable) { null }
                if (bmp != null) enqueueProcessing(bmp, Mode.PHOTO)
            }
            override fun onError(exception: ImageCaptureException) {}
        })
    }

    private fun onVideoEvent(event: VideoRecordEvent) {
        when (event) {
            is VideoRecordEvent.Start -> {
                playSound(MediaActionSound.START_VIDEO_RECORDING)
                paused = false
                btnPause.setImageResource(R.drawable.ic_pause)
                showRecordingUi(true)
            }
            is VideoRecordEvent.Status -> {
                val s = event.recordingStats.recordedDurationNanos / 1_000_000_000L
                setStatus(String.format(Locale.US, "REC  %02d:%02d", s / 60, s % 60))
            }
            is VideoRecordEvent.Finalize -> {
                recording = null
                playSound(MediaActionSound.STOP_VIDEO_RECORDING)
                showRecordingUi(false)
                if (!event.hasError()) {
                    val uri = event.outputResults.outputUri
                    lastUri = uri
                    lastMime = "video/mp4"
                    loadThumb(uri)
                    toast("Video saved to Movies/ProCam")
                } else {
                    toast("Video error " + event.error)
                }
            }
            else -> {}
        }
    }

    private fun showRecordingUi(on: Boolean) {
        modeBar.visibility = if (on) View.INVISIBLE else View.VISIBLE
        btnFlip.visibility = if (on) View.GONE else View.VISIBLE
        btnPause.visibility = if (on) View.VISIBLE else View.GONE
        btnPhotoWhileVideo.visibility = if (on) View.VISIBLE else View.GONE
        thumbnail.isEnabled = !on
        if (!on) setStatus(null)
        refreshModeBar()
    }

    // --------------------------------------------------------------- Gallery

    private fun openGallery() {
        galleryLauncher.launch(Intent(this, GalleryActivity::class.java))
    }

    private fun loadThumb(uri: Uri) {
        Thread {
            var bmp: Bitmap? = null
            try {
                bmp = if (Build.VERSION.SDK_INT >= 29) {
                    contentResolver.loadThumbnail(uri, Size(256, 256), null)
                } else {
                    val o = BitmapFactory.Options()
                    o.inSampleSize = 8
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                }
            } catch (e: Exception) {
                bmp = null
            }
            val result = bmp
            runOnUiThread { if (result != null) thumbnail.setImageBitmap(result) }
        }.start()
    }

    private fun loadLastMedia() {
        Thread {
            try {
                val proj = arrayOf(
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.MEDIA_TYPE
                )
                val sel = MediaStore.MediaColumns.DATA + " LIKE ? AND (" +
                    MediaStore.Files.FileColumns.MEDIA_TYPE + "=? OR " +
                    MediaStore.Files.FileColumns.MEDIA_TYPE + "=?)"
                val args = arrayOf(
                    "%/ProCam/%",
                    MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
                    MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
                )
                contentResolver.query(
                    MediaStore.Files.getContentUri("external"), proj, sel, args,
                    MediaStore.MediaColumns.DATE_ADDED + " DESC"
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val id = c.getLong(0)
                        val type = c.getInt(1)
                        val isVideo = type == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                        val base = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        val uri = ContentUris.withAppendedId(base, id)
                        runOnUiThread {
                            lastUri = uri
                            lastMime = if (isVideo) "video/mp4" else "image/jpeg"
                            loadThumb(uri)
                        }
                    } else {
                        runOnUiThread {
                            thumbnail.setImageResource(R.drawable.bg_circle)
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore
            }
        }.start()
    }
}
